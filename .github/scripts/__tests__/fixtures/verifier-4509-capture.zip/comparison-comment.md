**Verdict:** UNVERIFIABLE_INPUT

## Provider Comparison Report

- openai: files reviewed 0 of 2; files_not_reviewed: ["scripts/ci_history.py", "tests/scripts/test_ci_history.py"]; no model review: Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable
- anthropic: files reviewed 0 of 2; files_not_reviewed: ["scripts/ci_history.py", "tests/scripts/test_ci_history.py"]; no model review: Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable

### Provider Summary
| Provider | Model | Verdict | Confidence | Summary |
| --- | --- | --- | --- | --- |
| openai | gpt-6.1-sol | UNVERIFIABLE_INPUT | N/A | Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable |
| anthropic | claude-sonnet-5-5 | UNVERIFIABLE_INPUT | N/A | Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable |

<details>
<summary>📋 Full Provider Details (click to expand)</summary>

#### openai
- **Model:** gpt-6.1-sol
- **Verdict:** UNVERIFIABLE_INPUT
- **Confidence:** N/A
- **Summary:** Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable
- **Concerns:**
  - Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable

#### anthropic
- **Model:** claude-sonnet-5-5
- **Verdict:** UNVERIFIABLE_INPUT
- **Confidence:** N/A
- **Summary:** Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable
- **Concerns:**
  - Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable

</details>

### Agreement
- Verdict: UNVERIFIABLE_INPUT (all providers)
- Concern: Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable

### Disagreement
No major disagreements detected.

### Unique Insights
- openai: Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable
- anthropic: Verifier input coverage incomplete; PASS withheld: Required capture integrity unavailable: acceptance_evidence:artifacts:integrity_failure_or_unknown_kind; acceptance_evidence:artifacts:unavailable

