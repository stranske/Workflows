## PR Diff Summary

- Files changed: 2
- Total additions: 42
- Total deletions: 4

### File changes
- scripts/ci_history.py (+4/-4) <!-- verifier-file-path:v1 "scripts/ci_history.py" -->
- tests/scripts/test_ci_history.py (+38/-0) <!-- verifier-file-path:v1 "tests/scripts/test_ci_history.py" -->
