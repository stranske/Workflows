# Executable missing-unit acceptance

The recovered extractor now accepts an optional `--max-missing N` argument.
Validated missing statements plus branches are summed across the three targets.
An inclusive total at or below N returns 0; an over-budget total returns 1
and reports the measured counts. Invalid limits or reports return 2 without
publishing a total. JSON-only reporting without a limit retains its interface.
No workflow or target production-module change was made.

The pre-test baseline, concrete Gate job, expanded coverage command and bounded
acceptance command are recorded in [round3-preflight.md](round3-preflight.md).
The missing issue-format document leaves the first task unchecked. The current
main SHA at this round's preflight was
`49a88b3776e7cc60d13c670d52c81b8303dfec0a`; the checked-out head was
`c416ee365d13c7d87490ef4f6cd2442d1e58f175`, with this increment in its working tree.
There is no final commit SHA for this increment because staging failed on the
read-only Git metadata mount.

## Focused verification

The original 46 extractor cases passed before editing. Adding the 10 new cases
first produced **7 failed, 49 passed** against the original CLI. After adding
the option, the identical command produced **56 passed**:

```bash
python -m pytest tests/scripts/test_issue_4001_target_coverage.py -m 'not slow' -q
```

Complete red/green output is retained under [budget-after/](budget-after/).
The new cases cover inclusive boundaries, an over-budget result, invalid limits,
JSON/XML disagreement despite a generous limit, and zero-unit retained Gate
reports with both zero and 46-unit limits. The original JSON-only tests pass.

Two deliberate breaks separately changed `>` to `>=` and removed missing
branches from the sum. The named budget test failed in both cases, then all
four cases passed after exact byte restoration. Complete diffs, reverse diffs,
commands, output and restored digest are in
[exclusive-limit.md](budget-after/exclusive-limit.md) and
[ignore-branches.md](budget-after/ignore-branches.md).

The 268 target cases passed with targeted coverage:

```bash
python -m pytest tests/scripts/test_check_consumer_sync_drift.py \
  tests/scripts/test_validate_run_contract.py \
  tests/scripts/test_aggregate_agent_metrics.py -m 'not slow' \
  --cov=scripts.check_consumer_sync_drift \
  --cov=scripts.validate_run_contract --cov=scripts.aggregate_agent_metrics \
  --cov-config=pyproject.toml --cov-report=term-missing \
  --cov-report=json:/tmp/issue-4502-round3/coverage.json \
  --cov-report=xml:/tmp/issue-4502-round3/coverage.xml
```

| Target | Statements | Missing statements | Branches | Missing branches | Coverage |
| --- | ---: | ---: | ---: | ---: | ---: |
| aggregate_agent_metrics.py | 899 | 0 | 380 | 0 | 100.00% |
| check_consumer_sync_drift.py | 654 | 0 | 298 | 0 | 100.00% |
| validate_run_contract.py | 448 | 0 | 212 | 0 | 100.00% |

The complete targeted reports are `budget-after/target-coverage.json.gz` and
`budget-after/target-coverage.xml.gz`. Both original replay report digests were
also independently checked against `replay-after/artifact-manifest.json`.
An immediately runnable bounded acceptance check on those full Gate reports is:

```bash
python docs/evidence/issue-4001/extract_target_coverage.py \
  docs/evidence/issue-4502/replay-after/coverage.json.gz \
  --xml docs/evidence/issue-4502/replay-after/coverage.xml.gz --max-missing 46
```

It returns 0, reproduces each target's zero missing statements and branches,
and prints `combined_missing_units=0`. There are no remaining target locations
requiring behavioral limitation evidence. Original comparable measurements
remain Gate **2 → 0** and bounded **21 → 0**, as detailed in README.md.
The historical 226-unit observation is 226 above the final zero; this increment
does not claim an additional target-coverage reduction.

Black formatted the changed Python files, and the required whole-repository
check passed: **1,009 files unchanged**, exit 0. As in prior rounds, the temporary
sequential dispatcher calls Black's own `reformat_one` with its original mode
and AST safety check. Default multiprocessing fails in this sandbox; setting
one worker stalled, so that attempt was interrupted. The passing invocation:

```bash
PYTHONPATH=/tmp/issue-4502-round3/black-serial \
GITHUB_OUTPUT=/tmp/issue-4502-round3/black-output \
black --check --line-length 100 --exclude '(\.workflows-lib|node_modules)' .
```

The adapter is the same as the code recorded in README.md. Ruff passed for both
changed Python files; no coverage or formatting exclusion was added.

## Full Gate replay

The configured invocation completed with exit 1: **83 failed, 15,804 passed,
25 skipped, 3 xfailed in 399.38s**. Comparing complete JUnit reports against
the prior replay finds the exact same 83 failing nodes, with zero new or
resolved nodes. All 56 extractor cases passed. This is a failing local Gate
invocation, not a successful hosted CI receipt.

After extracting the unchanged embedded observer as documented in README.md:

```bash
PYTHONPATH=/tmp/issue-4502-round3/plugin:$PWD \
pytest -p ci_test_growth -m 'not quarantine and not slow' \
  --junitxml=/tmp/issue-4502-round3/gate/pytest-junit.xml \
  --cov --cov-config=pyproject.toml \
  --cov-report=xml:/tmp/issue-4502-round3/gate/coverage.xml \
  --cov-report=term-missing \
  --cov-report=json:/tmp/issue-4502-round3/gate/coverage.json \
  -n auto --dist load \
  --ignore=tests/scripts/test_pr_verifier_delivery_destinations.py \
  --ignore=tests/scripts/test_pr_verifier_prompt_coverage.py \
  --ignore=tests/scripts/test_pr_verifier_body_overall_integration.py \
  -n 4 --dist=loadgroup
```

Selection, coverage configuration, observer, markers and worker/distribution
settings match Gate; only report destinations are redirected. Complete reports
and logs are retained in `budget-after/coverage.json.gz`, `coverage.xml.gz`,
`pytest-junit.xml.gz` and `pytest.log.gz`, with source digests in `provenance.json`
and per-artifact digests in `artifact-manifest.json`. Every failing node and the
comparison are retained in `failure-comparison.json`.

The new full reports independently reproduce each target's zero missing
statements and branches, 100.00% coverage and a zero-unit accepted total:

```bash
python docs/evidence/issue-4001/extract_target_coverage.py \
  docs/evidence/issue-4502/budget-after/coverage.json.gz \
  --xml docs/evidence/issue-4502/budget-after/coverage.xml.gz --max-missing 46
```

All six target source/test files were checked against HEAD byte for byte;
this increment contains no changes to those files or deliberate breaks.
The Gate-generated collection inventory was restored to its original bytes.
Full CI acceptance remains open. The complete proposed PR-body update, with
the original target-test transcripts and this round's two additional probes,
is retained in `budget-after/proposed-pr-body.md.gz`; it is unpublished.

## Delivery blockers

Staging the meaningful extractor and test changes failed with:

```text
fatal: Unable to create '/home/runner/work/Workflows/Workflows/.git/index.lock': Read-only file system
```

The GitHub connector rejected the requested `needs-human` label on source issue
#4502: `MCP tool call requires approval, but approval policy is never`.
It rejected the source-issue blocker comment for the same reason; neither
remote write succeeded.
PR #4658 had already merged before this round. Its body was not changed, and no
new branch or PR was created. The open-PR handoff invariant cannot be satisfied
for a merged PR. No task checkbox or full-CI acceptance claim is advanced.


## Original target-test implementation and complete transcripts

### Keepalive: ON
<!-- meta:issue:4502 -->

### Source Issue #4502: [backlog] Implement the undelivered three-module coverage work with reproducible Gate evidence

Tracks #4502

Head: codex/issue-4502

Opened by opener-core so codex engages (invite-mode intake).

<!-- pr-preamble:start -->
<!-- meta:issue:4502 -->
> **Source:** Issue #4502

Closes #4502

<!-- pr-preamble:end -->

<!-- auto-status-summary:start -->
## Automated Status Summary
#### Scope
The original implementation is absent, so this is the full remaining coverage effort rather than a focused repair atop productive changes. Because this follow-up chain completed no substantive task, park the scope in the backlog rather than automatically dispatching another identical agent attempt.
Source issue #4429; merged PR #4494 delivered: PR #4494 added a single bootstrap marker in agents/codex-4429.md. It delivered no substantive task from this coverage issue.

<!-- Updated WORKFLOW_OUTPUTS.md context:start -->
## Context for Agent

### Related Issues/PRs
- [stranske/Workflows#4429](https://github.com/stranske/Workflows/issues/4429)
- [stranske/Workflows#4001](https://github.com/stranske/Workflows/issues/4001)
- [#4429](https://github.com/stranske/Workflows/issues/4429)
- [#4494](https://github.com/stranske/Workflows/issues/4494)
- [#4423](https://github.com/stranske/Workflows/issues/4423)
<!-- Updated WORKFLOW_OUTPUTS.md context:end -->

#### Tasks
- [ ] Inspect docs/AGENT_ISSUE_FORMAT.md and the Gate job under .github/workflows; resolve the extractor referenced by #4423 and record its concrete path, exact coverage command, current-main baseline SHA, and a bounded acceptance command before editing tests.
- [x] Run the configured Gate coverage command and extractor for validate_run_contract.py, check_consumer_sync_drift.py, and aggregate_agent_metrics.py; retain complete coverage.json and coverage.xml and enumerate missing statements and branches by target and location.
- [x] Add behavioral tests in test_check_consumer_sync_drift.py for uncovered main(), remote/session helpers, report writers, error paths, and cached misses involving cache.get(key) is None; use pytest.raises for new exception assertions and compare parsed fields or complete report values.
- [x] Add behavioral tests in test_validate_run_contract.py for uncovered fail-closed validator and manifest paths, asserting concrete rejection diagnostics or exit statuses.
- [x] Add behavioral tests in test_aggregate_agent_metrics.py for uncovered statements and branches; document each remaining location that cannot meaningfully be exercised.
- [x] For each new test of the three target modules, capture a temporary behavioral break, the named pytest command and failing output, the exact reversion, and the same command's passing output; include complete transcripts in the PR body.
- [x] Make changes to validate_run_contract.py, check_consumer_sync_drift.py, or aggregate_agent_metrics.py only when a new test demonstrates a production defect, and link each correction to that failure in the PR body.
- [ ] Rerun the same Gate command and extractor, retain retrievable coverage.json and coverage.xml, run the configured CI pytest invocation, and publish complete measurement provenance, before/after tables, and any required remaining-unit explanations in the PR body.

#### Acceptance criteria
- [ ] The repository-configured pytest command passes in CI; each named new-test command also fails under its documented deliberate break and passes after reversion.
- [ ] The exact Gate coverage command and extractor are runnable from the PR body and reproduce all three targets' counts from retrievable coverage.json and coverage.xml.
- [x] Combined missing statements plus branches total at most 46, or the PR body identifies every remaining unit by target and location and supplies the required behavioral limitation evidence.
- [ ] The PR body identifies baseline and final SHAs, Gate job, coverage command, extractor, per-target before/after counts, and reduction relative to the historical 226-unit baseline.
- [x] The submitted diff contains no deliberate-break edits, and every production correction has a demonstrated triggering test failure.

<!-- auto-status-summary:end -->


## Coverage evidence handoff (unpublished)

PR #4658 merged externally while this replay was running. These local extractor
changes are not in that merged head. Git metadata is read-only; GitHub writes
require approval unavailable under this run's policy. This proposed body records
the prepared payload without claiming publication or a final continuation SHA.

### Comparable before/after counts

| Target | Original Gate before missing lines / branches | Original Gate after | Continuation replay | Bounded before | Bounded after |
| --- | ---: | ---: | ---: | ---: | ---: |
| aggregate_agent_metrics.py | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 |
| check_consumer_sync_drift.py | 2 / 0 | 0 / 0 | 0 / 0 | 2 / 0 | 0 / 0 |
| validate_run_contract.py | 0 / 0 | 0 / 0 | 0 / 0 | 12 / 7 | 0 / 0 |
| Combined | 2 | 0 | 0 | 21 | 0 |

The historical 226-unit baseline comprised metrics 22, drift 130 and contract
74 missing units. Final coverage is 226 below that historical number; the
attributable reductions in this branch are two units in Gate and 21 in the
bounded population. This continuation adds no further target coverage reduction.
No remaining target units need behavioral-limitation explanations.

### Standalone observer preparation

Gate job: `.github/workflows/pr-00-gate.yml`, `python-ci`, calls
`.github/workflows/reusable-10-ci-python.yml`, job `tests`, step `pytest`.
Runtime: Python 3.14; no workflow changes.

```bash
mkdir -p /tmp/issue-4502-round2/plugin /tmp/issue-4502-round2/gate
python - <<'PREP'
from pathlib import Path
import yaml
workflow = yaml.safe_load(Path('.github/workflows/reusable-10-ci-python.yml').read_text())
step = next(s for s in workflow['jobs']['tests']['steps'] if s.get('id') == 'pytest')
plugin = step['run'].split("<<'PY'\n", 1)[1].split('\nPY\n', 1)[0]
Path('/tmp/issue-4502-round2/plugin/ci_test_growth.py').write_text(plugin + '\n')
PREP
```

### Reproduce the retained before and after measurements

Each input below is a complete coverage report, not a reconstructed target
summary. The extractor reads gzip directly and verifies both XML counters.
`docs/evidence/issue-4502/artifact-manifest.json` records the original artifact
digests; `replay-after/artifact-manifest.json` records the continuation digests,
runtime, source hashes and results. Before/after location inventories are retained
under each phase's `inventory.json`.

```bash
for phase in gate-before gate-after target-before target-after replay-after; do
  python docs/evidence/issue-4001/extract_target_coverage.py \
    "docs/evidence/issue-4502/$phase/coverage.json.gz" \
    --xml "docs/evidence/issue-4502/$phase/coverage.xml.gz"
done
```

Expected combined missing units, in order: 2, 0, 21, 0, 0.

# Extractor and evidence replay continuation

This continuation adds gzip report input and `--xml` validation to
`docs/evidence/issue-4001/extract_target_coverage.py`. The original JSON-only CLI
remains supported. XML counters are read independently; missing branch exits
are counted from covered/total conditions, rather than partial-branch counts.
Malformed reports and counter disagreements return exit 2 without publishing
an accepted total. XML parsing uses the repository's existing `defusedxml`
dependency. No workflow or target production module was changed.

The 46 new extractor checks exercise plain/compressed input, rejection paths,
the original JSON-only interface, all four retained report pairs, and both
compressed/uncompressed report digests. They pass in the bounded command:

```bash
python -m pytest tests/scripts/test_issue_4001_target_coverage.py -m 'not slow' -q
```

The 268 existing target cases also pass. Their targeted coverage command in
[round2-preflight.md](round2-preflight.md) confirms:

| Target | Statements | Missing statements | Branches | Missing branches | Coverage |
| --- | ---: | ---: | ---: | ---: | ---: |
| aggregate_agent_metrics.py | 899 | 0 | 380 | 0 | 100.00% |
| check_consumer_sync_drift.py | 654 | 0 | 298 | 0 | 100.00% |
| validate_run_contract.py | 448 | 0 | 212 | 0 | 100.00% |

The original bounded measurement remains 21 → 0 missing units; the original
full Gate comparison remains 2 → 0. The historical 226-unit baseline is distinct
from this branch's before measurement. Replaying zero missing units does not
attribute another 226-unit reduction to the continuation.

## Full Gate replay

The configured coverage invocation completed with exit 1: **83 failed, 15,794
passed, 25 skipped, 3 xfailed in 404.11s**. All 46 extractor cases passed in this
run. Comparing complete JUnit inventories against the previous final run finds
the exact same 83 failure nodes, with zero new or resolved nodes. CI acceptance
therefore remains open. No unrelated failure was repaired or suppressed.

Complete reports and logs are retained in [replay-after/](replay-after/):
`coverage.json.gz`, `coverage.xml.gz`, `pytest-junit.xml.gz`, `pytest.log.gz`,
`inventory.json`, and `failure-comparison.json`. Unlike the original baseline
recovery, these JSON/XML reports were written directly by pytest-cov.
The bounded and formatting logs are retained alongside them.

After extracting the embedded observer exactly as in README.md, the replay was:

```bash
PYTHONPATH=/tmp/issue-4502-round2/plugin:$PWD \
pytest -p ci_test_growth -m 'not quarantine and not slow' \
  --junitxml=/tmp/issue-4502-round2/gate/pytest-junit.xml \
  --cov --cov-config=pyproject.toml \
  --cov-report=xml:/tmp/issue-4502-round2/gate/coverage.xml \
  --cov-report=term-missing \
  --cov-report=json:/tmp/issue-4502-round2/gate/coverage.json \
  -n auto --dist load \
  --ignore=tests/scripts/test_pr_verifier_delivery_destinations.py \
  --ignore=tests/scripts/test_pr_verifier_prompt_coverage.py \
  --ignore=tests/scripts/test_pr_verifier_body_overall_integration.py \
  -n 4 --dist=loadgroup
python docs/evidence/issue-4001/extract_target_coverage.py \
  docs/evidence/issue-4502/replay-after/coverage.json.gz \
  --xml docs/evidence/issue-4502/replay-after/coverage.xml.gz
```

Both report counters independently reproduce zero missing units for all three
targets; there are no remaining target locations requiring limitation evidence.
Selection, embedded observer, marker, worker/distribution options and coverage
configuration match Gate. Only output destinations are redirected. This local
invocation is not a successful hosted CI receipt.

All nine original deliberate-break probes were rerun after Gate exited. Every
one of the 18 target cases failed under its documented break and passed after
exact byte restoration. Complete fresh transcripts are retained under
`replay-after/mutations/` as `.md.gz` files. The extractor's valid-report command
also failed under temporary branch-count (four cases) and gzip-decoding (three
cases, with the uncompressed case unchanged) regressions, then passed all four
cases after each exact restoration. See
[extractor-red-green.md](replay-after/extractor-red-green.md).

`replay-after/artifact-manifest.json` records report digests, source digests,
runtime versions and results. All six target source/test files were checked
against Git after the probes; every byte matches the checked-out head.

## Formatting

Black formatted both Python files. Its required repository-wide check passed:
**1,009 files would be left unchanged, exit 0**. As in the previous round,
Black's multiprocessing dispatcher stalled in this sandbox; the same temporary
sequential adapter documented in README.md calls Black's own `reformat_one`
with its original mode and AST safety check for every discovered file. The
command was:

```bash
PYTHONPATH=/tmp/issue-4502-round2/black-serial \
BLACK_CACHE_DIR=/tmp/issue-4502-round2/black-cache \
GITHUB_OUTPUT=/tmp/issue-4502-round2/black-output \
black --check --line-length 100 --exclude '(\.workflows-lib|node_modules)' .
```

Ruff also passed for both Python files. No formatting exclusion, coverage
exclusion, test skip, or production correction was added.

## Provenance and blockers

Checked-out source head: `16be78c0eb19908fe7a383d8c457164286945e6e`, with the
extractor and its new tests in the working tree. The three target modules and
their three target test files match that head byte for byte. Original before
head: `b25657e57ec09b90f6bac8fa5d892f822b3bc34c`. Original preflight main:
`e621d8f0ed8b83b9648b7fa8577b4f236bd57f1d`. Live main was independently checked
through GitHub's branch API during this round:
`8084366d968d5c4f68208536ca8bb3956ce99091`.

The first task remains blocked by absent `docs/AGENT_ISSUE_FORMAT.md`; the
available issue-format guide and template were inspected instead, as recorded
before test edits. The local commit attempt failed with:

```text
fatal: Unable to create '/home/runner/work/Workflows/Workflows/.git/index.lock': Read-only file system
```

The explicit `needs-human` label request was rejected by the GitHub connector:
`MCP tool call requires approval, but approval policy is never`. This also
prevents publishing the prepared PR-body update through that connector.
No final commit SHA or successful publication is claimed. PR #4658 was initially
open and ready for review (`draft=false`), but merged externally at
2026-11-11 21:15:54 UTC with head
`16be78c0eb19908fe7a383d8c457164286945e6e`. The local continuation is not part
of that merged payload. No task or acceptance checkbox was updated on the PR
by this run. A complete proposed body, including the fresh full transcripts,
is retained as `replay-after/pr-body.md.gz` (uncompressed staging copy:
`/tmp/issue-4502-round2/pr-body.md`). It is an unpublished handoff artifact.

## Complete target deliberate-break transcripts


# test_consumer_mirror_enforces_catalog_timestamp

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -293,6 +293,8 @@
     satellite schema it declares.
     """
     ingests = entry.get("ingests", []) or []
+    if "document-mirror/v1" in ingests:
+        report.fail("mirror routing regression", "ingests")
     if not ingests:
         report.fail(
             f"consumer {report.repo} declares no 'ingests' schemas to validate",
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_consumer_mirror_enforces_catalog_timestamp -m 'not slow' --tb=short -q
FF                                                                       [100%]
=================================== FAILURES ===================================
___________ test_consumer_mirror_enforces_catalog_timestamp[invalid] ___________
tests/scripts/test_validate_run_contract.py:1231: in test_consumer_mirror_enforces_catalog_timestamp
    assert [(v.path, v.message) for v in report.violations] == expected
E   assert [('ingests', ...'date-time'")] == [('', "ingest...'date-time'")]
E
E     At index 0 diff: ('ingests', 'mirror routing regression') != ('', "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a 'date-time'")
E     Left contains one more item: ('', "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a 'date-time'")
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       [
E     +     (
E     +         'ingests',
E     +         'mirror routing regression',
E     +     ),
E           (
E               '',
E               "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a "
E               "'date-time'",
E           ),
E       ]
____________ test_consumer_mirror_enforces_catalog_timestamp[valid] ____________
tests/scripts/test_validate_run_contract.py:1230: in test_consumer_mirror_enforces_catalog_timestamp
    assert report.conformant is valid_timestamp
E   AssertionError: assert False is True
E    +  where False = Report(repo='owner/mirror-consumer', role='consumer', conformant=False, skipped=False, violations=[Violation(message='mirror routing regression', path='ingests')]).conformant
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_consumer_mirror_enforces_catalog_timestamp[invalid] - assert [('ingests', ...'date-time'")] == [('', "ingest...'date-time'")]

  At index 0 diff: ('ingests', 'mirror routing regression') != ('', "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a 'date-time'")
  Left contains one more item: ('', "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a 'date-time'")

  Full diff: (-: missing in left side, +: extra in left side)
    [
  +     (
  +         'ingests',
  +         'mirror routing regression',
  +     ),
        (
            '',
            "ingested-as-document-mirror/v1: 'not-a-timestamp' is not a "
            "'date-time'",
        ),
    ]
FAILED tests/scripts/test_validate_run_contract.py::test_consumer_mirror_enforces_catalog_timestamp[valid] - AssertionError: assert False is True
 +  where False = Report(repo='owner/mirror-consumer', role='consumer', conformant=False, skipped=False, violations=[Violation(message='mirror routing regression', path='ingests')]).conformant
2 failed in 0.78s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -293,8 +293,6 @@
     satellite schema it declares.
     """
     ingests = entry.get("ingests", []) or []
-    if "document-mirror/v1" in ingests:
-        report.fail("mirror routing regression", "ingests")
     if not ingests:
         report.fail(
             f"consumer {report.repo} declares no 'ingests' schemas to validate",
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_consumer_mirror_enforces_catalog_timestamp -m 'not slow' --tb=short -q
..                                                                       [100%]
2 passed in 0.69s
exit=0


# test_consumer_schema_fails_closed_without_required_format

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -142,6 +142,8 @@

 def _validator_for_schema(schema_dir: Path, name: str) -> Draft202012Validator:
     schema = _load_schema(schema_dir, name)
+    if name in ('mosaic-core-v1.schema.json', 'document-mirror-v1.schema.json'):
+        raise RuntimeError('schema loading regression')
     if name == "mosaic-core-v1.schema.json":
         # Explicitly request the checker so a missing rfc3339-validator dependency
         # fails instead of silently accepting malformed checked_at timestamps.
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_consumer_schema_fails_closed_without_required_format -m 'not slow' --tb=short -q
FFF                                                                      [100%]
=================================== FAILURES ===================================
_ test_consumer_schema_fails_closed_without_required_format[document-mirror/v1-valid_document_mirror.json-date-time] _
tests/scripts/test_validate_run_contract.py:1206: in test_consumer_schema_fails_closed_without_required_format
    with pytest.raises(RuntimeError, match=f"unavailable: {format_name}"):
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E   AssertionError: Regex pattern did not match.
E     Expected regex: 'unavailable: date-time'
E     Actual message: 'schema loading regression'
_ test_consumer_schema_fails_closed_without_required_format[document-mirror/v1-valid_document_mirror.json-uri] _
tests/scripts/test_validate_run_contract.py:1206: in test_consumer_schema_fails_closed_without_required_format
    with pytest.raises(RuntimeError, match=f"unavailable: {format_name}"):
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E   AssertionError: Regex pattern did not match.
E     Expected regex: 'unavailable: uri'
E     Actual message: 'schema loading regression'
_ test_consumer_schema_fails_closed_without_required_format[mosaic-core/v1-valid_mosaic_thesis_check.json-date-time] _
tests/scripts/test_validate_run_contract.py:1206: in test_consumer_schema_fails_closed_without_required_format
    with pytest.raises(RuntimeError, match=f"unavailable: {format_name}"):
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E   AssertionError: Regex pattern did not match.
E     Expected regex: 'unavailable: date-time'
E     Actual message: 'schema loading regression'
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_consumer_schema_fails_closed_without_required_format[document-mirror/v1-valid_document_mirror.json-date-time] - AssertionError: Regex pattern did not match.
  Expected regex: 'unavailable: date-time'
  Actual message: 'schema loading regression'
FAILED tests/scripts/test_validate_run_contract.py::test_consumer_schema_fails_closed_without_required_format[document-mirror/v1-valid_document_mirror.json-uri] - AssertionError: Regex pattern did not match.
  Expected regex: 'unavailable: uri'
  Actual message: 'schema loading regression'
FAILED tests/scripts/test_validate_run_contract.py::test_consumer_schema_fails_closed_without_required_format[mosaic-core/v1-valid_mosaic_thesis_check.json-date-time] - AssertionError: Regex pattern did not match.
  Expected regex: 'unavailable: date-time'
  Actual message: 'schema loading regression'
3 failed in 0.80s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -142,8 +142,6 @@

 def _validator_for_schema(schema_dir: Path, name: str) -> Draft202012Validator:
     schema = _load_schema(schema_dir, name)
-    if name in ('mosaic-core-v1.schema.json', 'document-mirror-v1.schema.json'):
-        raise RuntimeError('schema loading regression')
     if name == "mosaic-core-v1.schema.json":
         # Explicitly request the checker so a missing rfc3339-validator dependency
         # fails instead of silently accepting malformed checked_at timestamps.
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_consumer_schema_fails_closed_without_required_format -m 'not slow' --tb=short -q
...                                                                      [100%]
3 passed in 0.70s
exit=0


# test_main_caches_failed_blob_reads_by_repo_and_sha

Deliberate break:
```diff
--- scripts/check_consumer_sync_drift.py
+++ scripts/check_consumer_sync_drift.py
@@ -1076,7 +1076,7 @@

     def read_blob(repo: str, sha: str) -> str | None:
         key = (repo, sha)
-        if key not in blob_text_cache:
+        if blob_text_cache.get(key) is None:
             blob_text_cache[key] = remote_blob_text(session, repo, sha)
         return blob_text_cache[key]

```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_check_consumer_sync_drift.py::test_main_caches_failed_blob_reads_by_repo_and_sha -m 'not slow' --tb=short -q
F                                                                        [100%]
=================================== FAILURES ===================================
______________ test_main_caches_failed_blob_reads_by_repo_and_sha ______________
tests/scripts/test_check_consumer_sync_drift.py:100: in test_main_caches_failed_blob_reads_by_repo_and_sha
    assert Counter(call.args for call in read_blob.call_args_list) == Counter(
E   AssertionError: assert Counter({(<ob...ble-sha'): 3}) == Counter({(<ob...ble-sha'): 1})
E
E     Differing items:
E     {(<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 3} != {(<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 1}
E     {(<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 3} != {(<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 1}
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       Counter({
E     -     (<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 1,
E     ?                                                                           ^
E     +     (<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 3,
E     ?                                                                           ^
E     -     (<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 1,
E     ?                                                                            ^
E     +     (<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 3,
E     ?                                                                            ^
E       })
----------------------------- Captured stdout call -----------------------------
gate triggers: owner/first unknown (Gate unreadable)
gate triggers: owner/second unknown (Gate unreadable)
::warning::Consumer repo drift detected
=========================== short test summary info ============================
FAILED tests/scripts/test_check_consumer_sync_drift.py::test_main_caches_failed_blob_reads_by_repo_and_sha - AssertionError: assert Counter({(<ob...ble-sha'): 3}) == Counter({(<ob...ble-sha'): 1})

  Differing items:
  {(<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 3} != {(<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 1}
  {(<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 3} != {(<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 1}

  Full diff: (-: missing in left side, +: extra in left side)
    Counter({
  -     (<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 1,
  ?                                                                           ^
  +     (<object object at 0x7a2c61781840>, 'owner/first', 'unreadable-sha'): 3,
  ?                                                                           ^
  -     (<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 1,
  ?                                                                            ^
  +     (<object object at 0x7a2c61781840>, 'owner/second', 'unreadable-sha'): 3,
  ?                                                                            ^
    })
1 failed in 7.52s
exit=1

Exact reversion:
```diff
--- scripts/check_consumer_sync_drift.py
+++ scripts/check_consumer_sync_drift.py
@@ -1076,7 +1076,7 @@

     def read_blob(repo: str, sha: str) -> str | None:
         key = (repo, sha)
-        if blob_text_cache.get(key) is None:
+        if key not in blob_text_cache:
             blob_text_cache[key] = remote_blob_text(session, repo, sha)
         return blob_text_cache[key]

```
Restored source SHA-256: 4a339397f54b680719432f7d2a4fd136d7bdd40b2ad3dd267170c61c7eeb26c5

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_check_consumer_sync_drift.py::test_main_caches_failed_blob_reads_by_repo_and_sha -m 'not slow' --tb=short -q
.                                                                        [100%]
1 passed in 0.68s
exit=0


# test_main_persists_valid_run_conformance

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -796,7 +796,7 @@
         )
     if args.github_output:
         with args.github_output.open("a") as fh:
-            ok = report.conformant or report.skipped
+            ok = False
             fh.write(f"conformant={'true' if ok else 'false'}\n")

     if report.skipped or report.conformant:
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_main_persists_valid_run_conformance -m 'not slow' --tb=short -q
F                                                                        [100%]
=================================== FAILURES ===================================
___________________ test_main_persists_valid_run_conformance ___________________
tests/scripts/test_validate_run_contract.py:1296: in test_main_persists_valid_run_conformance
    assert output.read_text() == "earlier=value\nconformant=true\n"
E   AssertionError: assert 'earlier=valu...rmant=false\n' == 'earlier=valu...ormant=true\n'
E
E       earlier=value
E     - conformant=true
E     ?            ^^^
E     + conformant=false
E     ?            ^^^^
----------------------------- Captured stdout call -----------------------------
stranske/Pension-Data: run envelope conforms to run-contract/v1
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_main_persists_valid_run_conformance - AssertionError: assert 'earlier=valu...rmant=false\n' == 'earlier=valu...ormant=true\n'

    earlier=value
  - conformant=true
  ?            ^^^
  + conformant=false
  ?            ^^^^
1 failed in 0.77s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -796,7 +796,7 @@
         )
     if args.github_output:
         with args.github_output.open("a") as fh:
-            ok = False
+            ok = report.conformant or report.skipped
             fh.write(f"conformant={'true' if ok else 'false'}\n")

     if report.skipped or report.conformant:
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_main_persists_valid_run_conformance -m 'not slow' --tb=short -q
.                                                                        [100%]
1 passed in 0.71s
exit=0


# test_main_rejects_unreadable_artifact_manifest

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -759,7 +759,7 @@
             manifest = _load_json(args.manifest) if args.manifest else None
         except (OSError, json.JSONDecodeError) as exc:
             print(f"ERROR: cannot load artifact manifest {args.manifest}: {exc}", file=sys.stderr)
-            return 2
+            return 1
         report = validate_envelope(
             envelope=envelope,
             schema_dir=args.schema_dir,
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_main_rejects_unreadable_artifact_manifest -m 'not slow' --tb=short -q
FFF                                                                      [100%]
=================================== FAILURES ===================================
___________ test_main_rejects_unreadable_artifact_manifest[missing] ____________
tests/scripts/test_validate_run_contract.py:1243: in test_main_rejects_unreadable_artifact_manifest
    assert (
E   AssertionError: assert 1 == 2
E    +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a0/registry.json', '--repo', ...])
E    +    where <function main at 0x7e01592b62a0> = vrc.main
----------------------------- Captured stderr call -----------------------------
ERROR: cannot load artifact manifest /tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a0/manifest.json: [Errno 2] No such file or directory: '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a0/manifest.json'
__________ test_main_rejects_unreadable_artifact_manifest[directory] ___________
tests/scripts/test_validate_run_contract.py:1243: in test_main_rejects_unreadable_artifact_manifest
    assert (
E   AssertionError: assert 1 == 2
E    +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a1/registry.json', '--repo', ...])
E    +    where <function main at 0x7e01592b62a0> = vrc.main
----------------------------- Captured stderr call -----------------------------
ERROR: cannot load artifact manifest /tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a1/manifest.json: [Errno 21] Is a directory: '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a1/manifest.json'
_________ test_main_rejects_unreadable_artifact_manifest[invalid-json] _________
tests/scripts/test_validate_run_contract.py:1243: in test_main_rejects_unreadable_artifact_manifest
    assert (
E   AssertionError: assert 1 == 2
E    +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a2/registry.json', '--repo', ...])
E    +    where <function main at 0x7e01592b62a0> = vrc.main
----------------------------- Captured stderr call -----------------------------
ERROR: cannot load artifact manifest /tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a2/manifest.json: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_main_rejects_unreadable_artifact_manifest[missing] - AssertionError: assert 1 == 2
 +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a0/registry.json', '--repo', ...])
 +    where <function main at 0x7e01592b62a0> = vrc.main
FAILED tests/scripts/test_validate_run_contract.py::test_main_rejects_unreadable_artifact_manifest[directory] - AssertionError: assert 1 == 2
 +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a1/registry.json', '--repo', ...])
 +    where <function main at 0x7e01592b62a0> = vrc.main
FAILED tests/scripts/test_validate_run_contract.py::test_main_rejects_unreadable_artifact_manifest[invalid-json] - AssertionError: assert 1 == 2
 +  where 1 = <function main at 0x7e01592b62a0>(['/home/runner/work/Workflows/Workflows/tests/fixtures/backplane/valid_run.json', '--manifest', '/tmp/pytest-of-runner...st.json', '--registry', '/tmp/pytest-of-runner/pytest-31/test_main_rejects_unreadable_a2/registry.json', '--repo', ...])
 +    where <function main at 0x7e01592b62a0> = vrc.main
3 failed in 0.81s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -759,7 +759,7 @@
             manifest = _load_json(args.manifest) if args.manifest else None
         except (OSError, json.JSONDecodeError) as exc:
             print(f"ERROR: cannot load artifact manifest {args.manifest}: {exc}", file=sys.stderr)
-            return 1
+            return 2
         report = validate_envelope(
             envelope=envelope,
             schema_dir=args.schema_dir,
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_main_rejects_unreadable_artifact_manifest -m 'not slow' --tb=short -q
...                                                                      [100%]
3 passed in 0.71s
exit=0


# test_mirror_cli_reports_without_optional_output_files

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -703,7 +703,7 @@
             args.evidence_objects or args.tracked_variables or args.mirror_manifest or []
         )
         if report.conformant:
-            print(f"{label}: {path_count} file(s) conform to schema")
+            print(f"{label}: {path_count} file(s) rejected by schema")
         else:
             print(
                 f"{label}: {len(report.violations)} conformance violation(s):",
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_mirror_cli_reports_without_optional_output_files -m 'not slow' --tb=short -q
F                                                                        [100%]
=================================== FAILURES ===================================
____________ test_mirror_cli_reports_without_optional_output_files _____________
tests/scripts/test_validate_run_contract.py:1313: in test_mirror_cli_reports_without_optional_output_files
    assert captured.out == "document-mirror/v1: 1 file(s) conform to schema\n"
E   AssertionError: assert 'document-mir...d by schema\n' == 'document-mir...m to schema\n'
E
E     - document-mirror/v1: 1 file(s) conform to schema
E     ?                                ------- ^
E     + document-mirror/v1: 1 file(s) rejected by schema
E     ?                               ++++  ^^^^^
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_mirror_cli_reports_without_optional_output_files - AssertionError: assert 'document-mir...d by schema\n' == 'document-mir...m to schema\n'

  - document-mirror/v1: 1 file(s) conform to schema
  ?                                ------- ^
  + document-mirror/v1: 1 file(s) rejected by schema
  ?                               ++++  ^^^^^
1 failed in 0.77s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -703,7 +703,7 @@
             args.evidence_objects or args.tracked_variables or args.mirror_manifest or []
         )
         if report.conformant:
-            print(f"{label}: {path_count} file(s) rejected by schema")
+            print(f"{label}: {path_count} file(s) conform to schema")
         else:
             print(
                 f"{label}: {len(report.violations)} conformance violation(s):",
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_mirror_cli_reports_without_optional_output_files -m 'not slow' --tb=short -q
.                                                                        [100%]
1 passed in 0.70s
exit=0


# test_remote_tree_transport_failure_preserves_unknown

Deliberate break:
```diff
--- scripts/check_consumer_sync_drift.py
+++ scripts/check_consumer_sync_drift.py
@@ -919,7 +919,7 @@
         repo_response = session.get(f"https://api.github.com/repos/{repo}")
     except requests.RequestException as exc:
         return (
-            None,
+            {},
             f"{repo}: repository access preflight failed (requests.{type(exc).__name__})",
         )
     if repo_response.status_code >= 400:
@@ -936,7 +936,7 @@
         )
     except requests.RequestException as exc:
         return (
-            None,
+            {},
             f"{repo}: repository tree fetch failed (requests.{type(exc).__name__})",
         )
     if tree_response.status_code >= 400:
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown -m 'not slow' --tb=short -q
FFFF                                                                     [100%]
=================================== FAILURES ===================================
__ test_remote_tree_transport_failure_preserves_unknown[repo-ConnectionError] __
tests/scripts/test_check_consumer_sync_drift.py:41: in test_remote_tree_transport_failure_preserves_unknown
    assert check_consumer_sync_drift.fetch_remote_tree(session, "owner/repo") == (
E   AssertionError: assert ({}, 'owner/r...ectionError)') == (None, 'owner...ectionError)')
E
E     At index 0 diff: {} != None
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       (
E     -     None,
E     +     {},
E           'owner/repo: repository access preflight failed (requests.ConnectionError)',
E       )
______ test_remote_tree_transport_failure_preserves_unknown[repo-Timeout] ______
tests/scripts/test_check_consumer_sync_drift.py:41: in test_remote_tree_transport_failure_preserves_unknown
    assert check_consumer_sync_drift.fetch_remote_tree(session, "owner/repo") == (
E   AssertionError: assert ({}, 'owner/r...sts.Timeout)') == (None, 'owner...sts.Timeout)')
E
E     At index 0 diff: {} != None
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       (
E     -     None,
E     +     {},
E           'owner/repo: repository access preflight failed (requests.Timeout)',
E       )
__ test_remote_tree_transport_failure_preserves_unknown[tree-ConnectionError] __
tests/scripts/test_check_consumer_sync_drift.py:41: in test_remote_tree_transport_failure_preserves_unknown
    assert check_consumer_sync_drift.fetch_remote_tree(session, "owner/repo") == (
E   AssertionError: assert ({}, 'owner/r...ectionError)') == (None, 'owner...ectionError)')
E
E     At index 0 diff: {} != None
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       (
E     -     None,
E     +     {},
E           'owner/repo: repository tree fetch failed (requests.ConnectionError)',
E       )
______ test_remote_tree_transport_failure_preserves_unknown[tree-Timeout] ______
tests/scripts/test_check_consumer_sync_drift.py:41: in test_remote_tree_transport_failure_preserves_unknown
    assert check_consumer_sync_drift.fetch_remote_tree(session, "owner/repo") == (
E   AssertionError: assert ({}, 'owner/r...sts.Timeout)') == (None, 'owner...sts.Timeout)')
E
E     At index 0 diff: {} != None
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       (
E     -     None,
E     +     {},
E           'owner/repo: repository tree fetch failed (requests.Timeout)',
E       )
=========================== short test summary info ============================
FAILED tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown[repo-ConnectionError] - AssertionError: assert ({}, 'owner/r...ectionError)') == (None, 'owner...ectionError)')

  At index 0 diff: {} != None

  Full diff: (-: missing in left side, +: extra in left side)
    (
  -     None,
  +     {},
        'owner/repo: repository access preflight failed (requests.ConnectionError)',
    )
FAILED tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown[repo-Timeout] - AssertionError: assert ({}, 'owner/r...sts.Timeout)') == (None, 'owner...sts.Timeout)')

  At index 0 diff: {} != None

  Full diff: (-: missing in left side, +: extra in left side)
    (
  -     None,
  +     {},
        'owner/repo: repository access preflight failed (requests.Timeout)',
    )
FAILED tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown[tree-ConnectionError] - AssertionError: assert ({}, 'owner/r...ectionError)') == (None, 'owner...ectionError)')

  At index 0 diff: {} != None

  Full diff: (-: missing in left side, +: extra in left side)
    (
  -     None,
  +     {},
        'owner/repo: repository tree fetch failed (requests.ConnectionError)',
    )
FAILED tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown[tree-Timeout] - AssertionError: assert ({}, 'owner/r...sts.Timeout)') == (None, 'owner...sts.Timeout)')

  At index 0 diff: {} != None

  Full diff: (-: missing in left side, +: extra in left side)
    (
  -     None,
  +     {},
        'owner/repo: repository tree fetch failed (requests.Timeout)',
    )
4 failed in 0.89s
exit=1

Exact reversion:
```diff
--- scripts/check_consumer_sync_drift.py
+++ scripts/check_consumer_sync_drift.py
@@ -919,7 +919,7 @@
         repo_response = session.get(f"https://api.github.com/repos/{repo}")
     except requests.RequestException as exc:
         return (
-            {},
+            None,
             f"{repo}: repository access preflight failed (requests.{type(exc).__name__})",
         )
     if repo_response.status_code >= 400:
@@ -936,7 +936,7 @@
         )
     except requests.RequestException as exc:
         return (
-            {},
+            None,
             f"{repo}: repository tree fetch failed (requests.{type(exc).__name__})",
         )
     if tree_response.status_code >= 400:
```
Restored source SHA-256: 4a339397f54b680719432f7d2a4fd136d7bdd40b2ad3dd267170c61c7eeb26c5

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_check_consumer_sync_drift.py::test_remote_tree_transport_failure_preserves_unknown -m 'not slow' --tb=short -q
....                                                                     [100%]
4 passed in 0.69s
exit=0


# test_self_smoke_rejects_incomplete_schema_inventory

Deliberate break:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -821,11 +821,11 @@
             f"FAIL schema dir {schema_dir}: no *.schema.json files found; "
             "self-smoke cannot validate schemas"
         )
-        return 1
+        return 2
     missing = sorted(set(INGEST_SCHEMA_FILES.values()) - set(schema_names))
     if missing:
         print(f"FAIL schema dir {schema_dir}: missing registered schemas: {', '.join(missing)}")
-        return 1
+        return 2
     for name in schema_names:
         schema = _load_schema(schema_dir, name)
         Draft202012Validator.check_schema(schema)
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_self_smoke_rejects_incomplete_schema_inventory -m 'not slow' --tb=short -q
FF                                                                       [100%]
=================================== FAILURES ===================================
__________ test_self_smoke_rejects_incomplete_schema_inventory[empty] __________
tests/scripts/test_validate_run_contract.py:1325: in test_self_smoke_rejects_incomplete_schema_inventory
    assert vrc._self_smoke(schema_dir, registry) == 1
E   AssertionError: assert 2 == 1
E    +  where 2 = <function _self_smoke at 0x771232382610>(PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp0/schemas'), PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp0/registry.json'))
E    +    where <function _self_smoke at 0x771232382610> = vrc._self_smoke
----------------------------- Captured stdout call -----------------------------
FAIL schema dir /tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp0/schemas: no *.schema.json files found; self-smoke cannot validate schemas
___ test_self_smoke_rejects_incomplete_schema_inventory[missing-registered] ____
tests/scripts/test_validate_run_contract.py:1325: in test_self_smoke_rejects_incomplete_schema_inventory
    assert vrc._self_smoke(schema_dir, registry) == 1
E   AssertionError: assert 2 == 1
E    +  where 2 = <function _self_smoke at 0x771232382610>(PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp1/schemas'), PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp1/registry.json'))
E    +    where <function _self_smoke at 0x771232382610> = vrc._self_smoke
----------------------------- Captured stdout call -----------------------------
FAIL schema dir /tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp1/schemas: missing registered schemas: artifact-manifest-v1.schema.json, capability-bundle-v1.schema.json, document-mirror-v1.schema.json, evidence-object-v1.schema.json, mosaic-core-v1.schema.json, output-substrate-v1.schema.json, tracked-variable-v1.schema.json
=========================== short test summary info ============================
FAILED tests/scripts/test_validate_run_contract.py::test_self_smoke_rejects_incomplete_schema_inventory[empty] - AssertionError: assert 2 == 1
 +  where 2 = <function _self_smoke at 0x771232382610>(PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp0/schemas'), PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp0/registry.json'))
 +    where <function _self_smoke at 0x771232382610> = vrc._self_smoke
FAILED tests/scripts/test_validate_run_contract.py::test_self_smoke_rejects_incomplete_schema_inventory[missing-registered] - AssertionError: assert 2 == 1
 +  where 2 = <function _self_smoke at 0x771232382610>(PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp1/schemas'), PosixPath('/tmp/pytest-of-runner/pytest-38/test_self_smoke_rejects_incomp1/registry.json'))
 +    where <function _self_smoke at 0x771232382610> = vrc._self_smoke
2 failed in 0.78s
exit=1

Exact reversion:
```diff
--- scripts/validate_run_contract.py
+++ scripts/validate_run_contract.py
@@ -821,11 +821,11 @@
             f"FAIL schema dir {schema_dir}: no *.schema.json files found; "
             "self-smoke cannot validate schemas"
         )
-        return 2
+        return 1
     missing = sorted(set(INGEST_SCHEMA_FILES.values()) - set(schema_names))
     if missing:
         print(f"FAIL schema dir {schema_dir}: missing registered schemas: {', '.join(missing)}")
-        return 2
+        return 1
     for name in schema_names:
         schema = _load_schema(schema_dir, name)
         Draft202012Validator.check_schema(schema)
```
Restored source SHA-256: 5b769c2ea3d9edb526b0ffd706e9611cf7b086140c65bae639f5b58088e36efa

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_validate_run_contract.py::test_self_smoke_rejects_incomplete_schema_inventory -m 'not slow' --tb=short -q
..                                                                       [100%]
2 passed in 0.70s
exit=0


# test_verifier_ledger_counts_escalations_without_duplicating_shared_followups

Deliberate break:
```diff
--- scripts/aggregate_agent_metrics.py
+++ scripts/aggregate_agent_metrics.py
@@ -836,7 +836,7 @@
         if followup_issue is not None:
             ledger_followup_issues.add(followup_issue)
         if bool(entry.get("needs_human")) or disposition == "needs-human":
-            ledger_needs_human += 1
+            ledger_needs_human += 2
         chain_depth = _safe_int(entry.get("chain_depth"))
         if chain_depth is not None:
             ledger_chain_depths.append(chain_depth)
```

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_aggregate_agent_metrics.py::test_verifier_ledger_counts_escalations_without_duplicating_shared_followups -m 'not slow' --tb=short -q
F                                                                        [100%]
=================================== FAILURES ===================================
_ test_verifier_ledger_counts_escalations_without_duplicating_shared_followups _
tests/scripts/test_aggregate_agent_metrics.py:477: in test_verifier_ledger_counts_escalations_without_duplicating_shared_followups
    assert {key: value for key, value in summary.items() if key.startswith("ledger_")} == {
E   AssertionError: assert {'ledger_reco...sues': 1, ...} == {'ledger_reco...sues': 1, ...}
E
E     Omitting 10 identical items, use -vv to show
E     Differing items:
E     {'ledger_needs_human': 4} != {'ledger_needs_human': 2}
E
E     Full diff: (-: missing in left side, +: extra in left side)
E       {
E           'ledger_records': 2,
E     -     'ledger_dispositions': {
E     +     'ledger_dispositions': Counter({
E     ?                            ++++++++
E               'follow-up': 1,
E               'needs-human': 1,
E     -     },
E     +     }),
E     ?      +
E           'ledger_prs': 1,
E           'ledger_followup_issues': 1,
E     -     'ledger_needs_human': 2,
E     ?                           ^
E     +     'ledger_needs_human': 4,
E     ?                           ^
E           'ledger_avg_chain_depth': 2.0,
E           'ledger_max_chain_depth': 3,
E           'ledger_policy_records': 0,
E     -     'ledger_policy_actions': {},
E     ?                              ^^
E     +     'ledger_policy_actions': Counter(),
E     ?                              ^^^^^^^^^
E     -     'ledger_policy_triggers': {},
E     ?                               ^^
E     +     'ledger_policy_triggers': Counter(),
E     ?                               ^^^^^^^^^
E           'ledger_policy_depth_limit_exceeded': 0,
E       }
=========================== short test summary info ============================
FAILED tests/scripts/test_aggregate_agent_metrics.py::test_verifier_ledger_counts_escalations_without_duplicating_shared_followups - AssertionError: assert {'ledger_reco...sues': 1, ...} == {'ledger_reco...sues': 1, ...}

  Omitting 10 identical items, use -vv to show
  Differing items:
  {'ledger_needs_human': 4} != {'ledger_needs_human': 2}

  Full diff: (-: missing in left side, +: extra in left side)
    {
        'ledger_records': 2,
  -     'ledger_dispositions': {
  +     'ledger_dispositions': Counter({
  ?                            ++++++++
            'follow-up': 1,
            'needs-human': 1,
  -     },
  +     }),
  ?      +
        'ledger_prs': 1,
        'ledger_followup_issues': 1,
  -     'ledger_needs_human': 2,
  ?                           ^
  +     'ledger_needs_human': 4,
  ?                           ^
        'ledger_avg_chain_depth': 2.0,
        'ledger_max_chain_depth': 3,
        'ledger_policy_records': 0,
  -     'ledger_policy_actions': {},
  ?                              ^^
  +     'ledger_policy_actions': Counter(),
  ?                              ^^^^^^^^^
  -     'ledger_policy_triggers': {},
  ?                               ^^
  +     'ledger_policy_triggers': Counter(),
  ?                               ^^^^^^^^^
        'ledger_policy_depth_limit_exceeded': 0,
    }
1 failed in 0.72s
exit=1

Exact reversion:
```diff
--- scripts/aggregate_agent_metrics.py
+++ scripts/aggregate_agent_metrics.py
@@ -836,7 +836,7 @@
         if followup_issue is not None:
             ledger_followup_issues.add(followup_issue)
         if bool(entry.get("needs_human")) or disposition == "needs-human":
-            ledger_needs_human += 2
+            ledger_needs_human += 1
         chain_depth = _safe_int(entry.get("chain_depth"))
         if chain_depth is not None:
             ledger_chain_depths.append(chain_depth)
```
Restored source SHA-256: e03bd53293d5627de350405f9dcfdda966b9071c7954c59241ced4cbf12bd1df

$ /opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_aggregate_agent_metrics.py::test_verifier_ledger_counts_escalations_without_duplicating_shared_followups -m 'not slow' --tb=short -q
.                                                                        [100%]
1 passed in 0.65s
exit=0


The extractor-specific complete RED/GREEN transcript is retained separately at `docs/evidence/issue-4502/replay-after/extractor-red-green.md`.


## Budget acceptance deliberate-break transcripts

# exclusive-limit

Command: `/opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget -m 'not slow' -q`

## Deliberate change
```diff
--- docs/evidence/issue-4001/extract_target_coverage.py
+++ docs/evidence/issue-4001/extract_target_coverage.py
@@ -123,7 +123,7 @@
     print(json.dumps(stats, indent=2, sort_keys=True))
     total_missing = sum(stats[t]["missing_lines"] + stats[t]["missing_branches"] for t in TARGETS)
     print(f"combined_missing_units={total_missing}", file=sys.stderr)
-    if args.max_missing is not None and total_missing > args.max_missing:
+    if args.max_missing is not None and total_missing >= args.max_missing:
         print(f"coverage budget exceeded: {total_missing} > {args.max_missing}", file=sys.stderr)
         return 1
     return 0
```

## Broken result
```text
..F.                                                                     [100%]
=================================== FAILURES ===================================
_____________ test_cli_enforces_inclusive_missing_unit_budget[9-0] _____________

reports = (PosixPath('/tmp/pytest-of-runner/pytest-4/test_cli_enforces_inclusive_mi2/coverage.json'), PosixPath('/tmp/pytest-of-runner/pytest-4/test_cli_enforces_inclusive_mi2/coverage.xml'))
limit = 9, expected_status = 0

    @pytest.mark.parametrize("limit,expected_status", [(0, 1), (8, 1), (9, 0), (10, 0)])
    def test_cli_enforces_inclusive_missing_unit_budget(reports, limit, expected_status):
        json_path, xml_path = reports
        result = cli(json_path, "--xml", xml_path, "--max-missing", limit)
>       assert result.returncode == expected_status, result.stderr
E       AssertionError: combined_missing_units=9
E         coverage budget exceeded: 9 > 9
E         
E       assert 1 == 0
E        +  where 1 = CompletedProcess(args=['/opt/hostedtoolcache/Python/3.14.10/x64/bin/python', '/home/runner/work/Workflows/Workflows/do...nes": 1,\n    "percent_covered": 25.0\n  }\n}\n', stderr='combined_missing_units=9\ncoverage budget exceeded: 9 > 9\n').returncode

tests/scripts/test_issue_4001_target_coverage.py:84: AssertionError
=========================== short test summary info ============================
FAILED tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget[9-0] - AssertionError: combined_missing_units=9
  coverage budget exceeded: 9 > 9
  
assert 1 == 0
 +  where 1 = CompletedProcess(args=['/opt/hostedtoolcache/Python/3.14.10/x64/bin/python', '/home/runner/work/Workflows/Workflows/do...nes": 1,\n    "percent_covered": 25.0\n  }\n}\n', stderr='combined_missing_units=9\ncoverage budget exceeded: 9 > 9\n').returncode
1 failed, 3 passed in 0.96s

exit=1
```

## Exact reversion
```diff
--- docs/evidence/issue-4001/extract_target_coverage.py
+++ docs/evidence/issue-4001/extract_target_coverage.py
@@ -123,7 +123,7 @@
     print(json.dumps(stats, indent=2, sort_keys=True))
     total_missing = sum(stats[t]["missing_lines"] + stats[t]["missing_branches"] for t in TARGETS)
     print(f"combined_missing_units={total_missing}", file=sys.stderr)
-    if args.max_missing is not None and total_missing >= args.max_missing:
+    if args.max_missing is not None and total_missing > args.max_missing:
         print(f"coverage budget exceeded: {total_missing} > {args.max_missing}", file=sys.stderr)
         return 1
     return 0
```
Restored SHA-256: `f2d2b9c8de02855fa6bc5413b842c9fee2585abcad4f458984a2014976869a95`

## Restored result
```text
....                                                                     [100%]
4 passed in 0.92s

exit=0
```


# ignore-branches

Command: `/opt/hostedtoolcache/Python/3.14.10/x64/bin/python -m pytest tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget -m 'not slow' -q`

## Deliberate change
```diff
--- docs/evidence/issue-4001/extract_target_coverage.py
+++ docs/evidence/issue-4001/extract_target_coverage.py
@@ -121,7 +121,7 @@
         print(f"invalid coverage: {exc}", file=sys.stderr)
         return 2
     print(json.dumps(stats, indent=2, sort_keys=True))
-    total_missing = sum(stats[t]["missing_lines"] + stats[t]["missing_branches"] for t in TARGETS)
+    total_missing = sum(stats[t]["missing_lines"] for t in TARGETS)
     print(f"combined_missing_units={total_missing}", file=sys.stderr)
     if args.max_missing is not None and total_missing > args.max_missing:
         print(f"coverage budget exceeded: {total_missing} > {args.max_missing}", file=sys.stderr)
```

## Broken result
```text
FFFF                                                                     [100%]
=================================== FAILURES ===================================
_____________ test_cli_enforces_inclusive_missing_unit_budget[0-1] _____________

reports = (PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi0/coverage.json'), PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi0/coverage.xml'))
limit = 0, expected_status = 1

    @pytest.mark.parametrize("limit,expected_status", [(0, 1), (8, 1), (9, 0), (10, 0)])
    def test_cli_enforces_inclusive_missing_unit_budget(reports, limit, expected_status):
        json_path, xml_path = reports
        result = cli(json_path, "--xml", xml_path, "--max-missing", limit)
        assert result.returncode == expected_status, result.stderr
        assert json.loads(result.stdout) == {
            target: {"missing_lines": 1, "missing_branches": 2, "percent_covered": 25.0}
            for target in extractor.TARGETS
        }
        expected_error = "combined_missing_units=9\n"
        if expected_status:
            expected_error += f"coverage budget exceeded: 9 > {limit}\n"
>       assert result.stderr == expected_error
E       AssertionError: assert 'combined_mis...eded: 3 > 0\n' == 'combined_mis...eded: 9 > 0\n'
E         
E         - combined_missing_units=9
E         ?                        ^
E         + combined_missing_units=3
E         ?                        ^
E         - coverage budget exceeded: 9 > 0
E         ?                           ^
E         + coverage budget exceeded: 3 > 0
E         ?                           ^

tests/scripts/test_issue_4001_target_coverage.py:92: AssertionError
_____________ test_cli_enforces_inclusive_missing_unit_budget[8-1] _____________

reports = (PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi1/coverage.json'), PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi1/coverage.xml'))
limit = 8, expected_status = 1

    @pytest.mark.parametrize("limit,expected_status", [(0, 1), (8, 1), (9, 0), (10, 0)])
    def test_cli_enforces_inclusive_missing_unit_budget(reports, limit, expected_status):
        json_path, xml_path = reports
        result = cli(json_path, "--xml", xml_path, "--max-missing", limit)
>       assert result.returncode == expected_status, result.stderr
E       AssertionError: combined_missing_units=3
E         
E       assert 0 == 1
E        +  where 0 = CompletedProcess(args=['/opt/hostedtoolcache/Python/3.14.10/x64/bin/python', '/home/runner/work/Workflows/Workflows/do...ng_branches": 2,\n    "missing_lines": 1,\n    "percent_covered": 25.0\n  }\n}\n', stderr='combined_missing_units=3\n').returncode

tests/scripts/test_issue_4001_target_coverage.py:84: AssertionError
_____________ test_cli_enforces_inclusive_missing_unit_budget[9-0] _____________

reports = (PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi2/coverage.json'), PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi2/coverage.xml'))
limit = 9, expected_status = 0

    @pytest.mark.parametrize("limit,expected_status", [(0, 1), (8, 1), (9, 0), (10, 0)])
    def test_cli_enforces_inclusive_missing_unit_budget(reports, limit, expected_status):
        json_path, xml_path = reports
        result = cli(json_path, "--xml", xml_path, "--max-missing", limit)
        assert result.returncode == expected_status, result.stderr
        assert json.loads(result.stdout) == {
            target: {"missing_lines": 1, "missing_branches": 2, "percent_covered": 25.0}
            for target in extractor.TARGETS
        }
        expected_error = "combined_missing_units=9\n"
        if expected_status:
            expected_error += f"coverage budget exceeded: 9 > {limit}\n"
>       assert result.stderr == expected_error
E       AssertionError: assert 'combined_missing_units=3\n' == 'combined_missing_units=9\n'
E         
E         - combined_missing_units=9
E         ?                        ^
E         + combined_missing_units=3
E         ?                        ^

tests/scripts/test_issue_4001_target_coverage.py:92: AssertionError
____________ test_cli_enforces_inclusive_missing_unit_budget[10-0] _____________

reports = (PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi3/coverage.json'), PosixPath('/tmp/pytest-of-runner/pytest-6/test_cli_enforces_inclusive_mi3/coverage.xml'))
limit = 10, expected_status = 0

    @pytest.mark.parametrize("limit,expected_status", [(0, 1), (8, 1), (9, 0), (10, 0)])
    def test_cli_enforces_inclusive_missing_unit_budget(reports, limit, expected_status):
        json_path, xml_path = reports
        result = cli(json_path, "--xml", xml_path, "--max-missing", limit)
        assert result.returncode == expected_status, result.stderr
        assert json.loads(result.stdout) == {
            target: {"missing_lines": 1, "missing_branches": 2, "percent_covered": 25.0}
            for target in extractor.TARGETS
        }
        expected_error = "combined_missing_units=9\n"
        if expected_status:
            expected_error += f"coverage budget exceeded: 9 > {limit}\n"
>       assert result.stderr == expected_error
E       AssertionError: assert 'combined_missing_units=3\n' == 'combined_missing_units=9\n'
E         
E         - combined_missing_units=9
E         ?                        ^
E         + combined_missing_units=3
E         ?                        ^

tests/scripts/test_issue_4001_target_coverage.py:92: AssertionError
=========================== short test summary info ============================
FAILED tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget[0-1] - AssertionError: assert 'combined_mis...eded: 3 > 0\n' == 'combined_mis...eded: 9 > 0\n'
  
  - combined_missing_units=9
  ?                        ^
  + combined_missing_units=3
  ?                        ^
  - coverage budget exceeded: 9 > 0
  ?                           ^
  + coverage budget exceeded: 3 > 0
  ?                           ^
FAILED tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget[8-1] - AssertionError: combined_missing_units=3
  
assert 0 == 1
 +  where 0 = CompletedProcess(args=['/opt/hostedtoolcache/Python/3.14.10/x64/bin/python', '/home/runner/work/Workflows/Workflows/do...ng_branches": 2,\n    "missing_lines": 1,\n    "percent_covered": 25.0\n  }\n}\n', stderr='combined_missing_units=3\n').returncode
FAILED tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget[9-0] - AssertionError: assert 'combined_missing_units=3\n' == 'combined_missing_units=9\n'
  
  - combined_missing_units=9
  ?                        ^
  + combined_missing_units=3
  ?                        ^
FAILED tests/scripts/test_issue_4001_target_coverage.py::test_cli_enforces_inclusive_missing_unit_budget[10-0] - AssertionError: assert 'combined_missing_units=3\n' == 'combined_missing_units=9\n'
  
  - combined_missing_units=9
  ?                        ^
  + combined_missing_units=3
  ?                        ^
4 failed in 1.00s

exit=1
```

## Exact reversion
```diff
--- docs/evidence/issue-4001/extract_target_coverage.py
+++ docs/evidence/issue-4001/extract_target_coverage.py
@@ -121,7 +121,7 @@
         print(f"invalid coverage: {exc}", file=sys.stderr)
         return 2
     print(json.dumps(stats, indent=2, sort_keys=True))
-    total_missing = sum(stats[t]["missing_lines"] for t in TARGETS)
+    total_missing = sum(stats[t]["missing_lines"] + stats[t]["missing_branches"] for t in TARGETS)
     print(f"combined_missing_units={total_missing}", file=sys.stderr)
     if args.max_missing is not None and total_missing > args.max_missing:
         print(f"coverage budget exceeded: {total_missing} > {args.max_missing}", file=sys.stderr)
```
Restored SHA-256: `f2d2b9c8de02855fa6bc5413b842c9fee2585abcad4f458984a2014976869a95`

## Restored result
```text
....                                                                     [100%]
4 passed in 0.90s

exit=0
```
