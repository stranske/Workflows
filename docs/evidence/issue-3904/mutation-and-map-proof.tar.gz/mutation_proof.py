import ast,hashlib,json,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/tmp/workflows3904-mutations-20261016')
OUT=Path(__file__).parent/'mutations';OUT.mkdir(exist_ok=False)
source=ROOT/'scripts/langchain/pr_verifier.py';original=source.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
nodes={
 '_required_evidence_channels':('tests/scripts/test_pr_verifier_delivery_destinations.py::test_product_component_coordination_preserves_bare_other_channel[semantic-0-0-0-0-0-0-0]','    return set()\n'),
 '_apply_coverage_floor':('tests/scripts/test_pr_verifier_delivery_destinations.py::test_product_component_coordination_real_floor[False-and-body-False--must-active]','    return result\n'),
}
results=[]
try:
 for name,(node,replacement) in nodes.items():
  fn=next(n for n in ast.parse(original).body if isinstance(n,ast.FunctionDef) and n.name==name)
  lines=original.decode().splitlines(keepends=True);lines[fn.body[0].lineno-1:fn.end_lineno]=[replacement]
  mutant=''.join(lines).encode();(OUT/(name+'-mutant.py')).write_bytes(mutant)
  record={'function':name,'node':node,'original_sha256':sha(original),'mutant_sha256':sha(mutant),'phases':[]}
  for phase,data in [('red',mutant),('green',original)]:
   source.write_bytes(data)
   junit=OUT/(name+'-'+phase+'.xml')
   command=['/opt/anaconda3/bin/python3','-m','pytest',node,'-q','-o','addopts=',f'--junitxml={junit}']
   started=time.monotonic();p=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
   (OUT/(name+'-'+phase+'.log')).write_text(p.stdout+p.stderr)
   tree=ET.parse(junit);cases=list(tree.getroot().iter('testcase'));assert len(cases)==1
   errors=list(tree.getroot().iter('error'));skips=list(tree.getroot().iter('skipped'));failures=list(tree.getroot().iter('failure'))
   assert not errors and not skips
   if phase=='red':
    assert p.returncode==1 and len(failures)==1
    assert failures[0].get('message','').startswith(('AssertionError','assert ')),failures[0].get('message')
   else:assert p.returncode==0 and not failures
   record['phases'].append({'phase':phase,'command':command,'cwd':str(ROOT),'exit':p.returncode,'seconds':time.monotonic()-started,'junit':str(junit),'failures':len(failures),'errors':len(errors),'skips':len(skips)})
  assert source.read_bytes()==original
  record['restored_sha256']=sha(source.read_bytes());results.append(record);print(name,'assertion RED / restored GREEN',flush=True)
finally:source.write_bytes(original)
(OUT/'original.py').write_bytes(original)
(OUT/'receipt.json').write_text(json.dumps(results,indent=2)+'\n')
