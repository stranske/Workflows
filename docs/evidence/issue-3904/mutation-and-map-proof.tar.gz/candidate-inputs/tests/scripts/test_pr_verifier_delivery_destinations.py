"""Exact canary findings: destination completeness and actionable text output."""

import importlib.util
from itertools import permutations
from pathlib import Path

import pytest
from scripts import docs_drift_fix_agent as fix_agent
from scripts.langchain import pr_verifier as verifier

_COVERAGE_SPEC = importlib.util.spec_from_file_location(
    "delivery_coverage_fixtures", Path(__file__).with_name("test_pr_verifier_prompt_coverage.py")
)
_COVERAGE_FIXTURE = importlib.util.module_from_spec(_COVERAGE_SPEC)
_COVERAGE_SPEC.loader.exec_module(_COVERAGE_FIXTURE)


def _semantic_matrix(*, dimensions, semantic, lexical_spines):
    """Cross semantic states; sweep aliases on their declared interaction axes.

    Every original value survives. The core keeps every semantic combination;
    a lexical sweep keeps each alias crossed with its named grammar boundaries.
    Other lexical axes use their first value. See docs/ci/verifier-grammar-matrices.md
    for the intentionally unproven high-order lexical combinations and mapping.
    """
    from itertools import product

    names = list(dimensions)
    assert set(semantic).isdisjoint(lexical_spines)
    assert set(semantic) | set(lexical_spines) == set(names)
    rows = {}

    def add(axes, label):
        for indices in product(*(range(len(dimensions[name])) for name in axes)):
            selected = dict(zip(axes, indices, strict=True))
            key = tuple(selected.get(name, 0) for name in names)
            rows.setdefault(key, label + "-" + "-".join(map(str, indices)))

    add(semantic, "semantic")
    for alias, spine in lexical_spines.items():
        assert set(spine) <= set(semantic)
        add((alias, *spine), "lexical-" + alias.replace(",", "-"))
    flattened = [part.strip() for name in names for part in name.split(",")]
    values = []
    for key, label in rows.items():
        row = []
        for name, index in zip(names, key, strict=True):
            value = dimensions[name][index]
            row.extend(value if "," in name else [value])
        values.append(pytest.param(*row, id=label))
    return pytest.mark.parametrize(flattened, values)


def _floor_verdict(criterion, *, body, comments, artifacts="present", overall="present"):
    """Use the real prompt and coverage floor with one immutable fixture module."""
    context, _ = _COVERAGE_FIXTURE._context(1, 1000, 1000)
    evidence = (
        f"- Overall retrieval status: **{overall}**\n"
        f"- PR body: **{body}**\n- PR comments: **{comments}**\n"
        f"- Referenced workflow artifacts: **{artifacts}**"
    )
    context = context.replace("- " + _COVERAGE_FIXTURE.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary", "## Acceptance evidence\n\n" + evidence + "\n\n## PR Diff Summary"
    )
    return verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    ).verdict


@pytest.mark.parametrize("quotes", [('"', '"'), ("'", "'"), ("`", "`"), ("“", "”"), ("‘", "’")])
@pytest.mark.parametrize("separator", ["\n", "\r\n", "\n\n", " "])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment"])
@pytest.mark.parametrize("operation", ["The parser recognizes", "The reviewer quotes"])
@pytest.mark.parametrize("independent", [False, True])
def test_multiline_quoted_criteria_cannot_create_delivery(
    quotes, separator, destination, operation, independent
):
    opening, closing = quotes
    criterion = (
        f"{operation} {opening}- Tests pass locally{separator}"
        f"- Evidence must be recorded in {destination} by the reviewer{closing}"
    )
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == "PASS"
        if independent:
            assert (
                _floor_verdict(criterion, body="present", comments="present", artifacts=missing)
                == "CONCERNS"
            )


@pytest.mark.parametrize(
    "destination,channel", [("the PR body", "body"), ("a PR comment", "comments")]
)
@pytest.mark.parametrize("modifier", ["", "optional archived "])
@pytest.mark.parametrize("wrap", ["\n", "\r\n"])
def test_passive_object_boundary_preserves_legitimate_soft_wrap(
    destination, channel, modifier, wrap
):
    criterion = f"{modifier}Evidence{wrap}must be recorded by the reviewer in {destination}"
    assert verifier._required_evidence_options(criterion) == [{channel}]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == "CONCERNS"


@pytest.mark.parametrize("marker", ["-", "*", "1.", "- [ ]"])
@pytest.mark.parametrize("newline", ["\n", "\r\n"])
@pytest.mark.parametrize(
    "destination,channel", [("the PR body", "body"), ("a PR comment", "comments")]
)
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
@pytest.mark.parametrize("agent_first", [False, True])
@pytest.mark.parametrize("modifier", ["", "optional archived "])
def test_passive_object_does_not_capture_previous_list_item(
    marker, newline, destination, channel, governor, agent_first, modifier
):
    delivery = f"{modifier}Evidence {governor} be recorded " + (
        f"by the reviewer in {destination}" if agent_first else f"in {destination} by the reviewer"
    )
    criterion = f"{marker} Tests pass locally{newline}{marker} {delivery}"
    expected = {channel} if governor == "must" else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if expected else "PASS"
        )


@pytest.mark.parametrize(
    "preposition", ["in", "into", "to", "within", "for", "as", "through", "via"]
)
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("the PR description", "body"), ("a PR comment", "comments")],
)
@pytest.mark.parametrize("component", ["", " results panel"])
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
@pytest.mark.parametrize("independent", [False, True])
def test_transport_qualifier_is_not_a_product_component(
    preposition, destination, channel, component, governor, independent
):
    criterion = (
        f"The UI {governor} display test results in {destination}{component} "
        f"{preposition} automation"
    )
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    expected = ({channel} if governor == "must" and not component else set()) | (
        {"artifacts"} if independent else set()
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if channel in expected else "PASS"
        )


@_semantic_matrix(
    dimensions={
        "independent": [False, True],
        "passive": [False, True],
        "actor": ["UI", "reviewer"],
        "governor": ["must", "may", "must not", "is not expected to"],
        "component": ["", " results panel"],
        "destination,channel": [
            ["the PR body", "body"],
            ["the PR description", "body"],
            ["a PR comment", "comments"],
        ],
        "qualifier": [
            "containing logs",
            "including test results",
            "showing failures",
            "displaying command output",
            "summarizing validation results",
            "presenting screenshots",
            "listing failures",
            "describing test results",
        ],
    },
    semantic=("independent", "passive", "actor", "governor", "component", "destination,channel"),
    lexical_spines={"qualifier": ("passive", "actor", "governor")},
)
def test_participial_content_is_not_a_component_name(
    qualifier, destination, channel, component, governor, actor, passive, independent
):
    criterion = (
        f"Test logs {governor} be posted by the {actor} in {destination}{component} {qualifier}"
        if passive
        else f"The {actor} {governor} post test logs in {destination}{component} {qualifier}"
    )
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
    expected = (
        {channel} if governor == "must" and (actor == "reviewer" or not component) else set()
    ) | ({"artifacts"} if independent else set())
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if channel in expected else "PASS"
        )


@pytest.mark.parametrize(
    "qualifier",
    ["containing logs", "including test results", "showing failures", "displaying command output"],
)
@pytest.mark.parametrize("actor", ["UI", "reviewer"])
@pytest.mark.parametrize("coordination", ["AND", "OR"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("bare_body", [False, True])
def test_content_qualifiers_preserve_destination_alternatives(
    qualifier, actor, coordination, reverse, bare_body
):
    bare = "the PR body" if bare_body else "a PR comment"
    component = "a PR comment results panel" if bare_body else "the PR body results panel"
    bare_channel = "body" if bare_body else "comments"
    members = [component, bare + " " + qualifier]
    if reverse:
        members.reverse()
    criterion = f"The {actor} must post test logs in " + f" {coordination} ".join(members)
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = (
        [{bare_channel, "artifacts"}]
        if actor == "UI"
        else (
            [{"body", "comments", "artifacts"}]
            if coordination == "AND"
            else [{"body", "artifacts"}, {"comments", "artifacts"}]
        )
    )
    assert {frozenset(s) for s in verifier._required_evidence_options(criterion)} == {
        frozenset(s) for s in expected
    }
    for body in ("present", "absent", "unavailable"):
        for comments in ("present", "absent", "unavailable"):
            available = (
                {"artifacts"}
                | ({"body"} if body == "present" else set())
                | ({"comments"} if comments == "present" else set())
            )
            assert _floor_verdict(criterion, body=body, comments=comments) == (
                "PASS" if any(s <= available for s in expected) else "CONCERNS"
            )


@pytest.mark.parametrize(
    "modifier", ["optional archived", "no longer required", "not expected", "not supposed", "no"]
)
@pytest.mark.parametrize(
    "destination,channel", [("the PR body", "body"), ("a PR comment", "comments")]
)
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
def test_content_object_polarity_does_not_change_delivery_governor(
    modifier, destination, channel, governor
):
    criterion = f"The UI {governor} post test logs in {destination} containing {modifier} evidence"
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"} | ({channel} if governor == "must" else set())
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if governor == "must" else "PASS"
        )


@pytest.mark.parametrize(
    "modifier", ["optional archived", "no longer required", "not expected", "not supposed"]
)
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("the PR description", "body"), ("a PR comment", "comments")],
)
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
@pytest.mark.parametrize("actor", ["UI", "reviewer"])
@pytest.mark.parametrize("component", ["", " results panel"])
@pytest.mark.parametrize("voice", ["active", "passive-before", "passive-after"])
def test_content_object_polarity_across_passive_agents(
    modifier, destination, channel, governor, actor, component, voice
):
    tail = f"in {destination}{component} displaying {modifier} evidence"
    if voice == "active":
        criterion = f"The {actor} {governor} publish test logs {tail}"
    elif voice == "passive-before":
        criterion = f"Test logs {governor} be published by the {actor} {tail}"
    else:
        criterion = f"Test logs {governor} be published {tail} by the {actor}"
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"} | (
        {channel} if governor == "must" and (actor == "reviewer" or not component) else set()
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for overall in ("present", "absent", "unavailable"):
        assert (
            _floor_verdict(criterion, body="present", comments="present", overall=overall) == "PASS"
        )
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if channel in expected else "PASS"
        )


@pytest.mark.parametrize("qualifier", ["containing logs", "showing failures"])
@pytest.mark.parametrize(
    "destination,channel", [("the PR body", "body"), ("a PR comment", "comments")]
)
@pytest.mark.parametrize(
    "tail", ["only if available", ", when produced", "that must contain command output"]
)
@pytest.mark.parametrize("quoted", [False, True])
def test_content_qualifier_preserves_literals_conditions_and_independent_duties(
    qualifier, destination, channel, tail, quoted
):
    criterion = f"The UI must post test logs in {destination} {qualifier} {tail}"
    if quoted:
        criterion = 'The parser recognizes "' + criterion + '"'
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"} | ({channel} if not quoted and tail.startswith("that") else set())
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if channel in expected else "PASS"
        )
        assert (
            _floor_verdict(criterion, body="present", comments="present", artifacts=missing)
            == "CONCERNS"
        )


@pytest.mark.parametrize("actor", ["reviewer", "UI"])
@pytest.mark.parametrize("body_alias", ["body", "description"])
@pytest.mark.parametrize("reverse", [False, True])
def test_product_chain_keeps_genuine_destination_alternatives(actor, body_alias, reverse):
    first, second = f"the PR {body_alias}", "a PR comment"
    if reverse:
        first, second = second, first
    prefix = (
        "The UI must record evidence in the PR body panel and "
        if actor == "UI"
        else "The reviewer must "
    )
    criterion = (
        prefix + f"record evidence in {first} or {second}; "
        "the auditor must record evidence in a workflow artifact"
    )
    assert {frozenset(option) for option in verifier._required_evidence_options(criterion)} == {
        frozenset({"body", "artifacts"}),
        frozenset({"comments", "artifacts"}),
    }
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments="present") == "PASS"
        assert _floor_verdict(criterion, body="present", comments=missing) == "PASS"
        assert _floor_verdict(criterion, body=missing, comments=missing) == "CONCERNS"


@_semantic_matrix(
    dimensions={
        "reverse": [False, True],
        "forms": [
            ["ordinary", "ordinary", "ordinary"],
            ["perfect", "ordinary", "ordinary"],
            ["ordinary", "perfect", "perfect"],
            ["ordinary", "progressive", "progressive"],
            ["perfect", "progressive", "ordinary"],
            ["progressive", "perfect", "ordinary"],
        ],
        "operation,perfect,progressive": [
            ["record", "recorded", "recording"],
            ["supply", "supplied", "supplying"],
            ["leave", "left", "leaving"],
        ],
        "first_conjunction,last_conjunction": [
            ["and", "and"],
            ["and", "or"],
            ["or", "and"],
            ["or", "or"],
        ],
        "middle_governor": ["must", "may", "must not", "is not expected to"],
        "first_governor": ["must", "may", "must not", "is not expected to"],
    },
    semantic=(
        "reverse",
        "forms",
        "first_conjunction,last_conjunction",
        "middle_governor",
        "first_governor",
    ),
    lexical_spines={
        "operation,perfect,progressive": ("forms", "middle_governor", "first_governor")
    },
)
def test_product_chain_inherits_latest_explicit_governor_and_aspect(
    first_governor,
    middle_governor,
    first_conjunction,
    last_conjunction,
    operation,
    perfect,
    progressive,
    forms,
    reverse,
):
    predicates = {
        "ordinary": operation,
        "perfect": "have " + perfect,
        "progressive": "be " + progressive,
    }
    first, middle, final = [predicates[form] for form in forms]
    first_destination, middle_destination, final_destination = (
        "the PR body panel",
        "a PR comment panel",
        "a PR comment",
    )
    if reverse:
        first_destination, middle_destination, final_destination = (
            "a PR comment panel",
            "the PR body panel",
            "the PR body",
        )
    criterion = (
        f"The UI {first_governor} {first} evidence in {first_destination} "
        f"{first_conjunction} {middle_governor} {middle} evidence in {middle_destination} "
        f"{last_conjunction} {final} evidence in {final_destination}; "
        "the auditor must record evidence in a workflow artifact"
    )
    channel = "body" if reverse else "comments"
    expected = {"artifacts"} | ({channel} if middle_governor == "must" else set())
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if channel in expected else "PASS"
        )


@pytest.mark.parametrize("actor", ["reviewer", "maintainer"])
@pytest.mark.parametrize("first", ["recorded", "supplied", "left"])
@pytest.mark.parametrize("second", ["recorded", "left"])
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
@pytest.mark.parametrize("boundary", ["and", "but"])
@pytest.mark.parametrize("reverse", [False, True])
def test_irregular_perfect_delivery_inherits_actor_and_polarity(
    actor, first, second, governor, boundary, reverse
):
    first_destination, second_destination = ("the PR description", "a PR comment")
    if reverse:
        first_destination, second_destination = second_destination, first_destination
    criterion = (
        f"The {actor} {governor} have {first} evidence in {first_destination} "
        f"{boundary} have {second} evidence in {second_destination}"
    )
    expected = (
        {"body", "comments"}
        if governor == "must"
        else (
            {"body" if reverse else "comments"}
            if boundary == "but" and governor != "may"
            else set()
        )
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        for channel in ("body", "comments"):
            assert _floor_verdict(
                criterion,
                body=missing if channel == "body" else "present",
                comments=missing if channel == "comments" else "present",
            ) == ("CONCERNS" if channel in expected else "PASS")


@pytest.mark.parametrize("actor", ["UI", "service", "interface"])
@pytest.mark.parametrize("operation", ["generate", "record", "supply", "leave"])
@pytest.mark.parametrize("component", ["panel", "preview panel", "formatted preview panel"])
@pytest.mark.parametrize("boundary", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_repeated_product_operations_keep_component_ownership(
    actor, operation, component, boundary, reverse, governor
):
    destinations = ["the PR body " + component, "a PR comment " + component]
    if reverse:
        destinations.reverse()
    criterion = (
        f"The {actor} {governor} {operation} evidence in {destinations[0]} "
        f"{boundary} {operation} evidence in {destinations[1]}; "
        "the auditor must record evidence in a workflow artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == "PASS"


@pytest.mark.parametrize("participle", ["recorded", "supplied", "left"])
@pytest.mark.parametrize("position", ["before", "after"])
@pytest.mark.parametrize("quantifier,conjunction", [("both", "and"), ("either", "or")])
@pytest.mark.parametrize("agent_first", [False, True])
@pytest.mark.parametrize("actor", ["UI", "reviewer"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_passive_both_preposition_order_retains_actor_and_destinations(
    participle, position, quantifier, conjunction, agent_first, actor, reverse, governor
):
    destinations = ["the PR body panel", "a PR comment"]
    if reverse:
        destinations.reverse()
    target = (
        quantifier + " in " if position == "before" else "in " + quantifier + " "
    ) + f" {conjunction} in ".join(destinations)
    predicate = f"Evidence {governor} be {participle} "
    criterion = predicate + (
        f"by the {actor} {target}" if agent_first else f"{target} by the {actor}"
    )
    expected = (
        ({"comments"} if actor == "UI" else {"body", "comments"}) if governor == "must" else set()
    )
    assert verifier._required_evidence_channels(criterion) == expected
    options = (
        [{"body"}, {"comments"}]
        if governor == "must" and actor == "reviewer" and quantifier == "either"
        else [expected]
    )
    assert {frozenset(option) for option in verifier._required_evidence_options(criterion)} == {
        frozenset(option) for option in options
    }
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body="present", comments=missing) == (
            "CONCERNS"
            if "comments" in expected and not (actor == "reviewer" and quantifier == "either")
            else "PASS"
        )


@pytest.mark.parametrize("destination", ["the PR body", "a PR comment"])
@pytest.mark.parametrize("component", ["", " panel"])
@pytest.mark.parametrize("relative", ["which must contain command output", "that is available"])
@pytest.mark.parametrize("separator", ["\n\n", "\n \n", "\r\n\r\n"])
def test_relative_normalization_does_not_join_blank_paragraphs(
    destination, component, relative, separator
):
    criterion = "The UI may generate evidence in " + destination + component + separator + relative
    assert verifier._normalize_relative_review_presence(criterion) == criterion


def test_relative_normalization_retains_soft_wrap_and_quoted_paragraph_controls():
    soft_wrap = "The PR body\nwhich must contain command output"
    assert verifier._normalize_relative_review_presence(soft_wrap) == (
        "The PR body; PR body must contain command output"
    )
    quoted = 'The parser recognizes "PR body\n\nwhich must contain command output"'
    assert verifier._normalize_relative_review_presence(quoted) == quoted


@pytest.mark.parametrize("actor", ["UI", "service used by users", "UI used by users"])
@pytest.mark.parametrize(
    "operation,perfect,progressive",
    [
        ("record", "recorded", "recording"),
        ("supply", "supplied", "supplying"),
        ("leave", "left", "leaving"),
    ],
)
@pytest.mark.parametrize(
    "form",
    [
        "ordinary",
        "perfect",
        "progressive",
        "capability",
        "qualified-user",
        "qualified-reviewer",
        "permit",
        "let",
    ],
)
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
def test_repeated_product_predicate_shares_aspect_recipient_and_qualified_actor(
    actor, operation, perfect, progressive, form, governor, coordination, reverse
):
    predicate = {
        "ordinary": operation,
        "perfect": "have " + perfect,
        "progressive": "be " + progressive,
        "capability": "allow authenticated users to " + operation,
        "qualified-user": "allow users of the UI to " + operation,
        "qualified-reviewer": "enable authorized reviewers to " + operation,
        "permit": "permit users of the UI to " + operation,
        "let": "let users of the UI " + operation,
    }[form]
    destinations = ["the PR description preview panel", "a PR comment preview panel"]
    if reverse:
        destinations.reverse()
    criterion = (
        f"The {actor} {governor} {predicate} evidence in {destinations[0]} "
        f"{coordination} {predicate} evidence in {destinations[1]}; "
        "the auditor must record evidence in a workflow artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == "PASS"


@_semantic_matrix(
    dimensions={
        "second_destination,coordination": [
            ["a PR comment panel", "and"],
            ["a PR comment panel", "or"],
            ["a PR comment", "and"],
        ],
        "second_governor": [
            "",
            "must ",
            "may ",
            "must not ",
            "is not expected to ",
            "is not supposed to ",
            "is no longer required to ",
        ],
        "first_governor": [
            "must",
            "may",
            "must not",
            "is not expected to",
            "is not supposed to",
            "is no longer required to",
        ],
        "first_destination": [
            "in the PR body panel",
            "in the database",
            "to clients",
            "to users of the UI",
        ],
        "actor": ["UI", "service"],
    },
    semantic=(
        "second_destination,coordination",
        "second_governor",
        "first_governor",
        "first_destination",
    ),
    lexical_spines={"actor": ("second_governor", "first_governor")},
)
def test_product_coordination_preserves_recipients_and_explicit_governor_reset(
    actor, first_destination, first_governor, second_governor, second_destination, coordination
):
    criterion = (
        f"The {actor} {first_governor} record evidence {first_destination} "
        f"{coordination} {second_governor}record evidence in {second_destination}; "
        "the auditor must record evidence in a workflow artifact"
    )
    effective_governor = second_governor.strip() or first_governor
    expected = {"artifacts"} | (
        {"comments"}
        if second_destination == "a PR comment" and effective_governor == "must"
        else set()
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(criterion, body=missing, comments=missing) == (
            "CONCERNS" if "comments" in expected else "PASS"
        )


@pytest.mark.parametrize(
    "operation,participle",
    [
        ("record", "recorded"),
        ("capture", "captured"),
        ("generate", "generated"),
        ("leave", "left"),
        ("prove", "proved"),
        ("upload", "uploaded"),
        ("publish", "published"),
        ("share", "shared"),
        ("supply", "supplied"),
    ],
)
@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize("actor", ["UI", "service"])
@pytest.mark.parametrize("destination", ["in the database", "to authorized clients of the UI"])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
@pytest.mark.parametrize("independent_comment", [False, True])
def test_product_delivery_operations_share_storage_recipient_and_voice_guards(
    operation, participle, voice, actor, destination, governor, independent_comment
):
    if voice == "active":
        criterion = f"The {actor} {governor} {operation} evidence {destination}"
    elif voice == "agent-before":
        criterion = f"Evidence {governor} be {participle} by the {actor} {destination}"
    else:
        criterion = f"Evidence {governor} be {participle} {destination} by the {actor}"
    criterion += "; the auditor must record evidence in a workflow artifact"
    if independent_comment:
        criterion += "; the reviewer must record evidence in a PR comment"
    expected = {"artifacts"} | ({"comments"} if independent_comment else set())
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    for missing in ("absent", "unavailable"):
        assert (
            _floor_verdict(
                criterion,
                body=missing,
                comments="present",
                overall=missing,
            )
            == "PASS"
        )


@pytest.mark.parametrize(
    "operation,participle", [("record", "recorded"), ("supply", "supplied"), ("leave", "left")]
)
@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize(
    "destination,other",
    [
        ("the PR body", "a PR comment"),
        ("the PR description", "a PR comment"),
        ("a PR comment", "the PR body"),
    ],
)
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("condition", ["if available", "only when produced"])
@pytest.mark.parametrize("component", [False, True])
def test_availability_first_final_retains_parent_condition(
    operation, participle, voice, destination, other, coordination, reverse, condition, component
):
    relative = destination + (" panel" if component else "") + " that is available"
    members = [relative, other]
    if reverse:
        members.reverse()
    target = f" {coordination} in ".join(members)
    actor = "UI" if component else "reviewer"
    if voice == "active":
        criterion = f"The {actor} must {operation} evidence in {target} {condition}"
    elif voice == "agent-before":
        criterion = f"Evidence must be {participle} by the {actor} in {target} {condition}"
    else:
        criterion = f"Evidence must be {participle} in {target} by the {actor} {condition}"
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"}
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    fixture = _COVERAGE_FIXTURE
    for missing in ("absent", "unavailable"):
        for present in (set(), {"body"}, {"comments"}, {"body", "comments"}):
            context, _ = fixture._context(1, 1000, 1000)
            evidence = (
                "- Overall retrieval status: **present**\n"
                + f"- PR body: **{'present' if 'body' in present else missing}**\n"
                + f"- PR comments: **{'present' if 'comments' in present else missing}**\n"
                + "- Referenced workflow artifacts: **present**"
            )
            context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
                "## PR Diff Summary",
                "## Acceptance evidence\n\n" + evidence + "\n\n## PR Diff Summary",
            )
            result = verifier._apply_coverage_floor(
                verifier.EvaluationResult(verdict="PASS", used_llm=True),
                verifier.prompt_coverage(context, None),
            )
            assert result.verdict == "PASS"


@pytest.mark.parametrize(
    "operation,participle", [("record", "recorded"), ("supply", "supplied"), ("leave", "left")]
)
@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize(
    "destination,channel,other",
    [
        ("the PR body", "body", "a PR comment"),
        ("the PR description", "body", "a PR comment"),
        ("a PR comment", "comments", "the PR body"),
    ],
)
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("condition", ["if available", "only if available", "when produced"])
@pytest.mark.parametrize("component", [False, True])
@pytest.mark.parametrize("local_condition", [False, True])
def test_relative_qualifier_preserves_parent_and_local_condition_scope(
    operation,
    participle,
    voice,
    destination,
    channel,
    other,
    coordination,
    condition,
    component,
    local_condition,
):
    target = destination + (
        " panel that is available" if component else " that must contain command output"
    )
    if local_condition:
        target += " if available"
    target += f" {coordination} in {other}"
    actor = "UI" if component else "reviewer"
    if voice == "active":
        criterion = f"The {actor} must {operation} evidence in {target} {condition}"
    elif voice == "agent-before":
        criterion = f"Evidence must be {participle} by the {actor} in {target} {condition}"
    else:
        criterion = f"Evidence must be {participle} in {target} by the {actor} {condition}"
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {"artifacts"} | ({channel} if not component and not local_condition else set())
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    fixture = _COVERAGE_FIXTURE
    for missing in ("absent", "unavailable"):
        for present in (set(), {"body"}, {"comments"}, {"body", "comments"}):
            evidence = (
                "- Overall retrieval status: **present**\n"
                f"- PR body: **{'present' if 'body' in present else missing}**\n"
                f"- PR comments: **{'present' if 'comments' in present else missing}**\n"
                "- Referenced workflow artifacts: **present**"
            )
            context, _ = fixture._context(1, 1000, 1000)
            context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
                "## PR Diff Summary",
                "## Acceptance evidence\n\n" + evidence + "\n\n## PR Diff Summary",
            )
            result = verifier._apply_coverage_floor(
                verifier.EvaluationResult(verdict="PASS", used_llm=True),
                verifier.prompt_coverage(context, None),
            )
            assert result.verdict == (
                "PASS" if expected <= (present | {"artifacts"}) else "CONCERNS"
            )


@pytest.mark.parametrize("actor", ["UI", "application", "service", "renderer"])
@pytest.mark.parametrize("operation", ["recorded", "supplied", "left"])
@pytest.mark.parametrize("voice", ["agent-before", "agent-after"])
@pytest.mark.parametrize(
    "destination,channel,other,other_channel",
    [
        ("the PR body", "body", "a PR comment", "comments"),
        ("the PR description", "body", "a PR comment", "comments"),
        ("a PR comment", "comments", "the PR body", "body"),
    ],
)
@pytest.mark.parametrize("quantifier", ["both", "either"])
def test_passive_destination_quantifier_retains_bare_sibling(
    actor, operation, voice, destination, channel, other, other_channel, quantifier
):
    coordination = "and" if quantifier == "both" else "or"
    target = f"in {quantifier} {destination} panel {coordination} in {other}"
    criterion = (
        f"Evidence must be {operation} by the {actor} {target}"
        if voice == "agent-before"
        else f"Evidence must be {operation} {target} by the {actor}"
    )
    criterion += "; the auditor must record evidence in a workflow artifact"
    expected = {other_channel, "artifacts"}
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    fixture = _COVERAGE_FIXTURE
    for missing in ("absent", "unavailable"):
        context, _ = fixture._context(1, 1000, 1000)
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
            "## PR Diff Summary",
            "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
            + f"- PR body: **{missing}**\n- PR comments: **{missing}**\n"
            + "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
        )
        result = verifier._apply_coverage_floor(
            verifier.EvaluationResult(verdict="PASS", used_llm=True),
            verifier.prompt_coverage(context, None),
        )
        assert result.verdict == "CONCERNS"


@_semantic_matrix(
    dimensions={
        "independent": [False, True],
        "capability": [False, True],
        "component": ["panel", "editor", "field"],
        "destination": ["the PR body", "the PR description", "a PR comment"],
        "operation": [
            "prove",
            "provide",
            "return",
            "display",
            "show",
            "emit",
            "render",
            "expose",
            "store",
            "upload",
            "attach",
            "publish",
            "post",
            "record",
            "capture",
            "include",
            "contain",
            "have",
            "document",
            "generate",
            "link",
            "add",
            "leave",
        ],
        "actor": ["UI", "application", "service", "renderer"],
    },
    semantic=("independent", "capability", "component", "destination"),
    lexical_spines={
        "operation": ("capability", "component", "destination"),
        "actor": ("capability", "destination"),
    },
)
def test_product_generation_uses_shared_delivery_operations(
    actor, operation, destination, component, capability, independent
):
    predicate = f"must let users {operation}" if capability else f"must {operation}"
    criterion = f"The {actor} {predicate} evidence in {destination} {component}"
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert not verifier._required_evidence_is_missing(
        "- Overall retrieval status: **present**\n- PR body: **absent**\n"
        "- PR comments: **absent**\n- Referenced workflow artifacts: **present**",
        expected,
    )


def _product_component_case(
    actor,
    operation,
    product_channel,
    body_alias,
    reverse,
    coordination,
    independent,
    governor,
    condition,
    voice,
):
    members = (
        [f"the PR {body_alias} panel", "a PR comment"]
        if product_channel == "body"
        else ["a PR comment panel", f"the PR {body_alias}"]
    )
    if reverse:
        members.reverse()
    destination = f" {coordination} ".join(members)
    participle = {
        "generate": "generated",
        "link": "linked",
        "post": "posted",
        "record": "recorded",
        "prove": "proved",
        "leave": "left",
    }[operation]
    if voice == "active":
        criterion = f"The {actor} {governor} {operation} evidence in {destination}{condition}"
    elif voice == "active-perfect":
        criterion = f"The {actor} {governor} have {participle} evidence in {destination}{condition}"
    elif voice == "active-progressive":
        progressive = operation[:-1] + "ing" if operation.endswith("e") else operation + "ing"
        criterion = f"The {actor} {governor} be {progressive} evidence in {destination}{condition}"
    elif voice == "agent-before":
        criterion = (
            f"Evidence {governor} be {participle} by the {actor} in {destination}{condition}"
        )
    else:
        criterion = (
            f"Evidence {governor} be {participle} in {destination} by the {actor}{condition}"
        )
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    bare_channel = "comments" if product_channel == "body" else "body"
    required = governor == "must" and not condition
    expected = ({bare_channel} if required else set()) | ({"artifacts"} if independent else set())
    return criterion, expected, required


@_semantic_matrix(
    dimensions={
        "voice": ["active", "active-perfect", "active-progressive", "agent-before", "agent-after"],
        "condition": ["", " if available"],
        "governor": ["must", "may", "must not"],
        "independent": [False, True],
        "coordination": ["and", "or"],
        "reverse": [False, True],
        "body_alias": ["body", "description"],
        "product_channel": ["body", "comments"],
        "operation": ["generate", "link", "post", "record", "prove", "leave"],
        "actor": ["UI", "service"],
    },
    semantic=(
        "voice",
        "condition",
        "governor",
        "independent",
        "coordination",
        "reverse",
        "product_channel",
    ),
    lexical_spines={
        "operation": ("voice", "governor", "product_channel"),
        "actor": ("voice", "governor", "product_channel"),
        "body_alias": ("product_channel", "reverse", "coordination"),
    },
)
def test_product_component_coordination_preserves_bare_other_channel(
    actor,
    operation,
    product_channel,
    body_alias,
    reverse,
    coordination,
    independent,
    governor,
    condition,
    voice,
):
    criterion, expected, _ = _product_component_case(
        actor,
        operation,
        product_channel,
        body_alias,
        reverse,
        coordination,
        independent,
        governor,
        condition,
        voice,
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]


@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
@pytest.mark.parametrize("condition", ["", " if available"])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize("product_channel", ["body", "comments"])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
def test_product_component_coordination_real_floor(
    voice, governor, condition, independent, product_channel, coordination, reverse
):
    """Retain missing-evidence enforcement across every semantic result state.

    Lexical morphology is exercised by the classifier matrix above. The full
    prompt path receives the resulting requirement and retrieval states here.
    """
    criterion, _, required = _product_component_case(
        "UI",
        "generate",
        product_channel,
        "body",
        reverse,
        coordination,
        independent,
        governor,
        condition,
        voice,
    )
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        "- PR body: **absent**\n- PR comments: **absent**\n"
        "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if required else "PASS")


@_semantic_matrix(
    dimensions={
        "aspect": ["be", "have been", "have been being"],
        "position": ["agent-before", "agent-after"],
        "component": ["", " settings panel"],
        "destination,channel": [
            ["the PR body", "body"],
            ["the PR description", "body"],
            ["a PR comment", "comments"],
        ],
        "governor": ["must", "may", "must not", "is not expected to"],
        "object_": ["Evidence", "Command output"],
        "operation": ["posted", "generated", "recorded", "linked"],
        "actor": ["reviewer", "assigned reviewer", "UI", "service"],
    },
    semantic=("aspect", "position", "component", "destination,channel", "governor", "actor"),
    lexical_spines={"operation": ("actor", "aspect", "governor"), "object_": ("actor", "aspect")},
)
def test_passive_delivery_agent_position_preserves_actor_and_floor(
    actor, operation, object_, governor, destination, channel, component, position, aspect
):
    if position == "agent-before":
        criterion = (
            f"{object_} {governor} {aspect} {operation} by the {actor} in {destination}{component}"
        )
    else:
        criterion = (
            f"{object_} {governor} {aspect} {operation} in {destination}{component} by the {actor}"
        )
    required = governor == "must" and not (component and actor in {"UI", "service"})
    expected = {channel} if required else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert (
        verifier._required_evidence_is_missing(
            "- Overall retrieval status: **present**\n- PR body: **absent**\n"
            "- PR comments: **absent**\n- Referenced workflow artifacts: **present**",
            expected,
        )
        == required
    )


@_semantic_matrix(
    dimensions={
        "missing": ["absent", "unavailable"],
        "independent": [False, True],
        "governor": ["must", "may", "must not"],
        "shape": ["single", "human-and", "human-or", "product-and", "product-or"],
        "position": ["agent-before", "agent-after"],
        "destination,channel,other,other_channel": [
            ["the PR body", "body", "a PR comment", "comments"],
            ["the PR description", "body", "a PR comment", "comments"],
            ["a PR comment", "comments", "the PR body", "body"],
        ],
        "operation": [
            "recorded",
            "supplied",
            "shared",
            "written",
            "placed",
            "delivered",
            "submitted",
            "pasted",
            "put",
        ],
    },
    semantic=(
        "missing",
        "independent",
        "governor",
        "shape",
        "position",
        "destination,channel,other,other_channel",
    ),
    lexical_spines={"operation": ("shape", "governor", "position")},
)
def test_passive_aliases_preserve_actor_options_and_actual_floor(
    operation,
    destination,
    channel,
    other,
    other_channel,
    position,
    shape,
    governor,
    independent,
    missing,
):
    actor = "UI" if shape.startswith("product") else "reviewer"
    target = destination + (" panel" if actor == "UI" else "")
    if shape != "single":
        target += " " + shape.split("-")[1] + " " + other
    tail = (
        f"by the {actor} in {target}"
        if position == "agent-before"
        else f"in {target} by the {actor}"
    )
    criterion = f"Evidence {governor} be {operation} {tail}"
    artifact = {"artifacts"} if independent else set()
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
    if governor != "must":
        expected = [artifact]
    elif actor == "UI":
        expected = [{other_channel} | artifact]
    elif shape == "human-or":
        expected = [{channel} | artifact, {other_channel} | artifact]
    elif shape == "human-and":
        expected = [{channel, other_channel} | artifact]
    else:
        expected = [{channel} | artifact]
    assert verifier._required_evidence_channels(criterion) == set().union(*expected)
    assert {frozenset(option) for option in verifier._required_evidence_options(criterion)} == {
        frozenset(option) for option in expected
    }
    fixture = _COVERAGE_FIXTURE
    for present in (set(), {"body"}, {"comments"}, {"body", "comments"}):
        evidence = (
            "- Overall retrieval status: **present**\n"
            f"- PR body: **{'present' if 'body' in present else missing}**\n"
            f"- PR comments: **{'present' if 'comments' in present else missing}**\n"
            "- Referenced workflow artifacts: **present**"
        )
        context, _ = fixture._context(1, 1000, 1000)
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
            "## PR Diff Summary", "## Acceptance evidence\n\n" + evidence + "\n\n## PR Diff Summary"
        )
        result = verifier._apply_coverage_floor(
            verifier.EvaluationResult(verdict="PASS", used_llm=True),
            verifier.prompt_coverage(context, None),
        )
        satisfied = any(option <= (present | {"artifacts"}) for option in expected)
        assert result.verdict == ("PASS" if satisfied else "CONCERNS")


@_semantic_matrix(
    dimensions={
        "missing": ["absent", "unavailable"],
        "independent": [False, True],
        "governor": ["must", "may", "must not"],
        "availability": ["", " that is available", " that must always remain available"],
        "reverse": [False, True],
        "coordination": ["and", "or"],
        "destination,channel,other,other_channel": [
            ["the PR body", "body", "a PR comment", "comments"],
            ["the PR description", "body", "a PR comment", "comments"],
            ["a PR comment", "comments", "the PR body", "body"],
        ],
        "voice": ["active", "agent-before", "agent-after"],
        "operation": ["record", "supply", "leave"],
    },
    semantic=(
        "missing",
        "independent",
        "governor",
        "availability",
        "reverse",
        "coordination",
        "destination,channel,other,other_channel",
        "voice",
    ),
    lexical_spines={"operation": ("voice", "governor", "availability")},
)
def test_component_availability_preserves_bare_sibling_and_passive_actor(
    operation,
    voice,
    destination,
    channel,
    other,
    other_channel,
    coordination,
    reverse,
    availability,
    governor,
    independent,
    missing,
):
    members = [destination + " settings panel" + availability, other]
    if reverse:
        members.reverse()
    target = f" {coordination} in ".join(members)
    participle = {"record": "recorded", "supply": "supplied", "leave": "left"}[operation]
    if voice == "active":
        criterion = f"The UI {governor} {operation} evidence in {target}"
    elif voice == "agent-before":
        criterion = f"Evidence {governor} be {participle} by the UI in {target}"
    else:
        criterion = f"Evidence {governor} be {participle} in {target} by the UI"
    expected = {other_channel} if governor == "must" else set()
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
        expected.add("artifacts")
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    fixture = _COVERAGE_FIXTURE
    for present in (set(), {"body"}, {"comments"}, {"body", "comments"}):
        evidence = (
            "- Overall retrieval status: **present**\n"
            f"- PR body: **{'present' if 'body' in present else missing}**\n"
            f"- PR comments: **{'present' if 'comments' in present else missing}**\n"
            "- Referenced workflow artifacts: **present**"
        )
        context, _ = fixture._context(1, 1000, 1000)
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
            "## PR Diff Summary", "## Acceptance evidence\n\n" + evidence + "\n\n## PR Diff Summary"
        )
        result = verifier._apply_coverage_floor(
            verifier.EvaluationResult(verdict="PASS", used_llm=True),
            verifier.prompt_coverage(context, None),
        )
        assert result.verdict == ("PASS" if expected <= (present | {"artifacts"}) else "CONCERNS")


@pytest.mark.parametrize("operation", ["record", "supply", "leave"])
@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize(
    "destination,channel,other,other_channel",
    [
        ("the PR body", "body", "a PR comment", "comments"),
        ("the PR description", "body", "a PR comment", "comments"),
        ("a PR comment", "comments", "the PR body", "body"),
    ],
)
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_component_availability_comma_retains_actual_floor(
    operation, voice, destination, channel, other, other_channel, reverse, coordination, governor
):
    for availability in (", that is available", ", which must always remain available"):
        test_component_availability_preserves_bare_sibling_and_passive_actor(
            operation,
            voice,
            destination,
            channel,
            other,
            other_channel,
            coordination,
            reverse,
            availability,
            governor,
            True,
            "unavailable",
        )


@pytest.mark.parametrize("operation", ["record", "supply", "leave"])
@pytest.mark.parametrize("voice", ["active", "agent-before", "agent-after"])
@pytest.mark.parametrize(
    "destination,channel,other,other_channel",
    [
        ("the PR body", "body", "a PR comment", "comments"),
        ("the PR description", "body", "a PR comment", "comments"),
        ("a PR comment", "comments", "the PR body", "body"),
    ],
)
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
@pytest.mark.parametrize("missing", ["absent", "unavailable"])
def test_component_relative_presence_preserves_parent_actual_floor(
    operation,
    voice,
    destination,
    channel,
    other,
    other_channel,
    reverse,
    coordination,
    governor,
    missing,
):
    for attachment in (
        " that may contain command output",
        " that must contain command output",
        " that must not contain command output",
        " that must contain command output if available",
    ):
        test_component_availability_preserves_bare_sibling_and_passive_actor(
            operation,
            voice,
            destination,
            channel,
            other,
            other_channel,
            coordination,
            reverse,
            attachment,
            governor,
            True,
            missing,
        )


@pytest.mark.parametrize("actor", ["reviewer", "service"])
@pytest.mark.parametrize(
    "operation",
    [
        "providing",
        "generating",
        "proving",
        "exposing",
        "storing",
        "including",
        "capturing",
        "leaving",
        "having",
    ],
)
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("the PR description", "body"), ("a PR comment", "comments")],
)
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_active_progressive_delivery_inflections(actor, operation, destination, channel, governor):
    criterion = f"The {actor} {governor} be {operation} evidence in {destination}"
    expected = {channel} if governor == "must" else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert verifier._required_evidence_is_missing(
        "- Overall retrieval status: **present**\n- PR body: **absent**\n"
        "- PR comments: **absent**\n- Referenced workflow artifacts: **present**",
        expected,
    ) == bool(expected)


@pytest.mark.parametrize("governor", ["must not", "may", "is not expected to"])
@pytest.mark.parametrize("relative", ["that", "which"])
@pytest.mark.parametrize(
    "predicate",
    [
        "must contain",
        "must include",
        "must have",
        "may contain",
        "must not contain",
        "is not expected to contain",
    ],
)
@pytest.mark.parametrize(
    "destination,channel,other",
    [
        ("the PR body", "body", "a PR comment"),
        ("the PR description", "body", "a PR comment"),
        ("a PR comment", "comments", "the PR body"),
    ],
)
@pytest.mark.parametrize("coordination", ["and", "or"])
def test_independent_relative_body_presence_after_nonmandatory_delivery(
    governor, relative, predicate, destination, channel, other, coordination
):
    criterion = f"The reviewer {governor} record evidence in {other} {coordination} {destination} {relative} {predicate} command output"
    expected = {channel} if predicate in {"must contain", "must include", "must have"} else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert verifier._required_evidence_is_missing(
        "- Overall retrieval status: **present**\n- PR body: **absent**\n"
        "- PR comments: **absent**\n- Referenced workflow artifacts: **present**",
        expected,
    ) == bool(expected)


@pytest.mark.parametrize("relative", ["that", "which"])
@pytest.mark.parametrize(
    "destination,channel,other,other_channel",
    [
        ("the PR body", "body", "a PR comment", "comments"),
        ("the PR description", "body", "a PR comment", "comments"),
        ("a PR comment", "comments", "the PR body", "body"),
    ],
)
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("predicate", ["must contain", "may contain", "must not contain"])
@pytest.mark.parametrize("first", [False, True])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize(
    "condition",
    ["", " if available", ", when present", " only if available", " solely when present"],
)
def test_relative_presence_preserves_parent_mandatory_alternatives(
    relative,
    destination,
    channel,
    other,
    other_channel,
    coordination,
    predicate,
    first,
    independent,
    condition,
):
    relative_destination = f"{destination} {relative} {predicate} command output{condition}"
    members = [relative_destination, "in " + other] if first else [other, relative_destination]
    criterion = "The reviewer must record evidence in " + f" {coordination} ".join(members)
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
    options = verifier._required_evidence_options(criterion)
    if independent:
        assert all("artifacts" in option for option in options)
    statuses = (set(), {channel}, {other_channel}, {channel, other_channel})
    for present in statuses:
        satisfied = (bool(present) if coordination == "or" else len(present) == 2) and (
            predicate != "must contain" or bool(condition) or channel in present
        )
        evidence = (
            "- Overall retrieval status: **present**\n"
            f"- PR body: **{'present' if 'body' in present else 'absent'}**\n"
            f"- PR comments: **{'present' if 'comments' in present else 'absent'}**\n"
            "- Referenced workflow artifacts: **present**"
        )
        assert (
            any(not verifier._required_evidence_is_missing(evidence, option) for option in options)
            == satisfied
        )


def test_negative_content_condition_does_not_migrate_to_parent_delivery():
    criterion = (
        "The reviewer must record evidence in a PR comment and the PR body "
        "that must not contain command output if available"
    )
    assert verifier._normalize_review_content_qualifiers(criterion) == (
        "The reviewer must record evidence in a PR comment and the PR body"
    )
    assert verifier._required_evidence_options(criterion) == [{"body", "comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


def test_negative_content_keeps_condition_after_complete_parent_list():
    criterion = (
        "The reviewer must record evidence in the PR body that must not contain "
        "command output and in a PR comment if available"
    )
    assert verifier._normalize_review_content_qualifiers(criterion) == (
        "The reviewer must record evidence in the PR body and in a PR comment if available"
    )
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize(
    "qualifier",
    [
        "may contain command output",
        "must contain command output",
        "must not contain command output",
        "may contain command output if available",
        "must contain command output if available",
        "must always remain available",
        "is currently available",
    ],
)
@pytest.mark.parametrize("first", [False, True])
@pytest.mark.parametrize("actor,operation", [("reviewer", "record"), ("UI", "generate")])
@pytest.mark.parametrize(
    "destination,channel,other,other_channel",
    [
        ("the PR body", "body", "a PR comment", "comments"),
        ("the PR description", "body", "a PR comment", "comments"),
        ("a PR comment", "comments", "the PR body", "body"),
    ],
)
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("independent", [False, True])
def test_comma_relative_attachments_preserve_parent_floor(
    qualifier,
    first,
    actor,
    operation,
    destination,
    channel,
    other,
    other_channel,
    coordination,
    independent,
):
    attached = f"{destination}, which {qualifier}"
    members = [attached + ",", "in " + other] if first else [other, attached]
    criterion = f"The {actor} must {operation} evidence in " + f" {coordination} ".join(members)
    if independent:
        criterion += "; the auditor must record evidence in a workflow artifact"
    options = verifier._required_evidence_options(criterion)
    if independent:
        assert all("artifacts" in option for option in options)
    for present in (set(), {channel}, {other_channel}, {channel, other_channel}):
        satisfied = (bool(present) if coordination == "or" else len(present) == 2) and (
            qualifier != "must contain command output" or channel in present
        )
        evidence = (
            "- Overall retrieval status: **present**\n"
            f"- PR body: **{'present' if 'body' in present else 'absent'}**\n"
            f"- PR comments: **{'present' if 'comments' in present else 'absent'}**\n"
            "- Referenced workflow artifacts: **present**"
        )
        assert (
            any(not verifier._required_evidence_is_missing(evidence, option) for option in options)
            == satisfied
        )


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
@pytest.mark.parametrize("position", ["direct", "before", "after"])
@pytest.mark.parametrize("relative", ["that", "which"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("the PR body", "body"), ("the PR description", "body")],
)
@pytest.mark.parametrize("independent", [False, True])
def test_relative_additive_adjective_does_not_erase_delivery(
    contrast, position, relative, destination, channel, independent
):
    before = "currently " if position == "before" else ""
    after = "currently " if position == "after" else ""
    criterion = (
        f"- [ ] Test evidence in {destination} {relative} is not {before}{contrast} {after}required"
    )
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    expected = {channel} | ({"artifacts"} if independent else set())
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]


@pytest.mark.parametrize("relative", ["that", "which"])
@pytest.mark.parametrize("adjective", ["required", "expected", "supposed", "permitted"])
@pytest.mark.parametrize("negative", ["not", "never", "no longer"])
@pytest.mark.parametrize("adverb", ["now", "currently"])
@pytest.mark.parametrize("position", ["before-copula", "after-copula", "after-negative"])
@pytest.mark.parametrize("destination", ["a PR comment", "the PR body", "the PR description"])
@pytest.mark.parametrize("independent", [False, True])
def test_relative_negative_adjective_shares_internal_adverbs(
    relative, adjective, negative, adverb, position, destination, independent
):
    before = adverb + " " if position == "before-copula" else ""
    after = adverb + " " if position == "after-copula" else ""
    internal = adverb + " " if position == "after-negative" else ""
    criterion = f"- [ ] Test evidence in {destination} {relative} {before}is {after}{negative} {internal}{adjective}"
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    if adjective == "required" and negative == "not":
        fixture = _COVERAGE_FIXTURE
        context, _ = fixture._context(1, 1000, 1000)
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
            "## PR Diff Summary",
            "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
            "- PR body: **absent**\n- PR comments: **absent**\n"
            "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
        )
        result = verifier._apply_coverage_floor(
            verifier.EvaluationResult(verdict="PASS", used_llm=True),
            verifier.prompt_coverage(context, None),
        )
        assert result.verdict == "PASS"


@pytest.mark.parametrize("operation", ["link", "generate", "post"])
@pytest.mark.parametrize("body_alias", ["body", "description"])
@pytest.mark.parametrize("component", ["", " panel"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("proof", ["evidence", "test results"])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize("governor", ["must", "may", "must not", "is not expected to"])
def test_body_delivery_uses_shared_operation_and_polarity(
    operation, body_alias, component, reverse, proof, independent, governor
):
    destinations = [f"the PR {body_alias}{component}", "a PR comment"]
    if reverse:
        destinations.reverse()
    criterion = f"- [ ] The assigned reviewer {governor} {operation} {proof} in " + " and ".join(
        destinations
    )
    if independent:
        criterion += "; the maintainer must record evidence in a workflow artifact"
    expected = ({"body", "comments"} if governor == "must" else set()) | (
        {"artifacts"} if independent else set()
    )
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]

    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        "- PR body: **absent**\n- PR comments: **present**\n"
        "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if governor == "must" else "PASS")


@pytest.mark.parametrize("qualifier", ["only if tests fail", "currently not required"])
@pytest.mark.parametrize("modifier", ["", "also ", "now ", "explicitly "])
@pytest.mark.parametrize("independent", [False, True])
def test_qualified_checklist_does_not_split_following_product_capability(
    qualifier, modifier, independent
):
    criterion = (
        f"- [ ] Test evidence in a PR comment {qualifier}; "
        f"the UI lets users submit evidence and {modifier}lets clients post PR comments"
    )
    if independent:
        criterion += "; the reviewer must upload validation artifacts to the PR"
    assert verifier._required_evidence_channels(criterion) == (
        {"artifacts"} if independent else set()
    )


@pytest.mark.parametrize(
    "destination", ["a PR comment", "the PR description", "a workflow artifact"]
)
@pytest.mark.parametrize("separator", ["\n", "\n\n"])
def test_checklist_noun_destination_paragraph_boundary(destination, separator):
    criterion = f"- [ ]\nEvidence{separator}in {destination}."
    channels = {
        "a PR comment": "comments",
        "the PR description": "body",
        "a workflow artifact": "artifacts",
    }
    assert verifier._required_evidence_channels(criterion) == (
        {channels[destination]} if separator == "\n" else {"overall"}
    )


@pytest.mark.parametrize("newline", ["\n", "\n\n"])
@pytest.mark.parametrize("checked", [" ", "x"])
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("a PR comment", "comments"),
        ("the PR description", "body"),
        ("a workflow artifact", "artifacts"),
    ],
)
def test_checklist_immediate_continuation_not_blank_paragraph(
    newline, checked, destination, channel
):
    criterion = f"- [{checked}]{newline}Evidence in {destination}."
    assert verifier._required_evidence_channels(criterion) == (
        {channel} if newline == "\n" else set()
    )
    assert "comments" in verifier._required_evidence_channels(
        criterion + "; provide command output in a PR comment"
    )


@pytest.mark.parametrize("obligation", ["allowed", "permitted"])
@pytest.mark.parametrize(
    "destination", ["a PR comment", "the PR description", "a workflow artifact"]
)
def test_bare_negative_evidence_presence_allowed_permitted(obligation, destination):
    criterion = f"- [ ] Evidence is not {obligation} in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; provide command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("component", ["editor", "field", "textarea", "preview"])
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("operator", ["and", "or"])
@pytest.mark.parametrize("either", ["", "either "])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize(
    "governor",
    [
        "may",
        "can",
        "could",
        "would",
        "should",
        "must not",
        "is not expected to",
        "is no longer required to",
    ],
)
def test_component_alternatives_preserve_optional_negative_floor(
    component, destination, operator, either, independent, governor
):
    criterion = f"- [ ] Evidence {governor} be {either}in the {destination} {component} {operator} a PR comment"
    if independent:
        criterion += "; provide command output in a PR comment"
    options = verifier._required_evidence_options(criterion)
    assert options == ([{"comments"}] if independent else [set()])
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **absent**\n"
        "- PR body: **absent**\n- PR comments: **absent**\n"
        "- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if independent else "PASS")


@pytest.mark.parametrize(
    "component", ["editor", "field", "textarea", "preview", "panel", "section", "tab", "widget"]
)
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("independent", [False, True])
def test_review_body_product_components_do_not_create_delivery(component, destination, independent):
    criterion = f"- [ ] The UI must display test results in the {destination} {component}"
    if independent:
        criterion += "; provide command output in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize("component", ["panel", "section", "tab", "widget"])
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
def test_human_delivery_to_structural_component_remains_required(component, destination):
    criterion = f"- [ ] The reviewer must post test evidence in the {destination} {component}"
    assert verifier._required_evidence_channels(criterion) == {"body"}


@pytest.mark.parametrize("continuation", ["before merge", "today", "daily"])
def test_temporal_body_continuation_is_not_product_component(continuation):
    criterion = f"- [ ] The UI must display test results in the PR description {continuation}"
    assert verifier._required_evidence_channels(criterion) == {"body"}


@pytest.mark.parametrize("component", ["", "field", "settings panel", "results section"])
@pytest.mark.parametrize(
    "continuation",
    [
        "before merge",
        "after approval",
        "today",
        "daily",
        "that reviewers can inspect",
        "which reviewers can inspect",
        "where reviewers can inspect",
    ],
)
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("actor,operation", [("UI", "display"), ("reviewer", "post")])
@pytest.mark.parametrize("independent", [False, True])
def test_component_temporal_boundary_preserves_bare_and_independent_delivery(
    component, continuation, destination, actor, operation, independent
):
    criterion = (
        f"- [ ] The {actor} must {operation} test results in the "
        f"{destination} {component} {continuation}"
    )
    expected = set() if actor == "UI" and component else {"body"}
    if independent:
        criterion += "; the reviewer must provide command output in a PR comment"
        expected.add("comments")
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        "- PR body: **absent**\n- PR comments: **present**\n"
        "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if "body" in expected else "PASS")


@pytest.mark.parametrize("component", ["field", "textarea", "preview", "panel"])
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("governor", ["may", "can", "could", "must"])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("channel", ["comments", "artifacts"])
@pytest.mark.parametrize("independent", [False, True])
def test_product_coordination_preserves_optional_modality(
    component, destination, governor, coordination, channel, independent
):
    other = "a PR comment" if channel == "comments" else "a workflow artifact"
    criterion = (
        f"- [ ] The UI {governor} display test results in the "
        f"{destination} {component} {coordination} {other}"
    )
    if independent:
        criterion += "; the reviewer must provide command output in a PR comment"
    expected = {channel} if governor == "must" else set()
    if independent:
        expected.add("comments")
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("component", ["field", "textarea", "preview", "panel"])
@pytest.mark.parametrize("prefix", ["", "either "])
@pytest.mark.parametrize("suffix", ["", " if available", " when produced"])
@pytest.mark.parametrize("independent", [False, True])
def test_structural_coordination_preserves_conditional_suffix(
    component, prefix, suffix, independent
):
    criterion = (
        f"- [ ] The UI must display test results in {prefix}the PR description "
        f"{component} or a PR comment{suffix}"
    )
    if independent:
        criterion += "; the reviewer must provide evidence in a workflow artifact"
    expected = set() if suffix else {"comments"}
    if independent:
        expected.add("artifacts")
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("component", ["field", "textarea", "preview", "panel"])
@pytest.mark.parametrize("actor,operation", [("UI", "display"), ("reviewer", "post")])
@pytest.mark.parametrize("ordering", ["single", "body-first", "body-last"])
@pytest.mark.parametrize("suffix", ["", " if available", " when produced"])
@pytest.mark.parametrize("independent", [False, True])
def test_structural_component_last_preserves_conditionality(
    component, actor, operation, ordering, suffix, independent
):
    body = f"the PR description {component}"
    destination = (
        body
        if ordering == "single"
        else f"{body} and a PR comment" if ordering == "body-first" else f"a PR comment and {body}"
    )
    criterion = f"- [ ] The {actor} must {operation} test results in {destination}{suffix}"
    if independent:
        criterion += "; the reviewer must provide evidence in a workflow artifact"
    expected = set()
    if not suffix:
        if actor == "reviewer":
            expected.add("body")
        if ordering != "single":
            expected.add("comments")
    if independent:
        expected.add("artifacts")
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("component", ["field", "panel", "settings panel", "results section"])
@pytest.mark.parametrize("actor,operation", [("UI", "display"), ("reviewer", "post")])
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("body_first", [False, True])
@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("condition", ["", " if available", ", if available"])
@pytest.mark.parametrize("independent", [False, True])
def test_component_options_and_actual_floor_are_order_symmetric(
    component, actor, operation, destination, body_first, coordination, condition, independent
):
    members = [f"the {destination} {component}", "a PR comment"]
    if not body_first:
        members.reverse()
    criterion = (
        f"- [ ] The {actor} must {operation} test results in either "
        + f" {coordination} ".join(members)
        + condition
    )
    if independent:
        criterion += "; the reviewer must provide evidence in a workflow artifact"
    extra = {"artifacts"} if independent else set()
    if condition:
        expected = [extra]
    elif actor == "UI":
        expected = [{"comments"} | extra]
    elif coordination == "or":
        expected = [{"body"} | extra, {"comments"} | extra]
    else:
        expected = [{"body", "comments"} | extra]
    assert {frozenset(x) for x in verifier._required_evidence_options(criterion)} == {
        frozenset(x) for x in expected
    }
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        "- PR body: **absent**\n- PR comments: **present**\n"
        "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    expected_pass = bool(condition) or actor == "UI" or coordination == "or"
    assert result.verdict == ("PASS" if expected_pass else "CONCERNS")


@pytest.mark.parametrize("marker", ["-", "*", "+", "1.", "1)"])
@pytest.mark.parametrize("proof", ["Test evidence", "Command output", "Transcripts"])
@pytest.mark.parametrize(
    "suffix",
    [
        "before merge",
        "after approval",
        "today",
        "daily",
        "that reviewers can inspect",
        "which reviewers can inspect",
        "where reviewers can inspect",
    ],
)
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("a PR comment", "comments"),
        ("the PR body", "body"),
        ("the PR description", "body"),
        ("a workflow artifact", "artifacts"),
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_temporal_checklist_shorthand_preserves_named_delivery(
    marker, proof, suffix, destination, channel, independent
):
    criterion = f"{marker} [ ] {proof} in {destination} {suffix}."
    extra = "; the reviewer must record evidence in a workflow artifact" if independent else ""
    expected = {channel} | ({"artifacts"} if independent else set())
    assert verifier._required_evidence_channels(criterion + extra) == expected
    assert verifier._required_evidence_options(criterion + extra) == [expected]
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion + extra).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        "- PR body: **absent**\n- PR comments: **absent**\n"
        "- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == "CONCERNS"
    for governor in ["may be", "is not expected to be", "is no longer required to be"]:
        negative = f"{marker} [ ] Evidence {governor} in {destination} {suffix}."
        assert verifier._required_evidence_channels(negative + extra) == (
            {"artifacts"} if independent else set()
        )


@pytest.mark.parametrize("marker", ["-", "*", "+", "1.", "1)"])
@pytest.mark.parametrize(
    "suffix",
    [
        "only if tests fail",
        "solely if tests fail",
        "currently not required",
        "currently not expected",
    ],
)
@pytest.mark.parametrize("destination", ["a PR comment", "the PR body", "the PR description"])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize("joiner", [". ", "; ", " and ", ", and ", " or ", ", or ", " but "])
def test_checklist_suffix_cannot_promote_conditional_or_negative_delivery(
    marker, suffix, destination, independent, joiner
):
    criterion = f"{marker} [ ] Test evidence in {destination} {suffix}"
    extra = (
        joiner + "the reviewer must record evidence in a workflow artifact" if independent else "."
    )
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion + extra) == expected
    assert verifier._required_evidence_options(criterion + extra) == [expected]


@_semantic_matrix(
    dimensions={
        "adverb": ["", "now ", "currently "],
        "independent": [False, True],
        "joiner": ["; ", " and ", ", and "],
        "destination": ["a PR comment", "the PR body", "the PR description"],
        "predicate": [
            "need not be provided",
            "is not expected to be recorded",
            "may be omitted",
            "can be provided",
            "must not be supplied",
        ],
        "relative": ["that", "which"],
        "marker": ["-", "*", "+", "1.", "1)"],
    },
    semantic=("independent", "joiner", "destination", "predicate"),
    lexical_spines={
        "marker": ("joiner", "destination", "predicate"),
        "adverb": ("predicate", "independent"),
        "relative": ("predicate", "joiner", "destination"),
    },
)
def test_relative_checklist_delivery_reuses_negative_optional_governor(
    marker, relative, predicate, destination, joiner, independent, adverb
):
    criterion = f"{marker} [ ] Test evidence in {destination} {relative} {adverb}{predicate}"
    if independent:
        criterion += joiner + "the reviewer must record evidence in a workflow artifact"
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]


@_semantic_matrix(
    dimensions={
        "actor": ["nominal", "reviewer", "UI"],
        "repeat_preposition": [False, True],
        "first": [False, True],
        "body_alias": ["body", "description"],
        "independent": [False, True],
        "reverse": [False, True],
        "predicate": [
            "must remain available",
            "shall stay accessible",
            "is required to be present",
            "is available",
            "is accessible",
            "are present",
            "now is available",
            "currently is available",
            "now is accessible",
            "currently is accessible",
            "now are present",
            "currently are present",
            "is now available",
            "is currently available",
            "is now accessible",
            "is currently accessible",
            "are now present",
            "are currently present",
            "must always remain available",
            "shall always stay accessible",
            "is required to always be present",
            "always is available",
            "is always accessible",
            "are always present",
        ],
        "relative": ["that", "which"],
    },
    semantic=("actor", "repeat_preposition", "first", "independent", "reverse", "relative"),
    lexical_spines={
        "predicate": ("actor", "first", "independent"),
        "body_alias": ("reverse", "first", "repeat_preposition"),
    },
)
def test_attached_availability_relative_preserves_destination_or(
    relative, predicate, reverse, independent, body_alias, first, repeat_preposition, actor
):
    destinations = [f"the PR {body_alias}", "a PR comment"]
    if reverse:
        destinations.reverse()
    destinations[0 if first else 1] += f" {relative} {predicate}"
    if repeat_preposition:
        destinations[1] = "in " + destinations[1]
    prefix = (
        "Test evidence must be in "
        if actor == "nominal"
        else f"The {actor} must generate evidence in "
    )
    criterion = prefix + " or ".join(destinations)
    if independent:
        criterion += "; the reviewer must record evidence in a workflow artifact"
    extra = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == {"body", "comments"} | extra
    assert verifier._required_evidence_options(criterion) == [
        {"comments" if reverse else "body"} | extra,
        {"body" if reverse else "comments"} | extra,
    ]
    fixture = _COVERAGE_FIXTURE
    for present in ["body", "comments"]:
        context, _ = fixture._context(1, 1000, 1000)
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
            "## PR Diff Summary",
            "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
            f"- PR body: **{'present' if present == 'body' else 'absent'}**\n"
            f"- PR comments: **{'present' if present == 'comments' else 'absent'}**\n"
            "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
        )
        result = verifier._apply_coverage_floor(
            verifier.EvaluationResult(verdict="PASS", used_llm=True),
            verifier.prompt_coverage(context, None),
        )
        assert result.verdict == "PASS"


@pytest.mark.parametrize("marker", ["-", "*", "+", "1.", "1)"])
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("a PR comment", "comments"),
        ("the PR description", "body"),
        ("a workflow artifact", "artifacts"),
    ],
)
def test_every_supported_checklist_marker_retains_destination(marker, destination, channel):
    assert verifier._required_evidence_channels(f"{marker} [ ] Test evidence in {destination}") == {
        channel
    }
    assert (
        verifier._required_evidence_channels(f"{marker} [ ] Evidence may be in {destination}")
        == set()
    )
    assert (
        verifier._required_evidence_channels(f"{marker} [ ] Evidence must not be in {destination}")
        == set()
    )


@pytest.mark.parametrize("operator", ["and", "or"])
@pytest.mark.parametrize("component", ["", " editor", " field", " textarea", " preview"])
@pytest.mark.parametrize("destination", ["PR body", "PR description"])
@pytest.mark.parametrize("body_first", [False, True])
@pytest.mark.parametrize("comment_status", ["present", "absent", "unavailable"])
@pytest.mark.parametrize("body_status", ["present", "absent", "unavailable"])
def test_checklist_destination_lists_control_real_floor(
    operator, component, destination, body_first, comment_status, body_status
):
    fixture = _COVERAGE_FIXTURE
    destinations = ["a PR comment", f"the {destination}{component}"]
    if body_first:
        destinations.reverse()
    criterion = "- [ ] Test evidence in " + f" {operator} ".join(destinations)
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        f"- PR body: **{body_status}**\n- PR comments: **{comment_status}**\n"
        "- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    expected = (
        (comment_status == "present" and body_status == "present")
        if operator == "and"
        else (comment_status == "present" or body_status == "present")
    )
    assert result.verdict == ("PASS" if expected else "CONCERNS")


@pytest.mark.parametrize(
    "destination,channel",
    [
        ("a PR comment", "comments"),
        ("the PR description", "body"),
        ("a workflow artifact", "artifacts"),
    ],
)
@pytest.mark.parametrize("prefix", ["- [ ] ", "- [x] "])
def test_checklist_noun_evidence_retains_named_destination(destination, channel, prefix):
    assert verifier._required_evidence_channels(prefix + "Test evidence in " + destination) == {
        channel
    }


@pytest.mark.parametrize("destination", ["PR description", "pull request description"])
@pytest.mark.parametrize(
    "governor,expected", [("must", {"body"}), ("must not", set()), ("may", set())]
)
def test_description_alias_preserves_body_polarity(destination, governor, expected):
    assert (
        verifier._required_evidence_channels(f"Command output {governor} be in the {destination}")
        == expected
    )


@pytest.mark.parametrize(
    "destination", ["a PR comment", "the PR description", "a workflow artifact"]
)
@pytest.mark.parametrize(
    "phrase",
    [
        "No evidence is required in ",
        "Evidence is not expected in ",
        "Evidence is not supposed to be in ",
        "Evidence is no longer required in ",
        "Optional evidence in ",
    ],
)
def test_checklist_noun_destinations_keep_negative_and_optional_controls(destination, phrase):
    criterion = "- [ ] " + phrase + destination
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; provide command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "criterion",
    [
        "The UI must display command output in the PR description editor",
        'The UI must display the label "Command output must be in the PR description"',
        "The verifier must recognize evidence in a PR comment",
    ],
)
def test_description_and_checklist_changes_keep_product_boundaries(criterion):
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()


@pytest.mark.parametrize(
    "proof",
    [
        "test results",
        "validation results",
        "test logs",
        "validation logs",
        "test output",
        "validation output",
        "screenshots",
        "recordings",
        "a recording of the session",
    ],
)
@pytest.mark.parametrize("governor", ["must", "must not", "may"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
@pytest.mark.parametrize("independent", [False, True])
def test_direct_common_proof_upload_keeps_its_destination(
    proof, governor, destination, channel, independent
):
    criterion = f"The reviewer {governor} upload {proof} in {destination}"
    expected = {channel} if governor == "must" else set()
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
        expected.add("comments")
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("proof", ["screenshots", "test results", "recordings"])
@pytest.mark.parametrize("actor", ["The UI", "The API"])
def test_product_upload_capability_does_not_require_review_delivery(proof, actor):
    criterion = f"{actor} must allow users to upload {proof}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(criterion + "; upload evidence in the PR body") == {
        "body"
    }


@pytest.mark.parametrize(
    "governor", ["doesn't need to", "doesn’t need to", "isn't expected to", "isn’t expected to"]
)
@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize("independent", [False, True])
def test_common_proof_contracted_negative_actor(proof, governor, independent):
    criterion = f"The UI must display {proof}, and the reviewer {governor} update the PR body"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize(
    "quote,closing", [('"', '"'), ("'", "'"), ("`", "`"), ("“", "”"), ("‘", "’")]
)
@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize("independent", [False, True])
def test_common_proof_destination_inside_adjacent_literal(quote, closing, proof, independent):
    criterion = f"The UI must display {proof} with the label {quote}Test results must be in the PR body{closing}"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize(
    "proof", ["a recording", "recordings", "screenshots", "test results", "validation output"]
)
@pytest.mark.parametrize("governor", ["must", "must not", "may"])
@pytest.mark.parametrize("operation", ["record", "attach", "put"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_common_proof_active_qualified_object(proof, governor, operation, destination, channel):
    criterion = f"The reviewer {governor} {operation} {proof} of the session in {destination}"
    assert verifier._required_evidence_channels(criterion) == (
        {channel} if governor == "must" else set()
    )


@pytest.mark.parametrize(
    "proof", ["test results", "screenshots", "validation output", "recordings"]
)
@pytest.mark.parametrize("actor", ["reviewer", "automation agent", "developer"])
@pytest.mark.parametrize("governor", ["does not need to", "no longer has to", "need not"])
@pytest.mark.parametrize("independent", [False, True])
def test_common_proof_negative_actor_boundary(proof, actor, governor, independent):
    criterion = f"The UI must display {proof}, and the {actor} {governor} update the PR body"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize("quote", ['"', "'", "`", "“"])
@pytest.mark.parametrize(
    "proof", ["Test results", "Screenshots", "Validation output", "Recordings"]
)
@pytest.mark.parametrize("independent", [False, True])
def test_common_proof_quoted_input(quote, proof, independent):
    closing = "”" if quote == "“" else quote
    criterion = f"The parser must accept the string {quote}{proof} must be in the PR body{closing}"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize("joiner", [", and ", "; ", ". "])
@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize("governor", ["must", "must not", "may"])
@pytest.mark.parametrize("operation", ["record", "put", "share"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments")],
)
def test_common_proof_pronoun_clause_separator(
    joiner, proof, governor, operation, destination, channel
):
    criterion = f"The UI must display {proof}{joiner}the reviewer {governor} {operation} them in {destination}"
    assert verifier._required_evidence_channels(criterion) == (
        {channel} if governor == "must" else set()
    )


@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize(
    "operation", ["put", "place", "share", "paste", "write", "submit", "deliver", "supply"]
)
@pytest.mark.parametrize("governor", ["must", "must not", "may"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_common_proof_pronoun_shared_aliases(proof, operation, governor, destination, channel):
    criterion = f"The UI must display {proof}, and the reviewer {governor} {operation} them in {destination}"
    assert verifier._required_evidence_channels(criterion) == (
        {channel} if governor == "must" else set()
    )


@pytest.mark.parametrize("quote", ['"', "'", "`", "“"])
@pytest.mark.parametrize("operation", ["include", "contain", "have"])
@pytest.mark.parametrize("independent", [False, True])
def test_pr_contained_comment_quoted_literal(quote, operation, independent):
    closing = "”" if quote == "“" else quote
    criterion = (
        f"The parser must accept the string {quote}The PR must {operation} a comment{closing}"
    )
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize(
    "actor",
    [
        "reviewer",
        "automation agent",
        "runner",
        "bot",
        "developer",
        "engineer",
        "tester",
        "auditor",
        "verifier",
        "team",
        "user",
        "consumer",
    ],
)
@pytest.mark.parametrize("operation", ["record", "attach", "include"])
@pytest.mark.parametrize("governor", ["must", "must not", "may"])
def test_common_proof_pronoun_cross_actor_delivery(proof, actor, operation, governor):
    criterion = (
        f"The UI must display {proof}, and the {actor} {governor} {operation} them in the PR body"
    )
    assert verifier._required_evidence_channels(criterion) == (
        {"body"} if governor == "must" else set()
    )


@pytest.mark.parametrize(
    "actor",
    [
        "automation agent",
        "runner",
        "bot",
        "developer",
        "engineer",
        "tester",
        "auditor",
        "verifier",
        "team",
        "user",
        "consumer",
    ],
)
@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
def test_automation_actor_unrelated_destination(proof, actor):
    assert (
        verifier._required_evidence_channels(
            f"The UI must display {proof}, and the {actor} must update the PR body"
        )
        == set()
    )


@pytest.mark.parametrize("operation", ["include", "contain", "have"])
@pytest.mark.parametrize("noun", ["button", "form", "count", "thread", "dashboard", "catalog"])
def test_pr_comment_compound_is_not_delivery(operation, noun):
    assert (
        verifier._required_evidence_channels(f"The PR must {operation} a comment {noun}") == set()
    )


@pytest.mark.parametrize(
    "destination,channel",
    [
        ("the PR body", "body"),
        ("a PR comment", "comments"),
    ],
)
def test_qualified_recording_presence_retains_governor(destination, channel):
    assert verifier._required_evidence_channels(
        f"A recording of the session must be in {destination}"
    ) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"A recording of the session must not be in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("capability", ["allow users to", "let users"])
@pytest.mark.parametrize("independent", [False, True])
def test_product_link_capability_preserves_reviewer_delivery(capability, independent):
    criterion = f"The UI must {capability} link to PR comments"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if independent else set()
    )


@pytest.mark.parametrize("joiner", [", and ", " and ", "; "])
@pytest.mark.parametrize("position", ["before", "after"])
@pytest.mark.parametrize("proof", ["test results", "screenshots", "validation output"])
@pytest.mark.parametrize(
    "actor",
    [
        "the reviewer",
        "our security reviewer",
        "the reviewer of the endpoint",
        "the endpoint used by reviewers",
    ],
)
def test_proof_destination_does_not_cross_independent_actor(joiner, position, proof, actor):
    product = f"The UI must display {proof}"
    unrelated = f"{actor} must update the PR body"
    criterion = (
        product + joiner + unrelated if position == "after" else unrelated + joiner + product
    )
    assert verifier._required_evidence_channels(criterion) == set()


@pytest.mark.parametrize("operation", ["include", "contain", "have"])
@pytest.mark.parametrize("noun", ["counter", "field", "icon", "parser", "metadata", "editor"])
def test_comment_feature_noun_is_not_comment_delivery(operation, noun):
    assert (
        verifier._required_evidence_channels(f"The PR must {operation} a comment {noun}") == set()
    )


@pytest.mark.parametrize("proof", ["Test results", "Screenshots", "Validation output"])
@pytest.mark.parametrize("governor", ["must", "have to", "are required to"])
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("the PR body", "body"),
        ("a PR comment", "comments"),
        ("workflow artifacts", "artifacts"),
    ],
)
def test_common_proof_bare_presence_uses_shared_delivery(proof, governor, destination, channel):
    assert verifier._required_evidence_channels(f"{proof} {governor} be in {destination}") == {
        channel
    }


@pytest.mark.parametrize("proof", ["Test output", "Validation output", "Validation results"])
def test_passive_test_output_requires_comment(proof):
    assert verifier._required_evidence_channels(f"{proof} must be in a PR comment") == {"comments"}
    assert verifier._required_evidence_channels(f"{proof} must not be in a PR comment") == set()


@pytest.mark.parametrize("actor", ["The UI", "The API", "The reviewer"])
@pytest.mark.parametrize("independent", [False, True])
def test_product_links_preserve_independent_review_delivery(actor, independent):
    criterion = f"{actor} must link to PR comments"
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if actor == "The reviewer" or independent else set()
    )


@pytest.mark.parametrize("subject", ["The PR", "The pull request"])
@pytest.mark.parametrize("operation", ["include", "contain", "have"])
def test_pr_contained_comment_evidence_is_comment_channel(subject, operation):
    assert verifier._required_evidence_channels(
        f"{subject} must {operation} a comment with test evidence"
    ) == {"comments"}
    for governor in ("must not", "is not expected to", "may"):
        assert (
            verifier._required_evidence_channels(
                f"{subject} {governor} {operation} a comment with test evidence"
            )
            == set()
        )


@pytest.mark.parametrize(
    "object_name",
    [
        "Test results",
        "Test logs",
        "Before/after screenshots",
        "Recordings",
    ],
)
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("the PR body", "body"),
        ("a PR comment", "comments"),
        ("workflow artifacts", "artifacts"),
    ],
)
def test_common_proof_objects_reuse_delivery_polarity(object_name, destination, channel):
    assert verifier._required_evidence_channels(
        f"{object_name} must be recorded in {destination}"
    ) == {channel}
    for governor in ("must not", "are not expected to", "are no longer required to"):
        assert (
            verifier._required_evidence_channels(
                f"{object_name} {governor} be recorded in {destination}"
            )
            == set()
        )
    assert (
        verifier._required_evidence_channels(
            f"The UI must allow users to upload {object_name.lower()}"
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels(
            f'The release notes must quote "{object_name} must be recorded in {destination}"'
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels(f"{object_name} may be recorded in {destination}")
        == set()
    )
    assert verifier._required_evidence_channels(
        f"{object_name} must not be recorded in {destination}; "
        "the reviewer must record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "criterion",
    [
        "The UI must capture screenshots",
        "The recorder must save recordings",
        "The UI must capture screenshots; the reviewer must record evidence in a PR comment",
    ],
)
def test_product_proof_nouns_do_not_create_overall_obligation(criterion):
    assert verifier._required_evidence_channels(criterion) == (
        {"comments"} if ";" in criterion else set()
    )


@pytest.mark.parametrize("quote", ["'", '"', "`"])
@pytest.mark.parametrize("predicate", ["appear", "be present"])
def test_quoted_presence_is_not_delivery(quote, predicate):
    criterion = f"The release notes must quote {quote}Evidence must {predicate} as workflow artifacts{quote}"
    assert verifier._required_evidence_channels(criterion) == set()


@pytest.mark.parametrize("quote", ["'", '"', "`"])
def test_quoted_presence_keeps_independent_delivery(quote):
    criterion = (
        f"The release notes must quote {quote}Evidence must appear as workflow artifacts{quote}; "
        "the reviewer must record command output in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize(
    "governor", ["is not expected to", "is not supposed to", "is no longer required to"]
)
@pytest.mark.parametrize("destination", ["workflow artifacts", "the PR body", "a PR comment"])
def test_negative_presence_destination_does_not_leak(governor, destination):
    criterion = f"Evidence {governor} be in {destination} and must be recorded in a PR comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize(
    "role",
    [
        "release reviewer",
        "security reviewer",
        "compliance maintainer",
        "risk auditor",
        "security release reviewer",
        "CI release reviewer",
        "project team",
        "independent security auditor",
    ],
)
@pytest.mark.parametrize("operation", ["placed", "submitted", "delivered", "supplied"])
@pytest.mark.parametrize("adverb", ["", "already ", "currently "])
@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_compound_review_roles_retain_active_past_delivery(
    role, operation, adverb, marker, destination, channel
):
    """Role noun modifiers cannot erase explicit delivered-evidence obligations."""
    criterion = f"The {role} {adverb}{operation} evidence in {destination}"
    assert verifier._required_evidence_channels(marker + criterion) == {channel}
    optional = "The reviewer may supply evidence in the PR body"
    assert verifier._required_evidence_channels(optional + "; " + criterion) == {channel}
    assert verifier._required_evidence_channels(criterion + "; " + optional) == {channel}


@pytest.mark.parametrize("predicate", ["audits", "observes", "tests"])
@pytest.mark.parametrize("actor", ["service", "API"])
@pytest.mark.parametrize("alias", ["placed", "submitted", "supplied", "supplies"])
@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
def test_inspection_object_actor_is_not_compound_delivery_role(
    predicate, actor, alias, marker, destination
):
    """Inspection cannot invent delivery; retain existing noun-only checklist floors."""
    criterion = f"The reviewer {predicate} {actor} {alias} evidence in {destination}"
    expected = (
        {"artifacts"}
        if marker and destination == "workflow artifacts"
        else {"overall"} if marker and destination == "the PR body" else set()
    )
    assert verifier._required_evidence_channels(marker + criterion) == expected


@pytest.mark.parametrize("role", ["release reviewer", "security reviewer", "risk auditor"])
@pytest.mark.parametrize("alias", ["supplies", "placed", "submitted", "supplied"])
@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_compound_role_polarity_and_independent_delivery(role, alias, marker, destination, channel):
    """Compound roles share optional, negative and independent delivery grammar."""
    positive = f"The {role} {alias} evidence in {destination}"
    optional = "The reviewer may supply evidence in workflow artifacts"
    assert verifier._required_evidence_channels(marker + optional + " and " + positive) == {channel}
    negative = f"The {role} must not supply evidence in {destination}"
    assert verifier._required_evidence_channels(marker + negative) == set()
    assert verifier._required_evidence_channels(marker + negative + "; " + positive) == {channel}


@_semantic_matrix(
    dimensions={
        "before,after": [
            ["", ""],
            ["already ", ""],
            ["currently ", ""],
            ["still ", ""],
            ["", "already "],
            ["", "currently "],
            ["already ", "still "],
            ["still already currently ", "now still already "],
            ["no longer ", ""],
            ["never ", ""],
            ["", "not "],
            ["already no longer ", "currently "],
            ["still ", "no longer already "],
        ],
        "marker": ["", "- [ ] ", "- [x] "],
        "destination": ["the PR body", "a PR comment", "workflow artifacts"],
        "inspection": ["inspect", "review", "check"],
        "alias": ["supply", "supplies"],
        "auxiliary": ["has", "have", "had"],
        "role": ["reviewer", "maintainer", "release reviewer"],
    },
    semantic=("before,after", "auxiliary", "alias"),
    lexical_spines={
        "role": ("auxiliary", "alias"),
        "inspection": ("auxiliary", "alias"),
        "destination": ("auxiliary", "alias"),
        "marker": ("before,after",),
    },
)
def test_possession_auxiliary_cannot_make_supply_noun_a_delivery(
    role, auxiliary, alias, inspection, destination, marker, before, after
):
    criterion = (
        f"The {role} may {inspection} whether the API {before}{auxiliary} {after}"
        f"{alias} evidence in {destination}"
    )
    assert verifier._required_evidence_channels(marker + criterion) == set()
    positive = "The maintainer must record evidence in the PR body"
    assert verifier._required_evidence_channels(marker + criterion + "; " + positive) == {"body"}
    assert verifier._required_evidence_channels(marker + positive + "; " + criterion) == {"body"}


@pytest.mark.parametrize("role", ["maintainer", "release reviewer"])
@pytest.mark.parametrize("modal", ["may", "can", "could", "would", "should"])
@pytest.mark.parametrize(
    "governor,operation",
    [
        ("must", "place"),
        ("will", "place"),
        ("must have", "placed"),
        ("has", "placed"),
        ("is", "placing"),
        ("needs to", "place"),
    ],
)
@pytest.mark.parametrize(
    "destinations", list(permutations(["the PR body", "a PR comment", "workflow artifacts"], 2))
)
def test_optional_predicate_cannot_suppress_named_actor_delivery(
    role, modal, governor, operation, destinations
):
    """Retain independently governed deliveries across optional actor clauses."""
    before, after = destinations
    expected = "body" if "body" in after else "comments" if "comment" in after else "artifacts"
    first = f"The reviewer {modal} put evidence in {before}"
    second = f"the {role} {governor} {operation} evidence in {after}"
    assert verifier._required_evidence_channels(first + " and " + second) == {expected}
    assert verifier._required_evidence_channels(first + "; " + second) == {expected}
    negative = second.replace(
        governor,
        governor.replace(" have", "") + " not" + (" have" if " have" in governor else ""),
        1,
    )
    assert verifier._required_evidence_channels(first + " and " + negative) == set()
    assert verifier._required_evidence_is_missing(
        "- Overall retrieval status: **absent**\n- PR body: **absent**\n- PR comments: **absent**\n- Referenced workflow artifacts: **absent**",
        verifier._required_evidence_channels(first + " and " + second),
    )


@pytest.mark.parametrize("boundary", ["! ", "? ", ". ", " while ", " and ", "; "])
@pytest.mark.parametrize("predicate", ["must place", "placed", "has placed"])
def test_optional_actor_sentence_boundaries_retain_delivery(boundary, predicate):
    """Sentence and finite-past actor boundaries cannot erase a delivery."""
    criterion = (
        "The reviewer may put evidence in workflow artifacts"
        + boundary
        + f"the maintainer {predicate} evidence in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_is_missing("- PR comments: **absent**", {"comments"})


@pytest.mark.parametrize(
    "predicate", ["must supply", "must be supplied", "supplied", "is supplying"]
)
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_supply_alias_retains_delivery_and_product_controls(predicate, destination, channel):
    """Supply aliases share obligation, destination, and product semantics."""
    subject = "Test evidence" if "be supplied" in predicate else "The reviewer"
    obj = "" if "be supplied" in predicate else " test evidence"
    criterion = f"{subject} {predicate}{obj} in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert (
        verifier._required_evidence_channels("The service must supply command output to its users")
        == set()
    )
    assert (
        verifier._required_evidence_channels(
            f"The reviewer must not supply evidence in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("capability", ["permit", "permits", "permitted", "permitting"])
@pytest.mark.parametrize("destination", ["workflow artifacts", "a PR comment", "the PR body"])
def test_permit_product_capability_is_not_review_delivery(capability, destination):
    criterion = f"The UI must {capability} users to upload evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    independent = f"The reviewer must record evidence in {destination}"
    expected = {
        (
            "artifacts"
            if destination == "workflow artifacts"
            else "comments" if destination == "a PR comment" else "body"
        )
    }
    assert verifier._required_evidence_channels(criterion + "; " + independent) == expected


@pytest.mark.parametrize("operation", ["share", "shares", "shared", "sharing"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("the PR body", "body"), ("workflow artifacts", "artifacts")],
)
def test_share_alias_reuses_delivery_and_polarity(operation, destination, channel):
    positive = f"The reviewer must {operation} test evidence in {destination}"
    assert verifier._required_evidence_channels(positive) == {channel}
    negative = f"The reviewer must not {operation} test evidence in {destination}"
    assert verifier._required_evidence_channels(negative) == set()
    assert verifier._required_evidence_channels(negative + "; " + positive) == {channel}


@pytest.mark.parametrize("predicate", ["must share", "shares", "shared", "is sharing"])
def test_finite_share_actor_and_nonverbal_share_objects(predicate):
    assert verifier._required_evidence_channels(
        f"The reviewer {predicate} evidence in a PR comment"
    ) == {"comments"}
    for object_name in ("market share evidence", "shared evidence", "share evidence"):
        assert (
            verifier._required_evidence_channels(
                f"The reviewer may inspect {object_name} in a PR comment"
            )
            == set()
        )
    assert (
        verifier._required_evidence_channels(
            "The UI must permit users to share evidence in a PR comment"
        )
        == set()
    )


@pytest.mark.parametrize(
    "predicate",
    [
        "The reviewer must report test results in {destination}",
        "The reviewer reports test results in {destination}",
        "The reviewer reported test results in {destination}",
        "Test results must be reported by the reviewer in {destination}",
        "The reviewer must be reporting test results in {destination}",
    ],
)
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("a PR comment", "comments"),
        ("the PR body", "body"),
        ("workflow artifacts", "artifacts"),
    ],
)
def test_report_alias_reuses_delivery_polarity_destinations_and_floor(
    predicate, destination, channel
):
    """Reporting test results is a delivery obligation, not a product capability."""
    positive = predicate.format(destination=destination)
    assert verifier._required_evidence_channels(positive) == {channel}
    assert verifier._required_evidence_options(positive) == [{channel}]
    for missing in ("absent", "unavailable"):
        assert (
            _floor_verdict(
                positive,
                body=missing if channel == "body" else "present",
                comments=missing if channel == "comments" else "present",
                artifacts=missing if channel == "artifacts" else "present",
            )
            == "CONCERNS"
        )

    assert (
        verifier._required_evidence_channels(
            f"The reviewer may report test results in {destination}"
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels(
            f"The reviewer must not report test results in {destination}"
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels(
            f"The API must allow users to report test results in {destination}"
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels("The API must report test results to its users")
        == set()
    )
    for predicate in ("may inspect", "must not inspect"):
        assert (
            verifier._required_evidence_channels(
                f"The reviewer {predicate} reported test results in a PR comment"
            )
            == set()
        )
        assert (
            verifier._required_evidence_channels(
                f"The reviewer {predicate} reports in a PR comment"
            )
            == set()
        )
    for governor in ("may", "must not"):
        assert (
            verifier._required_evidence_channels(
                f"The reviewer {governor} report and report test results in a PR comment"
            )
            == set()
        )
        assert (
            verifier._required_evidence_channels(
                f"The reviewer {governor} report and report and report test results in a PR comment"
            )
            == set()
        )
        for operations in ("submit and report", "report and submit"):
            criterion = f"The reviewer {governor} {operations} test results in a PR comment"
            assert verifier._required_evidence_channels(criterion) == set()
            assert verifier._required_evidence_options(criterion) == [set()]
            assert _floor_verdict(criterion, body="present", comments="absent") == "PASS"

    noun_then_delivery = (
        "The reviewer must inspect a report and submit test results in a PR comment"
    )
    assert verifier._required_evidence_channels(noun_then_delivery) == {"comments"}
    assert verifier._required_evidence_options(noun_then_delivery) == [{"comments"}]
    assert _floor_verdict(noun_then_delivery, body="present", comments="absent") == "CONCERNS"
    assert verifier._required_evidence_channels(
        "The reviewer must inspect a report; the reviewer must submit test results in a PR comment"
    ) == {"comments"}


def test_report_alias_keeps_coordinated_channels_and_independent_reviewer_duty():
    criterion = "The reviewer must report test results in a PR comment and workflow artifacts"
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )

    product_then_reviewer = (
        "The API must allow users to report test results in a PR comment; "
        "the reviewer must report test results in workflow artifacts"
    )
    assert verifier._required_evidence_channels(product_then_reviewer) == {"artifacts"}
    assert (
        _floor_verdict(product_then_reviewer, body="present", comments="absent", artifacts="absent")
        == "CONCERNS"
    )


def test_optional_actor_cannot_suppress_prove_delivery():
    """Keep the existing prove operation in the shared actor grammar."""
    assert verifier._required_evidence_channels(
        "The reviewer may record evidence in the PR body and the maintainer must prove the result in workflow artifacts"
    ) == {"artifacts"}


@pytest.mark.parametrize(
    "modifier", ["previously published", "already uploaded", "recently recorded"]
)
def test_optional_participial_object_is_not_a_finite_past_actor(modifier):
    """A coordinated evidence modifier has no independently governing actor."""
    criterion = (
        "The reviewer may include current evidence in the PR body and "
        + modifier
        + " evidence in workflow artifacts"
    )
    assert verifier._required_evidence_channels(criterion) == set()


@pytest.mark.parametrize("predicate", ["may inspect", "may check", "must inspect"])
@pytest.mark.parametrize("object_name", ["power supply evidence", "water supply evidence"])
def test_supply_noun_is_not_a_delivery_predicate(predicate, object_name):
    """Object noun supply cannot invent a record operation."""
    assert verifier._required_evidence_channels(
        f"The reviewer {predicate} {object_name} in the PR body"
    ) == ({"overall"} if predicate == "must inspect" else set())


@pytest.mark.parametrize(
    "criterion",
    [
        "The PR comment has to contain command output",
        "The PR comments have to contain command output",
        "Command output has to be in a PR comment",
        "Command outputs have to be in a PR comment",
    ],
)
def test_comment_has_to_uses_shared_mandatory_auxiliary(criterion):
    """Comment requirements reuse the complete mandatory auxiliary vocabulary."""
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize("predicate", ["appear", "be present"])
@pytest.mark.parametrize("governor", ["must not", "is not expected to", "is not supposed to"])
@pytest.mark.parametrize("preposition", ["in", "as"])
@pytest.mark.parametrize(
    "destination,channel",
    [("workflow artifacts", "artifacts"), ("a PR comment", "comments"), ("the PR body", "body")],
)
def test_negated_presence_retains_destination_polarity(
    predicate, governor, preposition, destination, channel
):
    negative = f"Evidence {governor} {predicate} {preposition} {destination}"
    assert verifier._required_evidence_channels(negative) == set()
    positive = f"The reviewer must record evidence in {destination}"
    assert verifier._required_evidence_channels(negative + "; " + positive) == {channel}
    assert verifier._required_evidence_channels(positive + "; " + negative) == {channel}


@pytest.mark.parametrize("subject", ["No evidence", "Neither evidence nor command output"])
@pytest.mark.parametrize("predicate", ["appear", "be present"])
@pytest.mark.parametrize(
    "destination,channel",
    [("workflow artifacts", "artifacts"), ("a PR comment", "comments"), ("the PR body", "body")],
)
def test_negative_presence_subject_preserves_independent_delivery(
    subject, predicate, destination, channel
):
    negative = f"{subject} must {predicate} as {destination}"
    assert verifier._required_evidence_channels(negative) == set()
    positive = f"The reviewer must record evidence in {destination}"
    assert verifier._required_evidence_channels(negative + "; " + positive) == {channel}
    assert verifier._required_evidence_channels(positive + "; " + negative) == {channel}


@pytest.mark.parametrize("subject", ["No evidence", "Neither evidence nor command output"])
@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize(
    "destinations",
    [
        "a PR comment or workflow artifacts",
        "workflow artifacts and the PR body",
        "the PR body, a PR comment and workflow artifacts",
        "a PR comment or in workflow artifacts",
        "the users and a PR comment or workflow artifacts",
    ],
)
def test_negative_presence_consumes_entire_coordinated_destination_list(
    subject, marker, destinations
):
    negative = f"{marker}{subject} is required to appear in {destinations}"
    assert verifier._required_evidence_channels(negative) == set()
    positive = "The reviewer must record evidence in workflow artifacts"
    assert verifier._required_evidence_channels(negative + "; " + positive) == {"artifacts"}
    assert verifier._required_evidence_channels(positive + "; " + negative) == {"artifacts"}


@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize("separator", [", and ", " and ", " or "])
@pytest.mark.parametrize("predicate_prefix", ["", "currently ", "that ", "which now "])
@pytest.mark.parametrize(
    "governor",
    ["must", "shall", "has to", "required to", "expected to", "is required to", "is supposed to"],
)
@pytest.mark.parametrize(
    "destination,channel",
    [("workflow artifacts", "artifacts"), ("the PR body", "body"), ("a PR comment", "comments")],
)
def test_destination_list_cannot_consume_independent_affirmative_actor(
    marker, separator, predicate_prefix, governor, destination, channel
):
    negative = marker + "No evidence is required to appear in a PR comment"
    positive = f"{destination} {predicate_prefix}{governor} contain command output"
    assert verifier._required_evidence_channels(negative + separator + positive) == {channel}
    criterion = negative + separator + positive
    assert verifier._required_evidence_options(criterion) == [{channel}]
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, criterion).replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **unavailable**\n"
        "- PR body: **present**\n- PR comments: **present**\n"
        "- Referenced workflow artifacts: **present**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == "PASS"


@pytest.mark.parametrize(
    "governor", ["is not expected to", "is not supposed to", "is no longer required to"]
)
@pytest.mark.parametrize("evidence", ["Command output", "Evidence", "A transcript"])
@pytest.mark.parametrize("marker", ["", "- [ ] "])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("the PR body", "body"), ("workflow artifacts", "artifacts")],
)
def test_negative_presence_governor_cannot_require_delivery(
    governor, evidence, marker, destination, channel
):
    negative = f"{evidence} {governor} be in {destination}"
    assert verifier._required_evidence_channels(marker + negative) == set()
    positive = f"The reviewer must record evidence in {destination}"
    assert verifier._required_evidence_channels(marker + negative + "; " + positive) == {channel}
    assert verifier._required_evidence_channels(positive + "; " + marker + negative) == {channel}


@pytest.mark.parametrize("predicate", ["checks", "inspects", "reviews"])
@pytest.mark.parametrize("compound", ["service", "API", "reviewer"])
@pytest.mark.parametrize("alias", ["supply", "supplied", "placed", "submitted", "delivered"])
def test_actor_word_in_supply_object_is_not_clause_subject(predicate, compound, alias):
    """An object compound cannot create a delivery predicate."""
    assert (
        verifier._required_evidence_channels(
            f"The reviewer {predicate} the {compound} {alias} evidence in the PR body"
        )
        == set()
    )


@pytest.mark.parametrize("boundary", [" and ", " while ", ". ", "! ", "? "])
@pytest.mark.parametrize("verb", ["supplies", "records", "provides", "places", "proves"])
def test_optional_actor_cannot_suppress_finite_present_delivery(boundary, verb):
    """An independent finite-present subject cannot inherit optional delivery."""
    assert verifier._required_evidence_channels(
        "The reviewer may supply evidence in the PR body"
        + boundary
        + f"the maintainer {verb} evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("boundary", [" and ", " while ", ". ", "! ", "? "])
@pytest.mark.parametrize(
    "negation",
    ["does not", "do not", "did not", "does never", "doesn't", "does no longer", "must not"],
)
@pytest.mark.parametrize("verb", ["prove", "supply", "record"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
def test_independent_delivery_prohibition_uses_shared_operation_grammar(
    boundary, negation, verb, destination
):
    assert (
        verifier._required_evidence_channels(
            "The reviewer may supply evidence in the PR body"
            + boundary
            + f"the senior maintainer {negation} {verb} evidence in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize(
    "negative_destination", ["the PR body", "a PR comment", "workflow artifacts"]
)
@pytest.mark.parametrize(
    "positive_destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_prohibition_does_not_erase_independent_mandatory_delivery(
    negative_destination, positive_destination, channel
):
    assert verifier._required_evidence_channels(
        f"The reviewer does not prove evidence in {negative_destination}"
        + f" and the maintainer must record evidence in {positive_destination}"
    ) == {channel}


@pytest.mark.parametrize("actor", ["reviewer", "assigned reviewer", "senior reviewer", "CI runner"])
def test_supply_clause_subject_preserves_delivery(actor):
    assert verifier._required_evidence_channels(
        f"The {actor} supplies evidence in a PR comment"
    ) == {"comments"}


@_semantic_matrix(
    dimensions={
        "positive_first": [True, False],
        "positive_destination,channel": [
            ["the PR body", "body"],
            ["a PR comment", "comments"],
            ["workflow artifacts", "artifacts"],
        ],
        "negative_destination": ["the PR body", "a PR comment", "workflow artifacts"],
        "verb": ["supply", "prove", "record"],
        "negation": ["doesn't", "doesn’t", "does not", "never", "no longer"],
        "boundary": [" and ", " while ", "; ", ". ", "! ", "? "],
    },
    semantic=(
        "positive_first",
        "positive_destination,channel",
        "negative_destination",
        "negation",
        "boundary",
    ),
    lexical_spines={"verb": ("negation", "boundary")},
)
def test_prohibition_polarity_is_clause_order_and_alias_symmetric(
    boundary, negation, verb, negative_destination, positive_destination, channel, positive_first
):
    """Negated aliases cannot invent a channel beside an independent obligation."""
    positive = f"The reviewer must record evidence in {positive_destination}"
    negative = f"the senior maintainer {negation} {verb} evidence in {negative_destination}"
    criterion = positive + boundary + negative if positive_first else negative + boundary + positive
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize("verb", ["proves", "records", "supplies"])
@pytest.mark.parametrize("negation", ["never", "no longer"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
def test_bare_finite_negative_delivery_has_no_channel(verb, negation, destination):
    """Finite negative predicates do not require evidence delivery."""
    assert (
        verifier._required_evidence_channels(
            f"The reviewer {negation} {verb} evidence in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
@pytest.mark.parametrize("verb", ["prove", "record", "supply"])
@pytest.mark.parametrize(
    "first_destination,first_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
@pytest.mark.parametrize(
    "second_destination,second_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_contrastive_not_only_preserves_both_delivery_channels(
    contrast, verb, first_destination, first_channel, second_destination, second_channel
):
    """Declared additive contrasts are not delivery prohibitions."""
    assert verifier._required_evidence_channels(
        f"The reviewer must not {contrast} {verb} evidence in {first_destination}"
        + f" but also record evidence in {second_destination}"
    ) == {first_channel, second_channel}


@pytest.mark.parametrize(
    "negative_auxiliary",
    ["does not need to", "doesn't need to", "never has to", "no longer needs to"],
)
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
def test_negative_embedded_mandatory_auxiliary_is_not_required(negative_auxiliary, destination):
    """Embedded need-to/has-to cannot override its negative governor."""
    assert (
        verifier._required_evidence_channels(
            f"Command output {negative_auxiliary} be in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
@pytest.mark.parametrize("modal", ["may", "should"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
def test_additive_contrast_preserves_optional_governor(contrast, modal, destination):
    """Additive normalization cannot promote an optional delivery."""
    assert (
        verifier._required_evidence_channels(
            f"Evidence {modal} not {contrast} be proved in {destination}"
            + " but also be recorded in a PR comment"
        )
        == set()
    )


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
def test_additive_contrast_inside_parser_literal_is_not_delivery(contrast):
    """Quoted parser examples stay literal, with independent obligations intact."""
    criterion = (
        f'The parser must recognize "Evidence must not {contrast} be proved'
        + ' in workflow artifacts but also be recorded in a PR comment"'
    )
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize(
    "governor",
    [
        "is not required to",
        "is not needed to",
        "is never expected to",
        "is no longer supposed to",
        "is not obliged to",
        "is not mandated to",
        "are not required to",
        "was not required to",
        "were never needed to",
    ],
)
@pytest.mark.parametrize("participle", ["recorded", "supplied", "proved"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
@pytest.mark.parametrize("positive_first", [True, False])
def test_negative_requirement_governor_consumes_complete_passive_action(
    governor, participle, destination, positive_first
):
    """Short optionality matches cannot leave a required action behind."""
    negative = f"Evidence {governor} be {participle} in {destination}"
    assert verifier._required_evidence_channels(negative) == set()
    positive = "The reviewer must record evidence in a PR comment"
    criterion = positive + "; " + negative if positive_first else negative + "; " + positive
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
@pytest.mark.parametrize("aspect", ["has been", "had been", "is being", "was being"])
@pytest.mark.parametrize("participle", ["recorded", "supplied", "proved"])
@pytest.mark.parametrize(
    "first_destination,first_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
@pytest.mark.parametrize(
    "second_destination,second_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_finite_aspect_additive_contrast_preserves_both_channels(
    contrast,
    aspect,
    participle,
    first_destination,
    first_channel,
    second_destination,
    second_channel,
):
    """Residual passive aspects share additive and elided-governor handling."""
    governor, residual = aspect.split()
    assert verifier._required_evidence_channels(
        f"Evidence {governor} not {contrast} {residual} {participle} in {first_destination}"
        + f" but also {residual} recorded in {second_destination}"
    ) == {first_channel, second_channel}


@pytest.mark.parametrize(
    "governor",
    [
        "is not required to",
        "is not needed to",
        "was not required to",
        "were not needed to",
        "is never expected to",
        "is no longer supposed to",
        "does not need to",
        "doesn't need to",
        "never has to",
        "no longer needs to",
    ],
)
@pytest.mark.parametrize("participle", ["recorded", "supplied", "proved"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment", "workflow artifacts"])
@pytest.mark.parametrize("positive_first", [True, False])
@pytest.mark.parametrize("marker", ["", "- [ ] ", "- [x] ", "* [ ] ", "- "])
def test_negative_active_perfect_governor_preserves_independent_delivery(
    governor, participle, destination, positive_first, marker
):
    """Active perfect actions retain their negative requirement governor."""
    negative = f"The reviewer {governor} have {participle} evidence in {destination}"
    assert verifier._required_evidence_channels(marker + negative) == set()
    positive = "The maintainer must record evidence in the PR body"
    criterion = positive + "; " + negative if positive_first else negative + "; " + positive
    assert verifier._required_evidence_channels(marker + criterion) == {"body"}


@_semantic_matrix(
    dimensions={
        "marker": ["", "- [ ] ", "- [x] ", "* [ ] ", "- "],
        "second_destination,second_channel": [
            ["the PR body", "body"],
            ["a PR comment", "comments"],
            ["workflow artifacts", "artifacts"],
        ],
        "first_destination": ["the PR body", "a PR comment", "workflow artifacts"],
        "boundary": ["and", "or", "but"],
        "participle": ["recorded", "supplied", "proved"],
        "governor": [
            "must not",
            "is not required to",
            "does not need to",
            "never has to",
            "no longer needs to",
        ],
    },
    semantic=("second_destination,second_channel", "first_destination", "boundary", "governor"),
    lexical_spines={"participle": ("governor", "boundary"), "marker": ("governor", "boundary")},
)
def test_negative_passive_coordination_respects_contrast(
    governor, participle, boundary, first_destination, second_destination, second_channel, marker
):
    criterion = f"Command output {governor} be {participle} in {first_destination} {boundary} be posted in {second_destination}"
    expected = {second_channel} if boundary == "but" else set()
    assert verifier._required_evidence_channels(marker + criterion) == expected


@_semantic_matrix(
    dimensions={
        "second_destination,second_channel": [
            ["the PR body", "body"],
            ["a PR comment", "comments"],
            ["workflow artifacts", "artifacts"],
        ],
        "first_destination,first_channel": [
            ["the PR body", "body"],
            ["a PR comment", "comments"],
            ["workflow artifacts", "artifacts"],
        ],
        "boundary": ["and", "or", "but"],
        "governor": [
            "is not required to",
            "does not need to",
            "never has to",
            "no longer needs to",
            "must not",
            "must",
            "may",
        ],
        "marker": ["", "- [ ] "],
        "participle": ["recorded", "proved", "supplied"],
        "adverb_position": ["before", "after", "both"],
        "adverb": ["already", "recently", "now"],
    },
    semantic=(
        "second_destination,second_channel",
        "first_destination,first_channel",
        "boundary",
        "governor",
        "adverb_position",
    ),
    lexical_spines={
        "adverb": ("governor", "boundary", "adverb_position"),
        "participle": ("governor", "boundary"),
        "marker": ("governor", "boundary"),
    },
)
def test_active_perfect_elided_delivery_retains_actor_and_governor(
    marker,
    governor,
    boundary,
    first_destination,
    first_channel,
    second_destination,
    second_channel,
    adverb,
    participle,
    adverb_position,
):
    """Active-perfect coordination shares finite actor/governor inheritance."""
    before = adverb + " " if adverb_position != "after" else ""
    after = adverb + " " if adverb_position != "before" else ""
    criterion = f"The reviewer {governor} have {participle} evidence in {first_destination} {boundary} {before}have {after}recorded evidence in {second_destination}"
    expected = (
        {first_channel, second_channel}
        if governor == "must"
        else set() if governor == "may" or boundary != "but" else {second_channel}
    )
    assert verifier._required_evidence_channels(marker + criterion) == expected


@pytest.mark.parametrize("contrast", ["only", "merely", "just"])
@pytest.mark.parametrize("participle", ["recorded", "proved", "supplied"])
@pytest.mark.parametrize(
    "first_destination,first_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
@pytest.mark.parametrize(
    "second_destination,second_channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_passive_not_only_preserves_complete_destination_set(
    contrast, participle, first_destination, first_channel, second_destination, second_channel
):
    """Additive obligations share the passive aspect grammar."""
    assert verifier._required_evidence_channels(
        f"Evidence must not {contrast} be {participle} in {first_destination}"
        + f" but also be recorded in {second_destination}"
    ) == {first_channel, second_channel}


@pytest.mark.parametrize(
    "negative_auxiliary", ["does not need to", "never has to", "no longer needs to"]
)
@pytest.mark.parametrize("participle", ["recorded", "proved", "supplied"])
@pytest.mark.parametrize(
    "negative_destination", ["the PR body", "a PR comment", "workflow artifacts"]
)
@pytest.mark.parametrize(
    "positive_destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
@pytest.mark.parametrize("positive_first", [True, False])
def test_negative_embedded_governor_preserves_independent_passive_delivery(
    negative_auxiliary,
    participle,
    negative_destination,
    positive_destination,
    channel,
    positive_first,
):
    """Passive prohibitions cannot add a channel or erase a separate obligation."""
    negative = f"Command output {negative_auxiliary} be {participle} in {negative_destination}"
    positive = f"The reviewer must record evidence in {positive_destination}"
    assert verifier._required_evidence_channels(negative) == set()
    criterion = positive + "; " + negative if positive_first else negative + "; " + positive
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize("governor", ["may", "should", "must not", "shall never"])
@pytest.mark.parametrize("first_destination", ["the PR body", "a PR comment", "workflow artifacts"])
@pytest.mark.parametrize(
    "second_destination", ["the PR body", "a PR comment", "workflow artifacts"]
)
def test_elided_passive_inherits_optional_or_negative_governor(
    governor, first_destination, second_destination
):
    """Object inheritance cannot turn an optional or prohibited delivery positive."""
    assert (
        verifier._required_evidence_channels(
            f"Evidence {governor} be recorded in {first_destination}"
            + f" and also be recorded in {second_destination}"
        )
        == set()
    )


@pytest.mark.parametrize("prefix", ["", "- ", "- [ ] ", "* [x] ", "1. "])
def test_supply_imperative_list_marker_preserves_delivery(prefix):
    """List formatting does not turn an imperative delivery into a noun."""
    assert verifier._required_evidence_channels(prefix + "Supply evidence in a PR comment") == {
        "comments"
    }


@_semantic_matrix(
    dimensions={
        "destinations": [
            ["the PR body", "a PR comment"],
            ["the PR body", "workflow artifacts"],
            ["a PR comment", "the PR body"],
            ["a PR comment", "workflow artifacts"],
            ["workflow artifacts", "the PR body"],
            ["workflow artifacts", "a PR comment"],
        ],
        "operation": ["put", "place", "write"],
        "governor": ["must", "shall", "needs to", "will"],
        "modal": ["may", "can", "could", "would", "should"],
        "role": ["reviewer", "maintainer"],
        "auxiliary": ["do", "does", "did"],
    },
    semantic=("destinations", "governor", "modal", "auxiliary"),
    lexical_spines={
        "operation": ("governor", "modal", "auxiliary"),
        "role": ("governor", "modal", "auxiliary"),
    },
)
def test_optional_review_predicate_cannot_suppress_elided_mandatory_delivery(
    auxiliary, role, modal, governor, operation, destinations
):
    before, after = destinations
    expected = "body" if "body" in after else "comments" if "comment" in after else "artifacts"
    criterion = f"The {role} {modal} {operation} evidence in {before} and {governor} {operation} evidence in {after}"
    assert verifier._required_evidence_channels(criterion) == {expected}
    assert (
        verifier._required_evidence_channels(
            criterion.replace(f"and {governor} ", f"and {governor} not ")
        )
        == set()
    )
    assert verifier._required_evidence_channels(
        criterion.replace(f"{modal} ", f"{modal} not ")
    ) == {expected}
    assert verifier._required_evidence_channels(
        f"The service {auxiliary} put evidence in its database; " + criterion
    ) == {expected}


@pytest.mark.parametrize("auxiliary", ["do", "does", "did"])
@pytest.mark.parametrize("role", ["reviewer", "maintainer"])
@pytest.mark.parametrize(
    "qualifier", ["after checking the", "before reviewing the", "following inspection of the"]
)
@pytest.mark.parametrize(
    "object_name", ["PR", "pull request", "PR body", "PR comments", "workflow artifacts"]
)
@pytest.mark.parametrize("operation", ["placed", "submitted", "delivered"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_review_related_actor_aside_preserves_delivery(
    auxiliary, role, qualifier, object_name, operation, destination, channel
):
    criterion = f"The {role}, {qualifier} {object_name}, {operation} evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The service, {qualifier} {object_name}, {auxiliary} put evidence in its database"
        )
        == set()
    )


@pytest.mark.parametrize("auxiliary", ["do", "does", "did"])
@pytest.mark.parametrize("actor", ["service", "API"])
@pytest.mark.parametrize("operation", ["put", "place", "write", "record"])
@pytest.mark.parametrize(
    "destination", ["in its database", "in the audit log", "to the assigned clients"]
)
def test_do_supported_product_storage_preserves_independent_delivery(
    auxiliary, actor, operation, destination
):
    criterion = f"The {actor} {auxiliary} {operation} evidence {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert (
        verifier._required_evidence_channels(criterion.replace(auxiliary, auxiliary + " not"))
        == set()
    )
    for review_destination, channel in [
        ("the PR body", "body"),
        ("a PR comment", "comments"),
        ("workflow artifacts", "artifacts"),
    ]:
        assert verifier._required_evidence_channels(
            criterion + f"; the reviewer must record evidence in {review_destination}"
        ) == {channel}


@pytest.mark.parametrize(
    "subject",
    [
        "The service must record evidence in its database",
        "Evidence must be recorded in its database by the service",
    ],
)
@pytest.mark.parametrize("separator", [", ", ", and ", " and "])
@pytest.mark.parametrize("preposition", ["in ", ""])
@pytest.mark.parametrize(
    "destinations", list(permutations(["the PR body", "a PR comment", "workflow artifacts"], 2))
)
def test_punctuated_shared_product_review_destinations(
    subject, separator, preposition, destinations
):
    criterion = (
        subject
        + separator
        + preposition
        + destinations[0]
        + separator
        + preposition
        + destinations[1]
    )
    channels = {
        "body" if "body" in d else "comments" if "comment" in d else "artifacts"
        for d in destinations
    }
    assert verifier._required_evidence_channels(criterion) == channels
    assert verifier._required_evidence_channels(criterion.replace("must ", "must not ")) == set()


@pytest.mark.parametrize("role", ["reviewer", "maintainer"])
@pytest.mark.parametrize(
    "qualifier", ["after validating the", "before checking the", "following inspection of the"]
)
@pytest.mark.parametrize(
    "evidence", ["output", "evidence", "artifacts", "transcript", "command output"]
)
@pytest.mark.parametrize("operation", ["placed", "submitted", "delivered"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_evidence_related_actor_aside_retains_outer_delivery(
    role, qualifier, evidence, operation, destination, channel
):
    aside = f"{qualifier} {evidence}"
    assert verifier._required_evidence_channels(
        f"The {role}, {aside}, {operation} evidence in {destination}"
    ) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The service, {aside}, {operation} evidence in its database"
        )
        == set()
    )


@pytest.mark.parametrize("role", ["reviewer", "maintainer", "author", "operator"])
@pytest.mark.parametrize(
    "parenthetical",
    [
        "however",
        "for example",
        "after checking CI",
        "in addition",
        "in particular",
        "at this point",
        "as noted above",
        "after initial validation",
    ],
)
@pytest.mark.parametrize("operation", ["placed", "submitted", "delivered", "wrote"])
def test_parenthetical_actor_preserves_active_past_delivery(role, parenthetical, operation):
    assert verifier._required_evidence_channels(
        f"The {role}, {parenthetical}, {operation} evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("apostrophe", ["'", "’"])
@pytest.mark.parametrize("actor", ["API", "service"])
def test_parenthetical_product_storage_and_quoted_contractions(actor, apostrophe):
    assert (
        verifier._required_evidence_channels(
            f"The {actor}, however, placed transcripts in its database"
        )
        == set()
    )
    quote_open, quote_close = ("'", "'") if apostrophe == "'" else ("‘", "’")
    assert verifier._required_evidence_channels(
        f"The parser must recognize {quote_open}The reviewer won{apostrophe}t place evidence in the PR body{quote_close}; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "inner",
    [
        "the maintainer recorded evidence in the PR body",
        "evidence was recorded in the PR body",
        "record evidence in the PR body",
        "the maintainer must record evidence in the PR body",
    ],
)
def test_parenthetical_does_not_erase_actual_delivery_predicates(inner):
    assert "body" in verifier._required_evidence_channels(
        f"The reviewer, {inner}, placed evidence in a PR comment"
    )


def test_parenthetical_normalization_preserves_independent_obligations_and_gates():
    assert verifier._required_evidence_channels(
        "Do not merge, without evidence in the PR body, until the reviewer placed evidence in a PR comment"
    ) == {"body", "comments"}
    assert "body" in verifier._required_evidence_channels(
        "The reviewer, the maintainer must place evidence in the PR body, placed evidence in a PR comment"
    )
    assert verifier._required_evidence_channels(
        'The parser must recognize "The reviewer, in addition, placed evidence in the PR body"; the maintainer must place evidence in a PR comment'
    ) == {"comments"}


@pytest.mark.parametrize(
    "quote_open,quote_close", [('"', '"'), ("'", "'"), ("“", "”"), ("‘", "’"), ("`", "`")]
)
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_quoted_later_storage_member_preserves_following_reviewer(
    quote_open, quote_close, destination, channel
):
    criterion = (
        "The API must record evidence in its database and record transcripts in its audit log; "
        f"the parser must recognize {quote_open}and record evidence in the PR body{quote_close}; "
        f"the reviewer must record evidence in {destination}"
    )
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize("apostrophe", ["'", "’"])
@pytest.mark.parametrize("operation", ["put", "place", "write", "paste"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
def test_multiple_contractions_do_not_form_a_quoted_literal(
    apostrophe, operation, destination, channel
):
    criterion = (
        f"The service won{apostrophe}t have put evidence in its database; "
        f"the reviewer must {operation} evidence in {destination}; "
        f"the operator couldn{apostrophe}t post artifacts"
    )
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize("modal", ["may", "can", "could", "would", "should", "would not"])
@pytest.mark.parametrize("governor", ["must", "shall", "needs to", "will"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_direct_storage_governor_reset_retains_mandatory_delivery(
    modal, governor, destination, channel
):
    criterion = f"The service {modal} record evidence in its database and {governor} record evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert (
        verifier._required_evidence_channels(
            criterion.replace(f"and {governor} record", f"and {governor} not record")
        )
        == set()
    )


@_semantic_matrix(
    dimensions={
        "destination,channel": [
            ["the PR body", "body"],
            ["a PR comment", "comments"],
            ["workflow artifacts", "artifacts"],
        ],
        "preposition": ["in ", ""],
        "operation": ["put", "placed", "recorded", "written"],
        "aspect,negative": [
            ["must be", "must not be"],
            ["has been", "has not been"],
            ["will be", "will not be"],
            ["was", "was not"],
            ["is", "is not"],
            ["has already been", "has not already been"],
            ["will have been", "will not have been"],
        ],
        "storage": ["in its database", "in the audit log", "to the assigned clients"],
        "actor": ["service", "API"],
    },
    semantic=("destination,channel", "preposition", "aspect,negative", "storage"),
    lexical_spines={
        "operation": ("aspect,negative", "preposition"),
        "actor": ("aspect,negative", "storage"),
    },
)
def test_passive_product_storage_shared_review_destination(
    actor, storage, aspect, negative, operation, preposition, destination, channel
):
    criterion = (
        f"Evidence {aspect} {operation} {storage} by the {actor} and {preposition}{destination}"
    )
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_channels(criterion.replace(aspect, negative)) == set()


@pytest.mark.parametrize("role", ["reviewer", "maintainer", "operator"])
@pytest.mark.parametrize(
    "adverbs",
    [
        "already",
        "now",
        "also",
        "still",
        "successfully",
        "already successfully",
        "also now successfully",
    ],
)
@pytest.mark.parametrize("operation", ["placed", "submitted", "delivered"])
@pytest.mark.parametrize(
    "destination,channel",
    [("the PR body", "body"), ("a PR comment", "comments"), ("workflow artifacts", "artifacts")],
)
def test_active_past_delivery_subject_adverbs(role, adverbs, operation, destination, channel):
    assert verifier._required_evidence_channels(
        f"The {role} {adverbs} {operation} evidence in {destination}"
    ) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The service {adverbs} {operation} evidence in its database"
        )
        == set()
    )


@pytest.mark.parametrize(
    "modal",
    [
        "could",
        "couldn't",
        "couldn’t",
        "wouldn't",
        "wouldn’t",
        "shouldn't",
        "shouldn’t",
        "may",
        "can",
        "should",
    ],
)
@pytest.mark.parametrize("operation", ["put", "place", "write", "record"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
def test_optional_modal_aliases_preserve_channels_and_contractions(
    modal, operation, destination, channel
):
    criterion = f"The reviewer {modal} {operation} evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + f"; the maintainer must record evidence in {destination}"
    ) == {channel}


@pytest.mark.parametrize("actor", ["API", "service"])
@pytest.mark.parametrize("operation", ["place", "write", "record"])
@pytest.mark.parametrize("conjunction", ["and", "or"])
def test_coordinated_product_storage_keeps_actor_and_delivery_scope(actor, operation, conjunction):
    criterion = f"The {actor} must record evidence in its database {conjunction} {operation} transcripts in its audit log"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(criterion.replace("must ", "must not ")) == set()
    for destination, channel in [
        ("a PR comment", "comments"),
        ("workflow artifacts", "artifacts"),
        ("the PR body", "body"),
    ]:
        assert verifier._required_evidence_channels(
            criterion + f"; the reviewer must record evidence in {destination}"
        ) == {channel}
        assert verifier._required_evidence_channels(
            criterion + f" and record evidence in {destination}"
        ) == {channel}


@pytest.mark.parametrize(
    "governor,operation,gating",
    [
        ("must", "record", True),
        ("must not", "record", False),
        ("has", "recorded", True),
        ("has not", "recorded", False),
        ("will have", "recorded", True),
        ("may", "record", False),
    ],
)
@pytest.mark.parametrize("conjunction", ["and", "or"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
@pytest.mark.parametrize(
    "continuation", ["internal", "inherited", "independent", "shared", "reset"]
)
def test_storage_coordination_governor_and_boundary_matrix(
    governor, operation, gating, conjunction, destination, channel, continuation
):
    chain = (
        f"The service {governor} {operation} evidence in its database "
        f"{conjunction} {operation} transcripts in its audit log"
    )
    expected = set()
    if continuation == "internal":
        chain += f" and {operation} command output in its storage"
    elif continuation == "inherited":
        chain += f" and {operation} evidence in {destination}"
        expected = {channel} if gating else set()
    elif continuation == "independent":
        chain += f" and the assigned reviewer must record evidence in {destination}"
        expected = {channel}
    elif continuation == "shared":
        chain += f" and in {destination}"
        expected = {channel} if gating else set()
    else:
        chain += f" and must record evidence in {destination}"
        expected = {channel}
    assert verifier._required_evidence_channels(chain) == expected


@pytest.mark.parametrize("preposition", ["in ", ""])
@pytest.mark.parametrize("polarity", ["", "not "])
def test_storage_coordination_shared_body_destination(polarity, preposition):
    chain = (
        f"The API must {polarity}record evidence in its database and record "
        f"transcripts in its audit log and {preposition}the PR body"
    )
    assert verifier._required_evidence_channels(chain) == (set() if polarity else {"body"})


def test_storage_coordination_parser_literal_and_unsupported_suffix():
    literal = "The API must record evidence in its database and record transcripts in its audit log"
    assert verifier._required_evidence_channels(
        f'The parser must recognize "{literal}"; the reviewer must record evidence in a PR comment'
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        literal + "; an independent reviewer must include evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize(
    "predicate", ["isn't", "isn’t", "aren't", "aren’t", "wasn't", "wasn’t", "weren't", "weren’t"]
)
@pytest.mark.parametrize("adverb", ["", "already ", "previously ", "still "])
@pytest.mark.parametrize("destination", ["in the database", "to clients"])
def test_contracted_finite_passive_put_preserves_negation(predicate, adverb, destination):
    criterion = f"Evidence {predicate} {adverb}put {destination} by the service"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "predicate",
    [
        "is not",
        "are not",
        "was not",
        "were not",
        "will not be",
        "must not be",
        "is never",
        "was no longer",
    ],
)
@pytest.mark.parametrize("operation", ["putting", "placing", "writing", "pasting", "recording"])
@pytest.mark.parametrize("destination", ["a PR comment", "workflow artifacts", "the PR body"])
def test_negated_progressive_delivery_has_no_channel(predicate, operation, destination):
    criterion = f"The reviewer {predicate} {operation} evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "predicate",
    [
        "is",
        "are",
        "was",
        "were",
        "is being",
        "was being",
        "is already",
        "was previously",
        "is not",
        "was never",
        "is no longer",
    ],
)
@pytest.mark.parametrize("operation", ["put", "placed", "written", "pasted", "recorded"])
@pytest.mark.parametrize("destination", ["in the database", "to clients"])
def test_finite_passive_product_storage_has_no_channel(predicate, operation, destination):
    criterion = f"Evidence {predicate} {operation} {destination} by the service"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("operation", ["record", "put", "place"])
@pytest.mark.parametrize("preposition", ["in ", ""])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
def test_product_storage_shared_review_destination(operation, preposition, destination, channel):
    criterion = (
        f"The service must {operation} evidence in its database and {preposition}{destination}"
    )
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_channels(criterion.replace("must ", "must not ")) == set()
    assert verifier._required_evidence_channels(
        criterion + "; the maintainer must include evidence in a PR comment"
    ) == {channel, "comments"}


@pytest.mark.parametrize("operation", ["put", "placed", "written", "pasted"])
@pytest.mark.parametrize("predicate", ["must be", "has been", "must have been"])
@pytest.mark.parametrize("destination", ["in the database", "to clients"])
def test_passive_product_aliases_share_bound_destination(operation, predicate, destination):
    criterion = f"Validation evidence {predicate} {operation} {destination} by the service"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("modal", ["may", "can", "could", "should"])
@pytest.mark.parametrize("operation", ["put", "place", "write", "paste"])
@pytest.mark.parametrize("destination", ["a PR comment", "workflow artifacts", "the PR body"])
def test_negated_optional_modal_alias_is_not_required(modal, operation, destination):
    criterion = f"The reviewer {modal} not {operation} evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; the maintainer must record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "predicate",
    ["must be recorded", "must have been recorded", "has been recorded", "is being recorded"],
)
@pytest.mark.parametrize("destination", ["the database", "the audit log"])
def test_passive_product_storage_preserves_independent_delivery(predicate, destination):
    criterion = f"Validation evidence {predicate} in {destination} by the service"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; the reviewer must record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "criterion",
    [
        "The service has written command output to clients",
        "The service must have written command output to clients",
        "The service is writing command output to clients",
        "Validation evidence must be written to clients by the service",
        "Validation evidence has been written to clients by the service",
        "Validation evidence must have been written to clients by the service",
    ],
)
def test_product_recipient_aspects_preserve_independent_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; the reviewer must record evidence in workflow artifacts"
    ) == {"artifacts"}


@pytest.mark.parametrize(
    "predicate", ["must record", "has recorded", "is recording", "must have recorded"]
)
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
def test_optional_case_object_is_not_optional_delivery(predicate, destination, channel):
    assert verifier._required_evidence_channels(
        f"The service must record transcripts in its database; the reviewer {predicate} optional-case test transcript in {destination}"
    ) == {channel}


@pytest.mark.parametrize(
    "auxiliary",
    [
        "has not",
        "have never",
        "had not",
        "has not already",
        "hasn't",
        "hadn’t",
        "will not have",
        "won’t have",
    ],
)
@pytest.mark.parametrize("verb", ["put", "placed", "pasted", "written", "recorded"])
@pytest.mark.parametrize("destination", ["a PR comment", "the PR body", "a workflow artifact"])
def test_perfect_negated_aliases_preserve_independent_delivery(auxiliary, verb, destination):
    criterion = f"The reviewer {auxiliary} {verb} validation evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; the maintainer must record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "auxiliary", ["has not yet", "hasn't yet", "had not yet", "won’t yet have"]
)
@pytest.mark.parametrize("verb", ["put", "placed", "recorded"])
def test_yet_perfect_negation_preserves_independent_delivery(auxiliary, verb):
    criterion = f"The reviewer {auxiliary} {verb} validation evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(criterion + "; record evidence in the PR body") == {
        "body"
    }


@pytest.mark.parametrize(
    "noun",
    [
        "validation evidence",
        "exact-head regression command output",
        "independently collected artifacts",
        "optional-case test transcript",
    ],
)
@pytest.mark.parametrize("verb", ["put", "placed", "recorded"])
def test_qualified_product_storage_preserves_independent_delivery(noun, verb):
    criterion = f"The service {verb} {noun} in its audit log"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("auxiliary", ["must", "shall", "needs to", "will"])
@pytest.mark.parametrize("aspect", ["put", "be putting", "have put", "have been placing"])
@pytest.mark.parametrize("noun", ["validation evidence", "regression command output"])
@pytest.mark.parametrize("destination", ["database", "audit log"])
def test_modal_product_storage_aspects_preserve_independent_delivery(
    auxiliary, aspect, noun, destination
):
    criterion = f"The service {auxiliary} {aspect} {noun} in its {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("boundary", [".", "!", "?"])
def test_sentence_product_clause_preserves_active_past_delivery(boundary):
    assert verifier._required_evidence_channels(
        f"The API must include command output{boundary} The reviewer placed evidence in a PR comment."
    ) == {"comments"}


@pytest.mark.parametrize(
    "auxiliary",
    [
        "will not have",
        "will never have",
        "will no longer have",
        "will also have",
        "will not already have",
    ],
)
@pytest.mark.parametrize("verb", ["placed", "put"])
def test_future_perfect_product_storage_modifier_positions(auxiliary, verb):
    criterion = f"The application {auxiliary} {verb} transcripts in its database"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "auxiliary", ["won't have", "won’t have", "won't already have", "won’t also have"]
)
@pytest.mark.parametrize("verb", ["placed", "put"])
def test_contracted_future_perfect_storage_preserves_independent_delivery(auxiliary, verb):
    criterion = f"The application {auxiliary} {verb} transcripts in its database"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("boundary", ["but", "while", "because", "whereas", "although"])
def test_compound_product_clause_preserves_active_past_placed(boundary):
    criterion = f"The API must include command output, {boundary} the reviewer placed evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize("auxiliary", ["has", "had", "will have"])
@pytest.mark.parametrize("verb", ["placed", "put"])
def test_perfect_product_storage_is_not_evidence(auxiliary, verb):
    criterion = f"The application {auxiliary} {verb} transcripts in its database"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("actor", ["assigned reviewer", "author", "maintainer", "API"])
@pytest.mark.parametrize("marker", ["- [ ]", "+ [X]", "1. [ ]"])
def test_active_past_placed_delivery_is_not_a_participial_modifier(actor, marker):
    assert verifier._required_evidence_channels(
        f"{marker} The {actor} placed validation evidence in a PR comment"
    ) == {"comments"}
    assert (
        verifier._required_evidence_channels("The application placed transcripts in its database")
        == set()
    )
    assert verifier._required_evidence_channels(
        "Record placed validation evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("verb", ["put", "place"])
@pytest.mark.parametrize(
    "destination,channel", [("a PR comment", "comments"), ("the PR body", "body")]
)
def test_put_place_share_review_delivery_boundaries(verb, destination, channel):
    criterion = f"The author must {verb} command output in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_channels(
        f"{verb.title()} the command output in {destination}"
    ) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The author must not {verb} command output in {destination}"
        )
        == set()
    )
    assert (
        verifier._required_evidence_channels(f"The API must {verb} command output in its database")
        == set()
    )


@pytest.mark.parametrize("verb", ["include", "contain", "have"])
@pytest.mark.parametrize("actor", ["API", "application", "service"])
def test_product_response_vocabulary_preserves_independent_review_delivery(verb, actor):
    criterion = f"The {actor} must {verb} command output"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        f"The reviewer must {verb} command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("verb", ["paste", "write"])
@pytest.mark.parametrize(
    "destination,channel", [("a PR comment", "comments"), ("the PR body", "body")]
)
def test_pasted_and_written_review_delivery(verb, destination, channel):
    criterion = f"The reviewer must {verb} command output into {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The reviewer must not {verb} command output into {destination}"
        )
        == set()
    )
    assert verifier._required_evidence_channels(
        criterion + "; the service must provide command output to clients"
    ) == {channel}


@pytest.mark.parametrize("modifier", ["supporting", "supporting execution", "validation"])
def test_modified_product_evidence_link_field(modifier):
    criterion = f"The API response must include links to {modifier} evidence"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; paste command output into a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("noun", ["Evidence", "Before/after evidence", "Command output"])
@pytest.mark.parametrize("requirement", ["required", "needed", "mandatory"])
def test_preposed_body_destination_consumes_complete_predicate(noun, requirement):
    criterion = f"{noun} in the PR body is {requirement}"
    assert verifier._required_evidence_channels(criterion) == {"body"}
    assert (
        verifier._required_evidence_channels(f"{noun} in the PR body is not {requirement}") == set()
    )
    assert verifier._required_evidence_channels(
        criterion + "; write command output into a PR comment"
    ) == {"body", "comments"}


@pytest.mark.parametrize("actor", ["service", "application", "API", "endpoint"])
def test_product_provides_output_without_erasing_review_delivery(actor):
    criterion = f"The {actor} must provide command output to clients"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; write command output into a PR comment"
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        "The reviewer must provide command output to a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize(
    "verb,canonical",
    [
        ("paste", "record"),
        ("pastes", "records"),
        ("pasted", "recorded"),
        ("pasting", "recording"),
        ("write", "record"),
        ("writes", "records"),
        ("written", "recorded"),
        ("writing", "recording"),
        ("wrote", "recorded"),
    ],
)
def test_delivery_lexical_aliases_share_existing_grammar(verb, canonical):
    for sentence in [
        "The reviewer must {verb} evidence in a PR comment",
        "Evidence must not be {verb} in a PR comment; record evidence in the PR body",
        "The application must {verb} transcripts in its database",
    ]:
        assert verifier._required_evidence_channels(sentence.format(verb=verb)) == (
            verifier._required_evidence_channels(sentence.format(verb=canonical))
        )


@pytest.mark.parametrize("participle", ["pasted", "written"])
def test_passive_delivery_alias_preserves_negation(participle):
    assert verifier._required_evidence_channels(
        f"Evidence must be {participle} in a PR comment"
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        f"Evidence must not be {participle} in a PR comment; record evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("status", ["not optional", "never optional", "no longer optional"])
@pytest.mark.parametrize(
    "criterion", ["Evidence in the PR body is {status}", "The PR body is {status}"]
)
def test_negated_optionality_is_mandatory_body_delivery(status, criterion):
    assert verifier._required_evidence_channels(criterion.format(status=status)) == {"body"}


@pytest.mark.parametrize("operation", ["write", "record", "paste"])
@pytest.mark.parametrize("destination", ["clients", "users", "consumers"])
def test_canonical_record_output_to_product_recipients(operation, destination):
    criterion = f"The service must {operation} command output to {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; write command output in a PR comment"
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        "The service must write command output in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("name", ["write", "paste"])
@pytest.mark.parametrize("quote", ["", "`", '"'])
def test_delivery_aliases_do_not_rewrite_command_names(name, quote):
    criterion = f"The {quote}{name}{quote} command must output evidence"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; paste command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("name", ["write evidence", "paste evidence"])
@pytest.mark.parametrize("quotes", [("`", "`"), ('"', '"'), ("'", "'"), ("“", "”")])
def test_alias_normalization_preserves_quoted_multitoken_names(name, quotes):
    criterion = f"The {quotes[0]}{name}{quotes[1]} command must output evidence"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; paste command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("name", ["write to disk", "paste into form", "write to the PR"])
@pytest.mark.parametrize("quote", ["", "`", '"'])
def test_alias_normalization_preserves_qualified_command_names(name, quote):
    criterion = f"The {quote}{name}{quote} command must output evidence"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; paste command output in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("operation", ["provide", "write", "return", "display", "emit", "render"])
@pytest.mark.parametrize(
    "destination,channel",
    [("workflow artifacts", "artifacts"), ("the PR", "overall"), ("the PR body", "body")],
)
def test_product_recipient_preserves_coordinated_review_delivery(operation, destination, channel):
    criterion = f"The service must {operation} command output to clients and in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_channels(
        criterion + "; paste command output in a PR comment"
    ) == {channel, "comments"}
    assert (
        verifier._required_evidence_channels(
            f"The service must {operation} command output to clients; must not attach it in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("operation", ["provide", "return", "display", "emit", "render", "expose"])
def test_product_shortcut_preserves_workflow_artifact_delivery(operation):
    criterion = f"The service must {operation} command output in workflow artifacts"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}


@pytest.mark.parametrize(
    "criterion,expected",
    [
        (
            "The service must provide command output to clients and in the PR body, a PR comment and workflow artifacts",
            {"body", "comments", "artifacts"},
        ),
        ("The UI must render command output to clients and in the PR body editor", set()),
        (
            "The UI must render command output to clients and in the PR body editor and workflow artifacts",
            {"artifacts"},
        ),
        (
            "The service must not provide command output to clients and in the PR body, a PR comment and workflow artifacts",
            set(),
        ),
    ],
)
def test_shared_destination_lists_preserve_review_and_editor_channels(criterion, expected):
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == expected | {"comments"}


@pytest.mark.parametrize("artifact_source", ["CI", "GitHub Actions"])
def test_recognized_artifact_destinations_share_body_channel_classification(artifact_source):
    criterion = f"The service must provide command output to clients and in the PR body and {artifact_source} artifacts"
    assert verifier._required_evidence_channels(criterion) == {"body", "artifacts"}
    assert (
        verifier._required_evidence_channels(criterion.replace("must provide", "must not provide"))
        == set()
    )


@pytest.mark.parametrize("modifier", ["written", "pasted"])
@pytest.mark.parametrize("operation", ["displays", "shows", "renders"])
def test_participial_alias_modifier_is_not_a_second_delivery(operation, modifier):
    criterion = f"- [ ] The UI {operation} {modifier} evidence to users"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; record evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("recipient", ["clients", "its users", "the consumers"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
def test_product_recipient_shared_destination_is_not_split(recipient, destination, channel):
    criterion = f"The service must provide command output to {recipient} and {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize(
    "auxiliary", ["has to", "have to", "is required to", "is expected to", "is obliged to"]
)
@pytest.mark.parametrize("operation", ["returned", "displayed", "provided"])
def test_shared_auxiliary_reaches_passive_review_requirement_gate(auxiliary, operation):
    criterion = f"Command output {auxiliary} be {operation} in a PR comment by the service"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    negative = f"Command output does not have to be {operation} in a PR comment by the service"
    assert verifier._required_evidence_channels(negative) == set()
    assert verifier._required_evidence_channels(negative + "; record evidence in the PR body") == {
        "body"
    }


@pytest.mark.parametrize("product", ["service", "API", "application", "endpoint"])
@pytest.mark.parametrize("verb", ["provided", "returned", "displayed"])
def test_reverse_product_output_retains_explicit_comment_delivery(product, verb):
    """An explicit review destination takes precedence over a product actor."""
    criterion = f"Command output must be {verb} in a PR comment by the {product}"
    assert verifier._required_evidence_channels(criterion) == {"comments"}


@pytest.mark.parametrize("actor", ["service", "API", "API response"])
@pytest.mark.parametrize(
    "object_,channel", [("artifacts", "artifacts"), ("command output", "overall")]
)
def test_product_provide_cannot_erase_explicit_pr_delivery(actor, object_, channel):
    criterion = f"The {actor} must provide {object_} in the PR"
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize(
    "criterion",
    [
        "Evidence is not written in a PR comment",
        "Evidence is not being pasted in a PR comment",
        "Never write evidence in a PR comment",
        "Never paste evidence in a PR comment",
    ],
)
def test_record_aliases_preserve_non_modal_prohibitions(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(criterion + "; record evidence in the PR body") == {
        "body"
    }


@pytest.mark.parametrize("participle", ["written", "pasted", "recorded"])
@pytest.mark.parametrize("recipient", ["clients", "users", "consumers"])
def test_reverse_record_output_binds_its_own_recipient(participle, recipient):
    criterion = f"Command output is {participle} to {recipient} by the service"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(criterion + "; write evidence in a PR comment") == {
        "comments"
    }


@pytest.mark.parametrize(
    "criterion,channel",
    [
        ("The reviewer must paste command output into a PR comment", "comments"),
        ("Test evidence in a PR comment", "comments"),
        ("Test evidence in the PR description", "body"),
        ("Command output must be in the PR description", "body"),
        ("Evidence in the PR body is required", "body"),
        ("Evidence in the PR body is not optional", "body"),
        ("Command output must be provided in a PR comment by the service", "comments"),
        ("The API response must include links to supporting evidence", None),
        ("The service must provide command output to clients", None),
        ("The service must write command output to clients", None),
        ("The service must provide artifacts in the PR", "artifacts"),
        ("The service must provide command output in the PR", "overall"),
        ("Evidence is not written in a PR comment", None),
        ("Command output is written to clients by the service", None),
        (
            "The service must provide command output to clients and in workflow artifacts",
            "artifacts",
        ),
        ("The service must provide command output to clients and in the PR", "overall"),
        ("The service must provide command output to clients and in the PR body", "body"),
        ("The service must provide command output to clients and in a PR comment", "comments"),
        ("The write to the PR command must output evidence", None),
        ("The release reviewer placed evidence in a PR comment", "comments"),
        ("The security reviewer submitted evidence in the PR body", "body"),
        ("The independent security auditor supplied evidence in workflow artifacts", "artifacts"),
    ],
)
@pytest.mark.parametrize("status", ["present", "absent", "unavailable"])
def test_fresh_canary_findings_control_actual_coverage_floor(criterion, channel, status):
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    if criterion.startswith("Test evidence in "):
        # This fixture starts with a plain bullet. The canary finding is an
        # actual checkbox noun phrase, not an ungoverned prose fragment.
        context = context.replace("- " + fixture.ACCEPTANCE_SENTINEL, "- [ ] " + criterion)
    else:
        context = context.replace(fixture.ACCEPTANCE_SENTINEL, criterion)
    context = context.replace(
        "## PR Diff Summary",
        f"## Acceptance evidence\n\n- Overall retrieval status: **{status if channel == 'overall' else 'absent'}**\n"
        f"- PR body: **{status if channel == 'body' else 'absent'}**\n"
        f"- PR comments: **{status if channel == 'comments' else 'absent'}**\n"
        f"- Referenced workflow artifacts: **{status if channel == 'artifacts' else 'absent'}**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if channel and status != "present" else "PASS")


@pytest.mark.parametrize("prefix", ["", "- [ ] "])
@pytest.mark.parametrize(
    "criterion",
    [
        "The reviewer is not required to have supplied evidence in workflow artifacts",
        "The reviewer may inspect whether the API has supply evidence in workflow artifacts",
        "The reviewer may inspect whether the API already has supply evidence in workflow artifacts",
        "The reviewer may inspect whether the API have currently supplies evidence in workflow artifacts",
        "The reviewer may inspect whether the API still had already supply evidence in workflow artifacts",
        "The reviewer may inspect whether the API no longer has supply evidence in workflow artifacts",
        "The reviewer may inspect whether the API never had supply evidence in workflow artifacts",
        "The reviewer may inspect whether the API has not supply evidence in workflow artifacts",
        "The reviewer is not required to have supplied evidence in workflow artifacts and already have recorded evidence in the PR body",
        "Command output must not be recorded in the PR body and be posted in workflow artifacts",
    ],
)
@pytest.mark.parametrize("positive", ["", "; The maintainer must record evidence in the PR body"])
@pytest.mark.parametrize("body_status", ["present", "absent", "unavailable"])
def test_negative_checklist_does_not_regain_actual_evidence_floor(
    prefix, criterion, positive, body_status
):
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace(
        "- " + fixture.ACCEPTANCE_SENTINEL, prefix + criterion + positive
    ).replace(
        "## PR Diff Summary",
        f"## Acceptance evidence\n\n- Overall retrieval status: **absent**\n- PR body: **{body_status}**\n- PR comments: **present**\n- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == ("CONCERNS" if positive and body_status != "present" else "PASS")


@pytest.mark.parametrize("prefix", ["", "- [ ] "])
@pytest.mark.parametrize(
    "status,expected", [("present", "PASS"), ("absent", "CONCERNS"), ("unavailable", "CONCERNS")]
)
def test_generated_docs_drift_body_requirement_controls_floor(prefix, status, expected):
    finding = fix_agent.Finding(
        source="semantic-scan",
        kind="semantic",
        doc_path="README.md",
        target="old claim",
        detail="stale",
        authoritative_source="scripts/example.py",
    )
    criterion = fix_agent.semantic_verification_requirements([finding])[0]
    assert "record the before/after evidence in the pull request body" in criterion
    assert verifier._required_evidence_channels(prefix + criterion) == {"body"}
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace(fixture.ACCEPTANCE_SENTINEL, prefix + criterion).replace(
        "## PR Diff Summary",
        f"## Acceptance evidence\n\n- Overall retrieval status: **absent**\n- PR body: **{status}**\n- PR comments: **absent**\n- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True),
        verifier.prompt_coverage(context, None),
    )
    assert result.verdict == expected


@pytest.mark.parametrize("modal", ["must", "shall", "needs to"])
def test_existential_comment_requirement(modal):
    channels = verifier._required_evidence_channels(
        f"- [ ] There {modal} be a PR comment with command output"
    )
    assert channels == {"comments"}


@pytest.mark.parametrize("operation", ["record", "capture", "attach", "generate"])
@pytest.mark.parametrize("actor", ["application", "service"])
def test_product_persistence_does_not_require_review_evidence(operation, actor):
    criterion = f"The {actor} must {operation} transcripts in its database"
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    assert verifier._required_evidence_channels(
        "- [ ] " + criterion + "; leave a PR comment with command output"
    ) == {"comments"}
    assert (
        verifier._required_evidence_channels(
            f"- [ ] The {actor} must {operation} transcripts in the PR"
        )
        != set()
    )


@pytest.mark.parametrize("operation", ["return", "display", "emit", "render", "expose"])
def test_product_delivery_operations_share_the_body_channel(operation):
    criterion = f"The service must {operation} evidence in the PR body"
    assert verifier._required_evidence_channels(criterion) == {"body"}
    assert (
        verifier._required_evidence_channels(
            f"The service must not {operation} evidence in the PR body"
        )
        == set()
    )
    assert verifier._required_evidence_channels(
        criterion + "; record command output in a PR comment"
    ) == {"body", "comments"}


@pytest.mark.parametrize("determiner", ["the", "its", "our", "all the", "all its"])
@pytest.mark.parametrize("recipient", ["clients", "users", "consumers"])
def test_forward_and_reverse_record_share_determined_recipients(determiner, recipient):
    for criterion in [
        f"The service must write command output to {determiner} {recipient}",
        f"Command output is written to {determiner} {recipient} by the service",
    ]:
        assert verifier._required_evidence_channels(criterion) == set()
        assert verifier._required_evidence_channels(
            criterion + "; record command output in a PR comment"
        ) == {"comments"}


@pytest.mark.parametrize(
    "auxiliary",
    [
        "needs to",
        "need to",
        "has to",
        "have to",
        "is required to",
        "is expected to",
        "is supposed to",
        "is obliged to",
        "is mandated to",
    ],
)
@pytest.mark.parametrize(
    "destination,channel", [("the PR", "overall"), ("a PR comment", "comments")]
)
def test_reverse_review_delivery_shares_mandatory_auxiliaries(auxiliary, destination, channel):
    criterion = f"Command output {auxiliary} be provided in {destination} by the service"
    assert verifier._required_evidence_channels(criterion) == {channel}


@pytest.mark.parametrize("determiner", ["the", "a", "an"])
def test_reversed_product_fields_allow_determiners(determiner):
    criterion = f"The API response must include links to {determiner} evidence"
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    assert verifier._required_evidence_channels(
        "- [ ] " + criterion + "; record evidence in a PR comment"
    ) == {"comments"}


def test_body_is_its_own_evidence_channel():
    assert verifier._required_evidence_channels(
        "- [ ] Include evidence in both a PR comment and the PR body"
    ) == {"comments", "body"}
    assert verifier._required_evidence_channels(
        "- [ ] Include before/after evidence in the PR body"
    ) == {"body"}
    assert not verifier._required_evidence_is_missing(
        "- PR body: **present**\n- PR comments: **absent**\n"
        "- Referenced workflow artifacts: **absent**",
        {"body"},
    )


@pytest.mark.parametrize(
    "status, verdict", [("present", "PASS"), ("absent", "CONCERNS"), ("unavailable", "CONCERNS")]
)
def test_actual_body_channel_controls_full_coverage_floor(status, verdict):
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace(
        fixture.ACCEPTANCE_SENTINEL, "Include before/after evidence in the PR body"
    )
    context = context.replace(
        "## PR Diff Summary",
        f"## Acceptance evidence\n\n- Overall retrieval status: **absent**\n- PR body: **{status}**\n- PR comments: **absent**\n- Referenced workflow artifacts: **absent**\n\n## PR Diff Summary",
    )
    coverage = verifier.prompt_coverage(context, None)
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True), coverage
    )
    assert result.verdict == verdict
    assert verifier._required_evidence_is_missing(
        "- PR body: **absent**\n- PR comments: **present**\n"
        "\n### Bounded PR body\n- PR body: **present**",
        {"body"},
    )


@pytest.mark.parametrize("verdict", ["CONCERNS", "FAIL"])
def test_nonpass_text_retains_actionable_concerns_and_raw_detail(verdict):
    result = verifier.EvaluationResult(
        verdict=verdict,
        summary="Short summary",
        concerns=["Missing exact-head witness"],
        raw_content="Detailed model explanation",
        used_llm=True,
    )
    text = verifier._evaluation_output_text(result)
    assert text.startswith(f"Verdict: {verdict}")
    assert "Short summary" in text
    assert "Missing exact-head witness" in text
    assert "Detailed model explanation" in text


@pytest.mark.parametrize("wrapper", ["Here is the result:\n{}", "```json\n{}\n```"])
def test_failed_repair_does_not_render_wrapped_stale_pass(monkeypatch, wrapper):
    raw = wrapper.format('{"verdict": "PASS", "summary": "Unvalidated result"}')
    monkeypatch.setattr(
        verifier, "_build_verifier_repair_callback", lambda _client: lambda *_args: None
    )
    result = verifier._parse_llm_response(raw, "test-provider", client=object())
    assert result.verdict == "CONCERNS"
    assert result.error
    text = verifier._evaluation_output_text(result)
    assert text.startswith("Verdict: CONCERNS")
    assert '"verdict": "PASS"' not in text


@pytest.mark.parametrize("wrapper", ["Explanation:\n{}", "```json\n{}\n```"])
def test_wrapped_nonpass_detail_is_preserved(wrapper):
    raw = wrapper.format('{"verdict": "CONCERNS", "detail": "Missing exact-head witness"}')
    result = verifier.EvaluationResult(verdict="CONCERNS", raw_content=raw)
    assert "Missing exact-head witness" in verifier._evaluation_output_text(result)


@pytest.mark.parametrize(
    "raw",
    [
        'Schema example: {"verdict":"PASS"}. Missing exact-head witness; repair failed.',
        '{"verdict":"CONCERNS","example":{"verdict":"PASS"},"detail":"Missing exact-head witness"}',
    ],
)
def test_incidental_pass_object_does_not_erase_actionable_diagnostics(raw):
    result = verifier.EvaluationResult(verdict="CONCERNS", raw_content=raw)
    text = verifier._evaluation_output_text(result)
    assert "Missing exact-head witness" in text
    assert '"verdict":"PASS"' not in text


@pytest.mark.parametrize(
    "criterion",
    [
        "The PR body must not include evidence",
        "The pull request body shall not include evidence",
        "Evidence must not be included in the PR body",
        "The PR body is not required",
        "The PR body does not need to include evidence",
        "The PR body is not required to include evidence",
        "The PR body must never include evidence",
        "Evidence must never be included in the PR body",
        "Evidence shall never be included in the PR body",
        "There must not be evidence in the PR body",
        "Evidence must not be shown in the PR body",
        "Evidence must not be added in the PR body",
    ],
)
def test_negated_body_delivery_does_not_require_evidence(criterion):
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    channels = verifier._required_evidence_channels(
        "- [ ] " + criterion + "; include evidence in a PR comment"
    )
    assert channels == {"comments"}


@pytest.mark.parametrize(
    "criterion",
    [
        "Evidence is required in the PR body",
        "There must be evidence in the PR body",
    ],
)
def test_equivalent_body_obligations_keep_destination_specific_floor(criterion):
    channels = verifier._required_evidence_channels("- [ ] " + criterion)
    assert channels == {"body"}
    mixed = verifier._required_evidence_channels(
        "- [ ] " + criterion + "; the reviewer must post a PR comment with command output"
    )
    assert mixed == {"comments", "body"}
    assert verifier._required_evidence_is_missing(
        "- Overall retrieval status: **present**\n- PR body: **absent**\n"
        "- PR comments: **present**\n- Referenced workflow artifacts: **present**",
        mixed,
    )


@pytest.mark.parametrize("actor", ["UI", "application", "service"])
@pytest.mark.parametrize("operation", ["should show", "must include"])
def test_body_editor_product_output_is_not_a_reviewer_deliverable(actor, operation):
    criterion = f"The {actor} {operation} evidence in the pull request body editor"
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    channels = verifier._required_evidence_channels(
        "- [ ] " + criterion + "; include evidence in the PR body"
    )
    assert channels == {"body"}
    human = verifier._required_evidence_channels(
        "- [ ] The reviewer of the UI must show evidence in the PR body"
    )
    assert human == {"body"}


BODY_CLAUSE_CASES = []
for modal in ("must", "shall"):
    for polarity in ("", "not ", "never "):
        expected = {"body"} if not polarity else set()
        for aspect in ("be", "have been", "have been being"):
            BODY_CLAUSE_CASES.append(
                (f"Evidence {modal} {polarity}{aspect} included in the PR body", expected)
            )
        for operation in ("include", "contain", "show"):
            BODY_CLAUSE_CASES.append(
                (f"The PR body {modal} {polarity}{operation} evidence", expected)
            )
for modal in ("must", "shall", "needs to"):
    for polarity in ("", "not ", "never "):
        BODY_CLAUSE_CASES.append(
            (
                f"There {modal} {polarity}be evidence in the PR body",
                {"body"} if not polarity else set(),
            )
        )
for actor in ("UI", "application", "service"):
    for operation in ("include", "show", "store"):
        for modal in ("must", "should"):
            BODY_CLAUSE_CASES.append(
                (f"The {actor} {modal} {operation} evidence in the pull request body editor", set())
            )
BODY_CLAUSE_CASES.extend(
    [
        ("The PR body must contain no before/after evidence", set()),
        ("There must be no before/after evidence in the PR body", set()),
        ("Record no before/after evidence in the pull request body", set()),
        ("The PR body must not exclude the before/after evidence", {"body"}),
        ("Evidence must be included in a PR comment and in the PR body", {"body", "comments"}),
        ("Evidence must be included in the PR body and in a PR comment", {"body", "comments"}),
        ("The PR body must exclude evidence", set()),
        ("The PR body must omit evidence", set()),
        ("The PR body must remove evidence", set()),
        ("The PR body must not exclude evidence", {"body"}),
        ("The UI allows users to show evidence in the pull request body editor", set()),
        ("The UI enables users to show evidence in the pull request body editor", set()),
        ("The UI supports users to show evidence in the pull request body editor", set()),
        ("The PR body must contain no evidence", set()),
        ("The PR body must include no evidence", set()),
        ("No evidence must be included in the PR body", set()),
        (
            "The UI must include evidence in both workflow artifacts and the PR body editor",
            {"artifacts"},
        ),
        ("The UI must include evidence in both a PR comment and the PR body editor", {"comments"}),
        ("The UI must contain evidence in the PR body editor", set()),
        ("Include evidence in both the PR body and a PR comment", {"body", "comments"}),
        ("Evidence must be included in the PR body with optional artifacts", {"body"}),
        ("The reviewer of the UI must include evidence in the PR body", {"body"}),
        ("The UI must include evidence in the PR body", {"body"}),
        ("The engineer must include evidence in the PR body", {"body"}),
        ("Do not merge without evidence in the PR body", {"body"}),
        (
            "The UI must show evidence in the pull request body editor that the reviewer must include in the PR body",
            {"body"},
        ),
    ]
)
for destinations in permutations(("the PR body", "a PR comment", "a workflow artifact")):
    for separator in (" and ", ", "):
        BODY_CLAUSE_CASES.append(
            (
                "Evidence must be included in " + separator.join(destinations),
                {"body", "comments", "artifacts"},
            )
        )
    BODY_CLAUSE_CASES.append(
        (
            "Evidence must be included in " + " and in ".join(destinations),
            {"body", "comments", "artifacts"},
        )
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The PR body must include a summary",
        "The parser must recognize headings in the PR body",
        "The PR body must be formatted as Markdown",
    ],
)
def test_ordinary_body_behavior_is_not_an_evidence_delivery(criterion):
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    assert verifier._required_evidence_channels(
        "- [ ] " + criterion + "; include evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("criterion,expected", BODY_CLAUSE_CASES)
@pytest.mark.parametrize("prefix", ["- ", "- [ ] "])
@pytest.mark.parametrize("comment_position", ["none", "before", "after", "and"])
def test_body_clause_matrix_preserves_independent_destinations(
    criterion, expected, prefix, comment_position
):
    comment = "the reviewer must post a PR comment with command output"
    if comment_position == "before":
        criterion = comment + "; " + criterion
    elif comment_position == "after":
        criterion += "; " + comment
    elif comment_position == "and":
        criterion += " and " + comment
    expected = expected | ({"comments"} if comment_position != "none" else set())
    actual = verifier._required_evidence_channels(prefix + criterion)
    assert actual == expected


@pytest.mark.parametrize("criterion,expected", BODY_CLAUSE_CASES)
@pytest.mark.parametrize("status", ["present", "absent", "unavailable"])
@pytest.mark.parametrize("channel", ["body", "comments", "artifacts"])
def test_body_clause_matrix_controls_real_coverage_floor(criterion, expected, status, channel):
    fixture = _COVERAGE_FIXTURE
    context, _ = fixture._context(1, 1000, 1000)
    context = context.replace(fixture.ACCEPTANCE_SENTINEL, criterion)
    statuses = {
        name: status if name == channel else "present" for name in ("body", "comments", "artifacts")
    }
    context = context.replace(
        "## PR Diff Summary",
        "## Acceptance evidence\n\n- Overall retrieval status: **present**\n"
        f"- PR body: **{statuses['body']}**\n- PR comments: **{statuses['comments']}**\n"
        f"- Referenced workflow artifacts: **{statuses['artifacts']}**\n\n## PR Diff Summary",
    )
    coverage = verifier.prompt_coverage(context, None)
    result = verifier._apply_coverage_floor(
        verifier.EvaluationResult(verdict="PASS", used_llm=True), coverage
    )
    assert result.verdict == ("CONCERNS" if channel in expected and status != "present" else "PASS")


@pytest.mark.parametrize("predicate", ["must describe the change", "should describe the change"])
def test_product_recipient_does_not_absorb_independent_review_predicate(predicate):
    criterion = f"The service must provide command output to clients, and the PR body {predicate}"
    assert verifier._required_evidence_channels("- [ ] " + criterion) == set()
    assert verifier._required_evidence_channels(
        "- [ ] " + criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("operation", ["presents", "sends", "delivers"])
@pytest.mark.parametrize("modifier", ["written", "pasted"])
def test_product_participial_modifiers_do_not_depend_on_governing_verb_allowlist(
    operation, modifier
):
    criterion = f"The UI {operation} {modifier} evidence to users"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("artifact_source", ["workflow", "CI", "GitHub Actions"])
def test_named_review_artifact_delivery_object_is_preserved(artifact_source):
    criterion = f"The service must provide {artifact_source} artifacts"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert (
        verifier._required_evidence_channels(
            "The service must not provide " + artifact_source + " artifacts"
        )
        == set()
    )


@pytest.mark.parametrize("operation", ["return", "display", "emit", "render", "expose"])
def test_shared_response_operations_retain_explicit_comment_delivery(operation):
    assert verifier._required_evidence_channels(
        f"The reviewer must {operation} evidence in a PR comment"
    ) == {"comments"}
    assert (
        verifier._required_evidence_channels(
            f"The reviewer must not {operation} evidence in a PR comment"
        )
        == set()
    )


@pytest.mark.parametrize("auxiliary", ["must", "shall", "has to"])
def test_modal_negated_body_optionality_remains_mandatory(auxiliary):
    assert verifier._required_evidence_channels(
        f"Evidence in the PR body {auxiliary} not be optional"
    ) == {"body"}


@pytest.mark.parametrize("modifier", ["required", "generated", "audit", "release"])
def test_positive_modified_artifact_delivery_survives_product_shortcut(modifier):
    criterion = f"The service must provide {modifier} evidence in workflow artifacts"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert (
        verifier._required_evidence_channels(
            "The service must not provide " + modifier + " evidence in workflow artifacts"
        )
        == set()
    )


@pytest.mark.parametrize(
    "passive",
    [
        "has not been written",
        "had never been pasted",
        "can not be written",
        "has not been freshly written",
        "had never been previously pasted",
        "can not be manually written",
    ],
)
def test_perfect_and_modal_passive_aliases_preserve_prohibition(passive):
    criterion = f"Evidence {passive} in a PR comment"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("negation", ["never", "no longer"])
@pytest.mark.parametrize("operation", ["return", "display", "emit", "render", "expose"])
def test_negated_obligations_preserve_response_operation_polarity(negation, operation):
    criterion = f"The reviewer is {negation} required to {operation} evidence in a PR comment"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize("operation", ["write", "paste"])
@pytest.mark.parametrize(
    "destination", ["outside a PR comment", "in the issue rather than a PR comment"]
)
def test_excluded_comment_destination_retains_generic_evidence_not_comment(operation, destination):
    criterion = f"The reviewer must {operation} evidence {destination}"
    assert verifier._required_evidence_channels(criterion) == {"overall"}
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"overall", "comments"}


@pytest.mark.parametrize(
    "destination,channel",
    [("workflow artifacts", "artifacts"), ("a PR comment", "comments"), ("the PR body", "body")],
)
def test_coordinated_evidence_object_inherits_governing_delivery(destination, channel):
    assert verifier._required_evidence_channels(
        f"The service must provide command output to clients and evidence in {destination}"
    ) == {channel}
    assert (
        verifier._required_evidence_channels(
            f"The service must not provide command output to clients and evidence in {destination}"
        )
        == set()
    )


@pytest.mark.parametrize("participle", ["written", "pasted"])
def test_alias_and_shared_destination_grammar_preserve_both_prefix(participle):
    assert verifier._required_evidence_channels(
        f"Evidence must be {participle} in both the PR body and a PR comment"
    ) == {"body", "comments"}
    assert (
        verifier._required_evidence_channels(
            f"Evidence must not be {participle} in both the PR body and a PR comment"
        )
        == set()
    )


@pytest.mark.parametrize("modal", ["may", "can", "should"])
@pytest.mark.parametrize("operation", ["write", "paste"])
@pytest.mark.parametrize("destination", ["a PR comment", "workflow artifacts", "the PR body"])
def test_optional_delivery_modal_does_not_become_a_mandatory_alias(modal, operation, destination):
    criterion = f"The reviewer {modal} {operation} evidence in {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_channels(
        criterion + "; include evidence in a PR comment"
    ) == {"comments"}


@_semantic_matrix(
    dimensions={
        "independent": [False, True],
        "predicate": [
            "must upload",
            "must not upload",
            "may upload",
            "uploaded",
            "uploads",
            "recorded",
            "puts",
            "has uploaded",
            "had uploaded",
            "was uploading",
            "has already uploaded",
            "has not uploaded",
        ],
        "separator": [", and ", "; ", ". "],
        "preposition": ["in", "into", "to", "within", "for", "as", "through", "via"],
        "proof": ["screenshots", "test results", "validation logs"],
    },
    semantic=("independent", "predicate", "separator", "preposition"),
    lexical_spines={"proof": ("predicate", "separator")},
)
def test_common_proof_pronoun_reuses_shared_finite_destination_grammar(
    proof, preposition, separator, predicate, independent
):
    criterion = f"The UI must display {proof}{separator}the reviewer {predicate} them {preposition} the PR body"
    canonical = criterion.replace(proof, "evidence", 1)
    expected = (
        set() if predicate in {"must not upload", "may upload", "has not uploaded"} else {"body"}
    )
    if independent:
        suffix = "; the reviewer must record evidence in a PR comment"
        criterion += suffix
        canonical += suffix
        expected.add("comments")
    assert verifier._required_evidence_channels(canonical) == expected
    assert verifier._required_evidence_channels(criterion) == expected


@_semantic_matrix(
    dimensions={
        "independent": [False, True],
        "preposition": ["in", "into", "to", "within", "for", "as", "through", "via"],
        "predicate": [
            "has been uploaded",
            "is being uploaded",
            "had been uploaded",
            "was uploaded",
            "uploaded",
            "must be uploaded",
            "has not been uploaded",
            "may be uploaded",
        ],
        "qualifier": ["the session", "posted output", "required scenarios"],
        "proof": ["A recording", "Recordings", "Screenshots", "Test results", "Validation output"],
    },
    semantic=("independent", "preposition", "predicate"),
    lexical_spines={
        "qualifier": ("predicate", "preposition"),
        "proof": ("predicate", "preposition"),
    },
)
def test_qualified_common_proof_reuses_shared_governor_boundary(
    proof, qualifier, predicate, preposition, independent
):
    criterion = f"{proof} of {qualifier} {predicate} {preposition} the PR body"
    canonical = f"Evidence {predicate} {preposition} the PR body"
    # Bare participial descriptors retain the canonical generic-evidence policy;
    # this normalization repair must not introduce a new body-specific gate.
    expected = (
        set()
        if predicate in {"has not been uploaded", "may be uploaded"}
        else {"overall"} if predicate == "uploaded" else {"body"}
    )
    if independent:
        suffix = "; the reviewer must record evidence in a PR comment"
        criterion += suffix
        canonical += suffix
        expected.add("comments")
    assert verifier._required_evidence_channels(canonical) == expected
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("proof", ["A recording", "Screenshots"])
@pytest.mark.parametrize(
    "qualifier",
    [
        "in-depth sessions",
        "for-sale scenarios",
        "has-been services",
        "optional scenarios",
        "no longer required cases",
        "and/or cases",
    ],
)
@pytest.mark.parametrize(
    "predicate", ["has been uploaded", "is being uploaded", "was uploaded", "has not been uploaded"]
)
@pytest.mark.parametrize("preposition", ["in", "via"])
@pytest.mark.parametrize("independent", [False, True])
def test_qualified_common_proof_modifier_tokens_are_not_governor_prefixes(
    proof, qualifier, predicate, preposition, independent
):
    criterion = f"{proof} of {qualifier} {predicate} {preposition} the PR body"
    expected = set() if predicate == "has not been uploaded" else {"body"}
    if independent:
        criterion += "; the reviewer must record evidence in a PR comment"
        expected.add("comments")
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize(
    "criterion,channel",
    [
        ("Attach evidence as an artifact", "artifacts"),
        ("Upload the coverage report as an artifact", "artifacts"),
        ("Publish validation output as a workflow artifact", "artifacts"),
        ("Evidence must be posted in a PR review comment", "comments"),
        ("Evidence must be posted in a PR inline review comment", "comments"),
        ("Evidence must be posted in an inline review comment", "comments"),
        ("Evidence must be posted in a pull request review comment", "comments"),
        ("- [ ] Validation output in a PR comment", "comments"),
        ("- [x] Validation output in a PR comment", "comments"),
        ("- [X] Validation output in a PR comment", "comments"),
        ("- [ ] Validation results in a PR comment", "comments"),
        ("- [x] Validation results in a PR comment", "comments"),
        ("- [X] Validation results in a PR comment", "comments"),
        ("- [ ] Validation results in a PR review comment", "comments"),
    ],
)
def test_issue3835_delivery_destinations(criterion, channel):
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_options(criterion) == [{channel}]


@pytest.mark.parametrize(
    "criterion",
    [
        "Do not attach evidence as an artifact",
        "No need to attach evidence as an artifact",
        "No requirement to upload the coverage report as an artifact",
        "No obligation to publish validation output as a workflow artifact",
        "No need to post evidence in a PR review comment",
        "No requirement to record evidence in the PR body",
        "No requirement exists to attach evidence as an artifact",
        "No need exists to post evidence in a PR review comment",
        "No obligation exists to record evidence in the PR body",
        "The inline review comment UI must display evidence",
        "The PR review comment API must return evidence",
        "The PR comment UI must display evidence",
        "The inline comment renderer must show evidence",
        "Evidence may be attached as an artifact",
        "The UI allows users to attach evidence as an artifact",
        "The service uploads evidence as an artifact to storage",
        'The parser recognizes "Attach evidence as an artifact"',
        "Evidence must not be posted in a PR review comment",
        "Evidence may be posted in an inline review comment",
        "The UI allows users to post evidence in a PR review comment",
        'The parser recognizes "Evidence must be posted in a PR review comment"',
        "- [ ] Validation output in a PR comment is optional",
        "- [ ] Validation output in a PR comment is not required",
        "- [ ] Validation output in a PR comment may be skipped",
        "- [ ] Validation results in a PR comment only if available",
        "The product can show Validation output in a PR comment",
        "The UI must allow Validation output in a PR comment",
        "The UI allows users to record validation output in a PR comment",
        'The parser recognizes "- [ ] Validation output in a PR comment"',
    ],
)
@pytest.mark.parametrize("independent", [None, "comments", "artifacts"])
@pytest.mark.parametrize("status", ["absent", "unavailable", "present"])
def test_issue3835_nongating_controls(criterion, independent, status):
    """Exempt clauses neither require evidence nor erase independent delivery."""
    delivery = {
        "comments": "; the reviewer must post evidence in a PR comment",
        "artifacts": "; the reviewer must attach evidence as an artifact",
    }
    criterion += delivery.get(independent, "")
    expected = {independent} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert _floor_verdict(criterion, body="present", comments=status, artifacts=status) == (
        "CONCERNS" if independent and status != "present" else "PASS"
    )


@pytest.mark.parametrize(
    "operation", ["Attach", "Upload", "Publish", "Record", "Provide", "Share", "Submit", "Deliver"]
)
def test_issue3835_as_artifact_reuses_shared_delivery_operations(operation):
    """Canonical delivery operations and their aliases retain the artifact floor."""
    criterion = f"{operation} evidence as an artifact"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == (
        "CONCERNS"
    )


def test_issue3835_review_comment_alternative_keeps_shared_options():
    criterion = "Evidence must be posted in a PR review comment or in the PR body"
    assert verifier._required_evidence_options(criterion) == [{"comments"}, {"body"}]


def test_issue3835_optional_validation_output_keeps_independent_mandatory():
    """Post-destination optionality must not invent overall or mask a sibling delivery."""
    optional = "- [ ] Validation output in a PR comment is optional"
    assert verifier._required_evidence_channels(optional) == set()
    assert verifier._required_evidence_channels(
        optional + "; provide command output in a PR comment"
    ) == {"comments"}
    assert verifier._required_evidence_channels(
        optional + "; the reviewer must record evidence in the PR body"
    ) == {"body"}


@pytest.mark.parametrize(
    "destination",
    ["PR review comment", "pull request review comment", "inline review comment", "review comment"],
)
@pytest.mark.parametrize(
    "criterion",
    [
        "A {destination} is required",
        "The reviewer must leave a {destination}",
        "The reviewer must leave at least one {destination}",
        "The reviewer must leave a detailed {destination}",
        "Test results must be posted in a {destination}",
    ],
)
def test_issue3835_review_alias_discovery_and_missing_floor(destination, criterion):
    text = criterion.format(destination=destination)
    assert verifier._required_evidence_channels(text) == {"comments"}
    assert verifier._required_evidence_options(text) == [{"comments"}]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(text, body="present", comments=missing) == "CONCERNS"


@pytest.mark.parametrize(
    "destination",
    ["PR review comment", "pull request review comment", "inline review comment", "review comment"],
)
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_review_alias_or_destinations(destination, reverse, independent):
    choices = ["the PR body", "a " + destination]
    if reverse:
        choices.reverse()
    text = "Evidence must be posted in either " + " or ".join(choices)
    suffix = "; the auditor must upload evidence in a workflow artifact" if independent else ""
    options = verifier._required_evidence_options(text + suffix)
    extra = {"artifacts"} if independent else set()
    assert {frozenset(option) for option in options} == {
        frozenset({"body"} | extra),
        frozenset({"comments"} | extra),
    }
    assert _floor_verdict(text + suffix, body="present", comments="absent") == "PASS"
    assert _floor_verdict(text + suffix, body="absent", comments="present") == "PASS"
    assert _floor_verdict(text + suffix, body="absent", comments="absent") == "CONCERNS"
    if independent:
        assert (
            _floor_verdict(text + suffix, body="present", comments="present", artifacts="absent")
            == "CONCERNS"
        )


@pytest.mark.parametrize(
    "destination", ["PR review comment", "inline review comment", "review comment"]
)
@pytest.mark.parametrize(
    "text",
    [
        "A {destination} is not required",
        "A {destination} is no longer required",
        "The reviewer is not expected to leave a {destination}",
        "The reviewer is not supposed to leave a {destination}",
        "No {destination} is required",
        "The UI allows users to leave a {destination}",
        'The parser recognizes "A {destination} is required"',
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_review_alias_polarity_and_product_controls(destination, text, independent):
    criterion = text.format(destination=destination)
    if independent:
        criterion += "; the auditor must post evidence in the PR body"
    expected = {"body"} if independent else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]


@pytest.mark.parametrize(
    "text",
    [
        "Copy the command output into a PR comment",
        "The reviewer must copy optional archived evidence into a PR comment",
        "Evidence must be copied into a PR comment",
        "- [ ] PR comment with test evidence",
    ],
)
def test_issue3835_retained_canary_counterexamples(text):
    assert verifier._required_evidence_channels(text) == {"comments"}
    assert verifier._required_evidence_options(text) == [{"comments"}]
    assert _floor_verdict(text, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    "text",
    [
        "Do not copy command output into a PR comment",
        "No need to copy evidence into a PR comment",
        "The reviewer is not expected to copy evidence into a PR comment",
        "The reviewer is not supposed to copy evidence into a PR comment",
        "Evidence must not be copied into a PR comment",
        "Evidence may be copied into a PR comment",
        "The UI allows users to copy evidence into a PR comment",
        "The UI allows users to copy and copy evidence into a PR comment",
        "Evidence can be copied into a PR comment by the application",
        "- [ ] PR comment with test evidence is optional",
        "- [ ] PR comment with test evidence is no longer required",
        "- [ ] PR comment with test evidence only if available",
        'The parser recognizes "Copy the command output into a PR comment"',
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_copy_and_destination_first_controls(text, independent):
    if independent:
        text += "; the reviewer must record evidence in the PR body"
    expected = {"body"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]


@pytest.mark.parametrize(
    "text",
    [
        "The reviewer may copy and copy evidence into a PR comment",
        "Do not copy and copy evidence into a PR comment",
        "The UI must allow evidence to be provided as an artifact",
        "The UI must allow evidence to be attached as an artifact",
        "The UI allows reviewers to copy evidence into a PR comment and copy evidence into the PR body",
        "The UI allows reviewers to record evidence into a PR comment and record evidence into the PR body",
        "Attach evidence as an artifact, which may be skipped",
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_assessment_nongating_counterexamples(text, independent):
    if independent:
        text += "; the auditor must upload evidence in a workflow artifact"
    expected = {"artifacts"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    assert _floor_verdict(text, body="present", comments="present", artifacts="absent") == (
        "CONCERNS" if independent else "PASS"
    )


@pytest.mark.parametrize("qualifier", ["not expected", "not supposed", "no longer required"])
def test_issue3835_copy_object_polarity_is_not_governor(qualifier):
    text = f"The reviewer must copy {qualifier} validation output into a PR comment"
    assert verifier._required_evidence_channels(text) == {"comments"}
    assert _floor_verdict(text, body="present", comments="absent") == "CONCERNS"


def test_issue3835_destination_first_alternative_uses_shared_normalization():
    text = "- [ ] PR comment with test evidence or in the PR body"
    assert verifier._required_evidence_options(text) == [{"comments"}, {"body"}]
    assert _floor_verdict(text, body="present", comments="absent") == "PASS"
    assert _floor_verdict(text, body="absent", comments="present") == "PASS"
    assert _floor_verdict(text, body="absent", comments="absent") == "CONCERNS"


@pytest.mark.parametrize("operation", ["copy", "record", "post", "provide"])
@pytest.mark.parametrize("governor,required", [("must", True), ("may", False), ("must not", False)])
def test_issue3835_repeated_operation_preserves_governor(operation, governor, required):
    text = f"The reviewer {governor} {operation} and {operation} evidence into a PR comment"
    expected = {"comments"} if required else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]


@pytest.mark.parametrize("first,second", [("PR comment", "PR body"), ("PR body", "PR comment")])
@pytest.mark.parametrize("operation", ["copy", "record", "post", "provide"])
def test_issue3835_bare_capability_coordination_is_channel_symmetric(first, second, operation):
    text = f"The UI allows reviewers to {operation} evidence into a {first} and {operation} evidence into the {second}"
    assert verifier._required_evidence_channels(text) == set()
    assert verifier._required_evidence_channels(
        text + "; the reviewer must post evidence in a PR comment"
    ) == {"comments"}


@pytest.mark.parametrize("operation", ["attached", "provided"])
@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize("destination", ["the PR body", "a PR comment"])
@pytest.mark.parametrize("independent", [False, True])
@pytest.mark.parametrize("reverse", [False, True])
def test_issue3835_passive_capability_destination_or_is_nongating(
    operation, artifact, destination, independent, reverse
):
    choices = [f"as {artifact}", f"in {destination}"]
    if reverse:
        choices.reverse()
    text = f"The UI must allow evidence to be {operation} " + " or ".join(choices)
    if independent:
        text += "; the reviewer must post evidence in a PR comment"
    expected = {"comments"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    assert _floor_verdict(text, body="present", comments="present", artifacts="absent") == "PASS"


@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize(
    "destination,channel", [("the PR body", "body"), ("a PR review comment", "comments")]
)
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_bare_artifact_or_retains_all_mandatory_alternatives(
    artifact, destination, channel, reverse, independent
):
    choices = [f"as {artifact}", f"in {destination}"]
    if reverse:
        choices.reverse()
    text = "Evidence must be attached " + " or ".join(choices)
    extra = {"comments"} if independent else set()
    if independent:
        text += "; the reviewer must post evidence in a PR comment"
    assert {frozenset(option) for option in verifier._required_evidence_options(text)} == {
        frozenset({"artifacts"} | extra),
        frozenset({channel} | extra),
    }
    assert _floor_verdict(text, body="present", comments="present", artifacts="absent") == "PASS"
    assert (
        _floor_verdict(
            text,
            body="absent",
            comments="present" if independent else "absent",
            artifacts="present",
        )
        == "PASS"
    )
    assert _floor_verdict(text, body="absent", comments="absent", artifacts="absent") == "CONCERNS"


@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_artifact_and_keeps_both_destinations(artifact, reverse, independent):
    choices = [f"as {artifact}", "in the PR body"]
    if reverse:
        choices.reverse()
    text = "Evidence must be attached " + " and ".join(choices)
    expected = {"artifacts", "body"}
    if independent:
        text += "; the reviewer must post evidence in a PR comment"
        expected.add("comments")
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    assert (
        _floor_verdict(text, body="present", comments="present", artifacts="absent") == "CONCERNS"
    )
    assert (
        _floor_verdict(text, body="absent", comments="present", artifacts="present") == "CONCERNS"
    )


@pytest.mark.parametrize("coordination", ["and", "or"])
@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("joiner", [" and ", "; "])
def test_issue3835_product_list_keeps_independent_reviewer_only(
    coordination, artifact, reverse, joiner
):
    """Product destination lists must not invent artifact duty beside a reviewer."""
    choices = ["in the PR body", f"as {artifact}"]
    if reverse:
        choices.reverse()
    text = (
        "The UI must allow evidence to be attached "
        + f" {coordination} ".join(choices)
        + f"{joiner}the reviewer must post evidence in a PR review comment"
    )
    assert verifier._required_evidence_channels(text) == {"comments"}
    assert verifier._required_evidence_options(text) == [{"comments"}]
    assert (
        _floor_verdict(text, body="present", comments="absent", artifacts="present") == "CONCERNS"
    )
    assert _floor_verdict(text, body="absent", comments="present", artifacts="absent") == "PASS"


@pytest.mark.parametrize(
    "qualifier",
    [
        "that must not contain command output",
        "which must not contain command output",
        "that must not include command output",
        "containing command output",
    ],
)
@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_negative_artifact_content_stays_product_capability(
    qualifier, artifact, reverse, independent
):
    """Artifact-content qualifiers under a product OR invent no artifact duty."""
    choices = ["in the PR body", f"as {artifact} {qualifier}"]
    if reverse:
        choices.reverse()
    text = "The UI must allow evidence to be attached " + " or ".join(choices)
    if independent:
        text += "; the reviewer must post evidence in a PR review comment"
    expected = {"comments"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    assert _floor_verdict(text, body="present", comments="present", artifacts="absent") == "PASS"
    if independent:
        assert (
            _floor_verdict(text, body="present", comments="absent", artifacts="present")
            == "CONCERNS"
        )


@pytest.mark.parametrize(
    "criterion",
    [
        "The reviewer must upload evidence without secret content as an artifact",
        "Attach evidence without secrets as an artifact",
        "The reviewer must upload evidence that must not contain secrets as an artifact",
        "The reviewer must upload evidence which must not contain command output as an artifact",
        "The reviewer must upload evidence as an artifact that must not contain secrets",
    ],
)
def test_issue3835_negative_artifact_content_keeps_mandatory_human_delivery(criterion):
    """Payload exclusions do not erase a mandatory human artifact duty."""
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="absent", comments="absent", artifacts="present") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "Do not attach secret content as an artifact",
        "The reviewer must not upload credential content as an artifact",
        "Evidence must not include private content as an artifact",
        "The UI must allow evidence to be attached as a workflow artifact that must not contain command output",
        "The UI must allow evidence to be attached in the PR body or as a workflow artifact that must not contain command output",
    ],
)
def test_issue3835_negative_artifact_content_controls_stay_nongating(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion,expected",
    [
        (
            "The UI must allow evidence to be attached in the PR body and as a workflow artifact "
            "and the reviewer must post evidence in a PR review comment",
            {"comments"},
        ),
        (
            "The UI must allow evidence to be attached in the PR body or as a workflow artifact "
            "and the reviewer must post evidence in a PR review comment",
            {"comments"},
        ),
        (
            "The application must allow users to upload evidence as an artifact "
            "and the reviewer must post a PR comment",
            {"comments"},
        ),
    ],
)
def test_issue3835_coordinated_product_reviewer_keeps_only_reviewer_duty(criterion, expected):
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="absent", comments="present", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize(
    "text",
    [
        "The application must validate a field in an artifact",
        "The service must parse a value in an artifact",
        "The schema must describe a property in an artifact",
        "Schema validation in an artifact is mandatory",
        "The pipeline must run validation in an artifact",
        "The application requires validation of a field in an artifact",
        "Command output validation in an artifact is required",
        "The schema must contain a property in an artifact",
        "The application must record a checksum in an artifact",
        "The application must validate stored values in an artifact",
        "Evidence must be posted in the PR body. The application must validate a field in an artifact.",
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_bare_artifact_normalize_requires_delivery_predicate(text, independent):
    """Product-domain 'in an artifact' must not become workflow-artifact duty."""
    if independent:
        text += "; the reviewer must post evidence in a PR review comment"
    artifact_clause = text
    if ". " in text:
        # Prior sentence may already require body; only the product clause is free.
        expected = {"body", "comments"} if independent else {"body"}
        artifact_clause = text.rsplit(". ", 1)[-1]
    else:
        expected = {"comments"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    assert (
        verifier._normalize_plain_artifact_destinations(artifact_clause.split(";")[0])
        == artifact_clause.split(";")[0]
    )


@pytest.mark.parametrize(
    "text,expected",
    [
        (
            "Provide evidence in the PR body, and the application must validate a field in an artifact.",
            {"body"},
        ),
        (
            "Provide evidence in the PR body and the application must validate a field in an artifact.",
            {"body"},
        ),
        (
            "Attach evidence as an artifact, but the service must parse a value in an artifact.",
            {"artifacts"},
        ),
        (
            "Provide evidence in the PR body while the application must validate a field in an artifact.",
            {"body"},
        ),
    ],
)
def test_issue3835_coordinated_product_clause_does_not_inherit_artifact_duty(text, expected):
    """Independent product clauses after and/but/while must not borrow delivery."""
    normalized = verifier._normalize_plain_artifact_destinations(text)
    # Delivery-side artifacts may canonicalize; product-domain uses must not.
    assert "validate a field in a workflow artifact" not in normalized
    assert "parse a value in a workflow artifact" not in normalized
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    # Destination-list coordination under one delivery still canonicalizes.
    keep = "Provide evidence in the PR body and in an artifact"
    assert "workflow artifact" in verifier._normalize_plain_artifact_destinations(keep)
    assert verifier._required_evidence_channels(keep) == {"body", "artifacts"}


@pytest.mark.parametrize(
    "text,expected",
    [
        ("Evidence must be attached as an artifact", {"artifacts"}),
        ("Evidence must be attached in the PR body and as an artifact", {"artifacts", "body"}),
        ("Evidence must be attached in the PR body or as an artifact", None),
        ("Evidence in an artifact is required", {"artifacts"}),
        ("Evidence is required in an artifact", {"artifacts"}),
        ("Validation results must be in an artifact", {"artifacts"}),
        ("Test results in an artifact are required", {"artifacts"}),
        ("Command output in an artifact is required", {"artifacts"}),
        ("Copy the transcript into an artifact", {"artifacts"}),
    ],
)
def test_issue3835_bare_artifact_delivery_still_canonicalizes(text, expected):
    normalized = verifier._normalize_plain_artifact_destinations(text)
    assert "workflow artifact" in normalized
    assert " an workflow " not in normalized
    if expected is None:
        assert {frozenset(option) for option in verifier._required_evidence_options(text)} == {
            frozenset({"body"}),
            frozenset({"artifacts"}),
        }
    else:
        assert verifier._required_evidence_channels(text) == expected


@pytest.mark.parametrize(
    "text",
    [
        "The review comment API is required",
        "The review comment component is required",
        "The inline review comment UI is required",
        "The review comment endpoint is required",
        "The review comment validator is required",
        "The review comment service is required",
        "The review comment REST API is required",
        "The review comment management UI is required",
        "The review comment data model is required",
    ],
)
@pytest.mark.parametrize("independent", [False, True])
def test_issue3835_review_comment_product_surface_is_not_delivery(text, independent):
    """Bare review aliases beside API/UI/component nouns stay non-gating."""
    assert text == verifier._normalize_review_comment_destinations(text)
    if independent:
        text += "; the auditor must record evidence in the PR body"
    expected = {"body"} if independent else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]


@pytest.mark.parametrize(
    "text",
    [
        "PR body that must include validation evidence",
        "A PR body that must include validation evidence is required",
        "Evidence must be posted in a PR body that must include validation evidence",
    ],
)
def test_issue3835_affirmative_relative_presence_keeps_body_duty(text):
    """Affirmative relative content predicates must not be stripped before presence."""
    normalized = verifier._normalize_review_content_qualifiers(text)
    assert "must include validation evidence" in normalized.lower()
    assert verifier._required_evidence_channels(text) == {"body"}
    assert verifier._required_evidence_options(text) == [{"body"}]


@pytest.mark.parametrize(
    "modal,expected", [("may", set()), ("must not", set()), ("must", {"body", "artifacts"})]
)
@pytest.mark.parametrize("operator", ["and", "or"])
@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
@pytest.mark.parametrize("artifact_first", [False, True])
def test_issue3835_relative_artifact_content_preserves_parent_delivery_governor(
    modal, expected, operator, artifact, artifact_first
):
    """A child artifact-content duty cannot promote its optional/prohibited parent."""
    artifact_destination = f"as {artifact} that must include logs"
    destinations = ["in the PR body", artifact_destination]
    if artifact_first:
        destinations.reverse()
    criterion = f"Evidence {modal} be posted " + f" {operator} ".join(destinations)
    assert verifier._required_evidence_channels(criterion) == expected
    options = verifier._required_evidence_options(criterion)
    if operator == "or" and expected:
        assert {frozenset(option) for option in options} == {
            frozenset({"body"}),
            frozenset({"artifacts"}),
        }
    else:
        assert options == [expected]


def test_issue3835_relative_artifact_content_keeps_independent_reviewer_floor():
    criterion = (
        "Evidence may be posted in the PR body and as an artifact that must include logs; "
        "an independent reviewer must deliver evidence in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]


def test_issue3835_filename_payload_keeps_artifact_delivery():
    criterion = "The reviewer must upload evidence from results.json in an artifact"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert verifier._required_evidence_channels(
        criterion + "; the auditor must record evidence in a PR comment"
    ) == {"artifacts", "comments"}


@pytest.mark.parametrize(
    "content",
    [
        "the implementation's test coverage",
        "v1.2 coverage",
        "(coverage)",
        "coverage: detail",
        '"coverage and in a workflow artifact"',
    ],
)
def test_issue3835_bounded_prose_content_keeps_destination_sibling(content):
    criterion = (
        "Evidence must be posted in a PR comment about " + content + " "
        "and in a workflow artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]


@pytest.mark.parametrize(
    "criterion",
    ["A parser for review comments is required", "Support for review comments is required"],
)
def test_issue3835_review_comment_product_subject_is_not_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize(
    "criterion",
    [
        "At least one PR review comment is required",
        "A detailed review comment is required",
        "At least two detailed review comments are required",
    ],
)
def test_issue3835_counted_or_descriptive_review_comment_subject_is_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


def test_issue3835_review_comment_product_complement_is_not_delivery():
    for criterion in (
        "Review comments are required fields in the response schema",
        "Review comments must be required fields in the response schema",
        "Review comments are required input metadata",
        "Review comments must be required metadata",
        "Review comments are required in the response schema",
    ):
        assert verifier._required_evidence_channels(criterion) == set()
        assert verifier._required_evidence_options(criterion) == [set()]
        assert _floor_verdict(criterion, body="present", comments="absent") == "PASS"
    criterion = "Review comments are required fields in the response schema"
    independent = criterion + "; an independent reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_channels(independent) == {"comments"}
    assert _floor_verdict(independent, body="present", comments="absent") == "CONCERNS"
    assert verifier._required_evidence_channels("A review comment is required for this PR") == {
        "comments"
    }


@pytest.mark.parametrize(
    "criterion",
    [
        "A review comment must be provided by the reviewer",
        "Review comments are required for the audit",
        "A review comment is required due to policy",
        "A PR review comment is required in this PR",
        "A review comment must be posted on the pull request",
    ],
)
def test_issue3835_standalone_requirement_prepositional_tail_is_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize("quantifier,operator", [("both", "and"), ("either", "or")])
def test_issue3835_quantifier_before_destination_preposition(quantifier, operator):
    criterion = f"Evidence must be posted {quantifier} in a PR comment {operator} in an artifact"
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    options = verifier._required_evidence_options(criterion)
    if operator == "or":
        assert {frozenset(option) for option in options} == {
            frozenset({"comments"}),
            frozenset({"artifacts"}),
        }
    else:
        assert options == [{"comments", "artifacts"}]
    if operator == "and":
        assert (
            _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
            == "CONCERNS"
        )
        assert (
            _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
            == "CONCERNS"
        )
    else:
        assert (
            _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
            == "PASS"
        )
        assert (
            _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
            == "PASS"
        )
        assert (
            _floor_verdict(criterion, body="present", comments="absent", artifacts="absent")
            == "CONCERNS"
        )


@pytest.mark.parametrize(
    "criterion,expected",
    [
        ("The reviewer must leave one or more PR review comments", {"comments"}),
        ("A PR review comment by the maintainer is required", {"comments"}),
        ("A PR review comment from the maintainer is required", {"comments"}),
        ("The document management system must upload a user file as an artifact", set()),
        ("The API must publish review comments to clients", set()),
    ],
)
def test_issue3835_preserves_main_delivery_boundaries(criterion, expected):
    """Bounded review aliases retain duties but ignore product capabilities."""
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    availability = {"body": "present", "comments": "present", "artifacts": "present"}
    if expected:
        channel = next(iter(expected))
        availability[channel] = "absent"
        assert _floor_verdict(criterion, **availability) == "CONCERNS"
    else:
        assert (
            _floor_verdict(criterion, body="absent", comments="absent", artifacts="absent")
            == "PASS"
        )


@pytest.mark.parametrize(
    "criterion,channel",
    [
        (
            "The document management system must upload a user file as an artifact; "
            "the reviewer must post evidence in a PR comment",
            "comments",
        ),
        (
            "The API must publish review comments to clients; "
            "the reviewer must upload evidence as an artifact",
            "artifacts",
        ),
    ],
)
def test_issue3835_product_capabilities_do_not_erase_independent_delivery(criterion, channel):
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_options(criterion) == [{channel}]
    availability = {"body": "present", "comments": "present", "artifacts": "present"}
    availability[channel] = "absent"
    assert _floor_verdict(criterion, **availability) == "CONCERNS"


def test_issue3835_count_modifier_cannot_create_empty_destination_option():
    criterion = (
        "One or more PR review comments are required or evidence must be posted in an artifact"
    )
    options = verifier._required_evidence_options(criterion)
    assert {frozenset(option) for option in options} == {
        frozenset({"comments"}),
        frozenset({"artifacts"}),
    }
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "- [ ] A PR review comment is required",
        "A PR review comment must be left",
        "A PR review comment needs to be posted",
        "A PR review comment has to be posted",
    ],
)
def test_issue3835_standalone_comment_duties_keep_the_comment_floor(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    "criterion",
    [
        "The parser must record review comments",
        "The API must publish review comments",
    ],
)
def test_issue3835_product_comment_objects_without_pr_destinations_are_not_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert _floor_verdict(criterion, body="absent", comments="absent", artifacts="absent") == "PASS"


def test_issue3835_product_comment_object_with_pr_destination_keeps_comment_floor():
    criterion = "The API must publish review comments in the PR"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    "criterion",
    [
        "A PR review comment must be submitted",
        "A PR review comment must be present",
        "A PR review comment must be mandatory",
        "A PR review comment must be added",
        "A PR review comment must exist",
    ],
)
def test_issue3835_standalone_comment_delivery_states_keep_the_comment_floor(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


def test_issue3835_content_qualified_comment_retains_coordinated_artifact_delivery():
    criterion = "Evidence must be posted in a PR comment about test coverage and uploaded to a workflow artifact"
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("prefix", ["the", "our", "their", "each appointed"])
@pytest.mark.parametrize("boundary", [" and ", ", and ", " but ", " while "])
@pytest.mark.parametrize("artifact", ["an artifact", "a workflow artifact"])
def test_issue3835_independent_clause_boundary_shares_actor_grammar(prefix, boundary, artifact):
    """One shared bounded actor grammar governs both kinds of independent duty."""
    product = (
        "The UI must allow evidence to be attached in the PR body or as "
        + artifact
        + boundary
        + prefix
        + " reviewer must post evidence in a PR review comment"
    )
    domain = (
        "Provide evidence in the PR body"
        + boundary
        + prefix
        + " application must validate a field in an artifact."
    )
    for criterion, expected in ((product, {"comments"}), (domain, {"body"})):
        assert verifier._required_evidence_channels(criterion) == expected
        assert verifier._required_evidence_options(criterion) == [expected]
        for missing in ("absent", "unavailable"):
            assert (
                _floor_verdict(criterion, body="present", comments="present", artifacts=missing)
                == "PASS"
            )
            assert _floor_verdict(criterion, body=missing, comments=missing) == "CONCERNS"


@pytest.mark.parametrize("boundary", [" and ", ", and ", " but ", " while "])
@pytest.mark.parametrize("predicate", ["validate a field", "parse a value", "record a checksum"])
def test_issue3835_same_subject_product_predicate_cannot_borrow_delivery(boundary, predicate):
    criterion = (
        "The application must record evidence internally" + boundary + predicate + " in an artifact"
    )
    assert verifier._normalize_plain_artifact_destinations(criterion) == criterion
    # This boundary must not invent artifact duty. Generic overall-evidence
    # classification is outside this repair; test the exact reported case too.
    baseline = verifier._required_evidence_channels(criterion)
    assert baseline <= {"overall"}
    if boundary == " and " and predicate == "validate a field":
        assert baseline == set()
    for text, expected in (
        (criterion, baseline),
        (
            criterion + "; the reviewer must post evidence in a PR review comment",
            baseline | {"comments"},
        ),
    ):
        assert verifier._required_evidence_channels(text) == expected
        assert verifier._required_evidence_options(text) == [expected]
        for missing in ("absent", "unavailable"):
            assert (
                _floor_verdict(text, body="present", comments="present", artifacts=missing)
                == "PASS"
            )
            if "comments" in expected:
                assert _floor_verdict(text, body="present", comments=missing) == "CONCERNS"


@pytest.mark.parametrize(
    "text",
    [
        "Record evidence in the PR body and in an artifact",
        "Record evidence in the PR body and post evidence in an artifact",
        "Record evidence in the PR body and attach it in an artifact",
        "Record evidence in the PR body and validation results in an artifact",
    ],
)
def test_issue3835_same_subject_real_artifact_delivery_retains_floor(text):
    assert verifier._required_evidence_channels(text) == {"body", "artifacts"}
    assert verifier._required_evidence_options(text) == [{"body", "artifacts"}]
    for missing in ("absent", "unavailable"):
        assert (
            _floor_verdict(text, body="present", comments="present", artifacts=missing)
            == "CONCERNS"
        )


@pytest.mark.parametrize(
    "destination",
    [
        "pull-request review comment",
        "pull-request inline review comment",
        "pull request review comment",
    ],
)
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_issue3835_hyphenated_qualified_review_destination(destination, governor):
    text = f"Evidence {governor} be posted in a {destination}"
    expected = {"comments"} if governor == "must" else set()
    assert verifier._required_evidence_channels(text) == expected
    assert verifier._required_evidence_options(text) == [expected]
    for missing in ("absent", "unavailable"):
        assert _floor_verdict(text, body="present", comments=missing) == (
            "CONCERNS" if expected else "PASS"
        )
    if expected:
        alternative = text + " or in the PR body"
        assert {
            frozenset(option) for option in verifier._required_evidence_options(alternative)
        } == {frozenset({"comments"}), frozenset({"body"})}
        assert _floor_verdict(alternative, body="present", comments="absent") == "PASS"


@pytest.mark.parametrize(
    "criterion",
    [
        "The application must attach evidence metadata to an artifact",
        "The application must store evidence records in an artifact",
        "The application must record evidence provenance in an artifact",
        "The validator must record review comment state",
        "The parser must include review comment fields",
    ],
)
def test_issue3835_compound_objects_are_product_fields(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert _floor_verdict(criterion, body="absent", comments="absent", artifacts="absent") == "PASS"
    independent = criterion + "; the reviewer must record evidence in a PR comment"
    assert verifier._required_evidence_options(independent) == [{"comments"}]
    assert _floor_verdict(independent, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    "criterion,expected",
    [
        ("The reviewer must attach evidence to an artifact", {"artifacts"}),
        ("The reviewer must record evidence internally in an artifact", {"artifacts"}),
        ("The reviewer must record a review comment", {"comments"}),
        ("The reviewer must record a detailed review comment with test evidence", {"comments"}),
        (
            "Evidence must be posted in a review comment or in an artifact",
            {"comments", "artifacts"},
        ),
    ],
)
def test_issue3835_complete_objects_retain_deliveries(criterion, expected):
    assert verifier._required_evidence_channels(criterion) == expected
    assert all(
        verifier._required_evidence_is_missing(
            "- Overall retrieval status: **present**\n- PR body: **absent**\n"
            "- PR comments: **absent**\n- Referenced workflow artifacts: **absent**",
            option,
        )
        for option in verifier._required_evidence_options(criterion)
    )


def test_issue3835_hyphenated_review_api_and_quoted_literal_are_not_delivery():
    for text in (
        "The pull-request review comment API is required",
        "`Evidence must be posted in a pull-request review comment`",
    ):
        assert verifier._normalize_review_comment_destinations(text) == text
        assert verifier._required_evidence_channels(text) == set()


@pytest.mark.parametrize("payload", ["files", "bundle", "package"])
@pytest.mark.parametrize(
    "governor,expected", [("must", {"artifacts"}), ("may", set()), ("must not", set())]
)
def test_issue3835_evidence_payload_delivery_preserves_floor(payload, governor, expected):
    criterion = f"The reviewer {governor} upload evidence {payload} to an artifact"
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == (
        "CONCERNS" if expected else "PASS"
    )


@pytest.mark.parametrize("qualifier", ["about", "regarding", "concerning"])
@pytest.mark.parametrize(
    "governor,expected", [("must", {"comments"}), ("may", set()), ("must not", set())]
)
def test_issue3835_review_content_preposition_preserves_floor(qualifier, governor, expected):
    criterion = f"The reviewer {governor} post a review comment {qualifier} the test results"
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert _floor_verdict(criterion, body="present", comments="absent") == (
        "CONCERNS" if expected else "PASS"
    )
    independent = criterion + "; the auditor must record evidence in a workflow artifact"
    assert verifier._required_evidence_channels(independent) == expected | {"artifacts"}
    assert (
        _floor_verdict(independent, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize("qualifier", ["about", "regarding", "concerning"])
@pytest.mark.parametrize(
    "content",
    [
        "test results",
        "test coverage",
        "implementation details",
        "test coverage and implementation details",
    ],
)
@pytest.mark.parametrize("conjunction", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_issue3835_content_qualified_destination_lists(
    qualifier, content, conjunction, reverse, governor
):
    comment = f"in a review comment {qualifier} {content}"
    artifact = "in a workflow artifact"
    first, second = (artifact, comment) if reverse else (comment, artifact)
    criterion = f"Evidence {governor} be posted {first} {conjunction} {second}"
    expected = {"comments", "artifacts"} if governor == "must" else set()
    assert verifier._required_evidence_channels(criterion) == expected
    options = (
        [{"comments"}, {"artifacts"}] if governor == "must" and conjunction == "or" else [expected]
    )
    assert {frozenset(x) for x in verifier._required_evidence_options(criterion)} == {
        frozenset(x) for x in options
    }
    for comments, artifacts in [("present", "absent"), ("absent", "present"), ("absent", "absent")]:
        missing = governor == "must" and (
            conjunction == "and" or (comments == artifacts == "absent")
        )
        assert _floor_verdict(
            criterion, body="present", comments=comments, artifacts=artifacts
        ) == ("CONCERNS" if missing else "PASS")


@pytest.mark.parametrize("payload", ["files", "bundle", "package"])
@pytest.mark.parametrize("elided", [False, True])
@pytest.mark.parametrize("conjunction", ["and", "or"])
@pytest.mark.parametrize("reverse", [False, True])
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_issue3835_payload_destination_lists(payload, elided, conjunction, reverse, governor):
    first, second = (
        ("to the PR body", "to an artifact") if reverse else ("to an artifact", "the PR body")
    )
    if reverse and elided:
        second = "an artifact"
    criterion = f"The reviewer {governor} upload evidence {payload} {first} {conjunction} {second}"
    expected = {"body", "artifacts"} if governor == "must" else set()
    assert verifier._required_evidence_channels(criterion) == expected
    options = (
        [{"body"}, {"artifacts"}] if governor == "must" and conjunction == "or" else [expected]
    )
    assert {frozenset(x) for x in verifier._required_evidence_options(criterion)} == {
        frozenset(x) for x in options
    }
    for body, artifacts in [("present", "absent"), ("absent", "present"), ("absent", "absent")]:
        missing = governor == "must" and (conjunction == "and" or (body == artifacts == "absent"))
        assert _floor_verdict(criterion, body=body, comments="present", artifacts=artifacts) == (
            "CONCERNS" if missing else "PASS"
        )


@pytest.mark.parametrize(
    "criterion",
    [
        "The application must allow users to upload evidence files to the PR body and an artifact",
        "The application must allow users to upload evidence files to an artifact and the PR body",
        "The application must allow users to upload evidence files to the PR body or an artifact",
        "The application must allow users to upload evidence files to an artifact or the PR body",
        "`Evidence must be posted in a PR comment about test coverage and in an artifact`",
    ],
)
def test_issue3835_payload_and_content_lists_preserve_product_and_literal_boundaries(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    independent = criterion + "; the auditor must record evidence in a workflow artifact"
    assert verifier._required_evidence_channels(independent) == {"artifacts"}
    assert (
        _floor_verdict(independent, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


def test_issue3835_elided_artifact_cannot_borrow_domain_predicate():
    criterion = "The reviewer must upload evidence files to the PR body and record a checksum in an artifact"
    assert verifier._required_evidence_channels(criterion) == {"body"}
    assert verifier._required_evidence_options(criterion) == [{"body"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize("pronoun", ["it", "them", "these", "those", "both"])
def test_issue3835_product_payload_list_retains_independent_proof_pronoun(pronoun):
    criterion = (
        "The application must allow users to upload evidence files to the PR body and an artifact; "
        + f"the reviewer must record {pronoun} in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("pronoun", ["it", "them", "this", "they", "these", "those", "both"])
@pytest.mark.parametrize(
    "destination,channel",
    [
        ("in an artifact", "artifacts"),
        ("as an artifact", "artifacts"),
        ("in a workflow artifact", "artifacts"),
        ("in a PR comment", "comments"),
        ("in the PR body", "body"),
    ],
)
@pytest.mark.parametrize("governor", ["must", "may", "must not"])
def test_issue3835_independent_proof_pronoun_destination_floor(
    pronoun, destination, channel, governor
):
    criterion = (
        "The application must allow users to upload evidence files to the PR body and an artifact; "
        + f"the reviewer {governor} record {pronoun} {destination}"
    )
    expected = {channel} if governor == "must" else set()
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    availability = {"body": "present", "comments": "present", "artifacts": "present"}
    availability[channel] = "absent"
    assert _floor_verdict(criterion, **availability) == ("CONCERNS" if expected else "PASS")


@pytest.mark.parametrize(
    "prefix",
    ["The validator stores a checksum", "`The application uploads evidence files`", "Tests pass"],
)
def test_issue3835_unbound_product_or_quoted_pronoun_is_not_evidence(prefix):
    criterion = prefix + "; the reviewer must record it in an artifact"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


def test_evidence_classification_cache_cannot_leak_mutated_containers():
    criterion = "Evidence must be posted in a PR comment or in a workflow artifact"
    channels = verifier._required_evidence_channels(criterion)
    channels.clear()
    channels.add("bogus")
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    options = verifier._required_evidence_options(criterion)
    options[0].add("bogus")
    options.clear()
    assert {frozenset(x) for x in verifier._required_evidence_options(criterion)} == {
        frozenset({"comments"}),
        frozenset({"artifacts"}),
    }


def test_evidence_options_cache_respects_classifier_substitution(monkeypatch):
    criterion = "Evidence must be posted in the PR body"
    assert verifier._required_evidence_options(criterion) == [{"body"}]
    monkeypatch.setattr(verifier, "_required_evidence_channels", lambda text: {"comments"})
    assert verifier._required_evidence_options(criterion) == [{"comments"}]


def test_evidence_classifier_caches_are_bounded_and_skip_large_criteria():
    channels = verifier._cached_evidence_channels
    options = verifier._cached_evidence_options
    assert channels.cache_info().maxsize == options.cache_info().maxsize == 512
    large = " " * (verifier._EVIDENCE_CACHE_MAX_CHARS + 1)
    before = (channels.cache_info().currsize, options.cache_info().currsize)
    assert verifier._required_evidence_channels(large) == set()
    assert verifier._required_evidence_options(large) == [set()]
    assert (channels.cache_info().currsize, options.cache_info().currsize) == before


@pytest.mark.parametrize("state", ["made", "sent", "shown", "put"])
def test_issue3835_irregular_standalone_delivery_states_preserve_main(state):
    criterion = f"A PR review comment must be {state}"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    "criterion",
    [
        "1. [ ] A PR review comment is required",
        "[ ] A PR review comment is required",
    ],
)
def test_issue3835_numbered_and_bare_checkbox_comment_duties(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize("operation", ["submit", "write", "deliver", "supply"])
def test_issue3835_active_comment_delivery_aliases_keep_the_comment_floor(operation):
    criterion = f"The reviewer must {operation} a PR review comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert _floor_verdict(criterion, body="present", comments="absent") == "CONCERNS"


@pytest.mark.parametrize(
    ("criterion", "channel"),
    [
        ("I must submit a PR review comment", "comments"),
        ("You must supply a PR review comment", "comments"),
        ("We must upload evidence to an artifact", "artifacts"),
    ],
)
def test_issue3835_pronoun_delivery_actors_keep_required_channel(criterion, channel):
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_options(criterion) == [{channel}]
    kwargs = {"body": "present", "comments": "present", "artifacts": "present"}
    kwargs[channel] = "absent"
    assert _floor_verdict(criterion, **kwargs) == "CONCERNS"


@pytest.mark.parametrize(
    "criterion",
    [
        "The background worker must upload evidence to an artifact",
        "The controller must record review comments",
    ],
)
def test_issue3835_component_subjects_are_not_review_delivery_actors(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize("actor", ["parser", "schema", "module", "API"])
@pytest.mark.parametrize("state", ["made", "ignored"])
def test_issue3835_product_modified_comment_state_is_not_delivery(actor, state):
    criterion = f"A {actor} review comment must be {state}"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize(
    ("criterion", "expected_options"),
    [
        (
            "Evidence must be posted both in the PR body and in an artifact",
            [{"body", "artifacts"}],
        ),
        (
            "Evidence must be posted both in the PR body and as an artifact",
            [{"body", "artifacts"}],
        ),
        (
            "Evidence must be posted either in the PR description or in an artifact",
            [{"body"}, {"artifacts"}],
        ),
        (
            "Evidence must be posted either in the PR description or as an artifact",
            [{"body"}, {"artifacts"}],
        ),
    ],
)
def test_issue3835_leading_destination_quantifiers_preserve_body_and_description_lists(
    criterion, expected_options
):
    assert verifier._required_evidence_channels(criterion) == {"body", "artifacts"}
    assert {frozenset(option) for option in verifier._required_evidence_options(criterion)} == {
        frozenset(option) for option in expected_options
    }
    if len(expected_options) == 1:
        assert (
            _floor_verdict(criterion, body="absent", comments="present", artifacts="present")
            == "CONCERNS"
        )
        assert (
            _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
            == "CONCERNS"
        )
    else:
        assert (
            _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
            == "PASS"
        )
        assert (
            _floor_verdict(criterion, body="absent", comments="present", artifacts="present")
            == "PASS"
        )
        assert (
            _floor_verdict(criterion, body="absent", comments="present", artifacts="absent")
            == "CONCERNS"
        )


@pytest.mark.parametrize("connector", ["then", "also", "must be", "then must also be"])
def test_issue3835_content_qualified_comment_keeps_coordinated_artifact_delivery(connector):
    criterion = (
        "Evidence must be posted in a PR comment about test coverage and "
        + connector
        + " uploaded to a workflow artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize("qualifier", ["with test results", "for audit"])
def test_issue3835_standalone_comment_qualifiers_keep_delivery_duty(qualifier):
    criterion = f"A PR review comment {qualifier} is required"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("subject", ["reviewer service", "maintainer dashboard"])
def test_issue3835_product_compounds_do_not_borrow_human_delivery_actor(subject):
    criterion = f"The {subject} must upload evidence to an artifact"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize("subject", ["reviewer", "maintainer"])
def test_issue3835_human_delivery_actor_head_remains_a_real_duty(subject):
    criterion = f"The {subject} must upload evidence to an artifact"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


def test_issue3835_human_actor_relative_qualifier_remains_a_delivery_duty():
    criterion = "The reviewer who owns the PR must submit a PR review comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_product_actor_before_relative_qualifier_remains_non_delivery():
    criterion = "The reviewer service who owns the PR must submit a PR review comment"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize(
    "tail",
    [
        "before merge",
        "after CI passes",
        "during release",
        "prior to merge",
        "until merge",
        "once CI passes",
        "throughout release",
        "when approved",
        "while release runs",
        "since CI passed",
        "following review",
        "upon approval",
        "later",
        "afterwards",
        "whenever approved",
    ],
)
def test_issue3835_delivered_comment_temporal_tail_keeps_comment_floor(tail):
    criterion = f"The reviewer must post a PR review comment {tail}"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("operation", ["returned", "serialized"])
def test_issue3835_passive_product_producer_is_not_comment_delivery(operation):
    criterion = f"Review comments must be {operation} by the API"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )


def test_issue3835_comment_content_provenance_is_not_passive_product_producer():
    criterion = "A PR review comment with output from API is required"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("operation", ["returned", "serialized"])
@pytest.mark.parametrize("actor", ["reviewer", "maintainer"])
def test_issue3835_passive_human_producer_keeps_comment_delivery(actor, operation):
    criterion = f"Review comments must be {operation} by the {actor}"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_passive_serialized_product_with_explicit_pr_destination_keeps_comment_delivery():
    criterion = "Review comments must be serialized by the API in the PR"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The parser must post a PR review comment later",
        "`The reviewer must post a PR review comment later`",
        "The reviewer must not post a PR review comment later",
    ],
)
def test_issue3835_active_human_tail_bypass_preserves_product_negative_and_literal_controls(
    criterion,
):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize(
    "criterion",
    [
        "The background worker may allow users to upload evidence to an artifact",
        "The application must allow users to upload evidence files either in a PR comment or as an artifact",
    ],
)
def test_issue3835_nonhuman_capability_lists_are_not_evidence_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    independent = criterion + "; the reviewer must upload evidence to a PR comment"
    assert verifier._required_evidence_channels(independent) == {"comments"}
    assert (
        _floor_verdict(independent, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_leading_quantifier_comment_artifact_list_keeps_destination_dnf():
    criterion = "Evidence must be posted either in a PR comment or as an artifact"
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert {frozenset(option) for option in verifier._required_evidence_options(criterion)} == {
        frozenset({"comments"}),
        frozenset({"artifacts"}),
    }
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "actor",
    [
        "reviewer",
        "reviewer service",
        "background worker",
        "export component",
    ],
)
@pytest.mark.parametrize("verb", ["allow", "enable", "support", "permit"])
@pytest.mark.parametrize("modal", ["must", "may"])
@pytest.mark.parametrize(
    "destination",
    [
        "to an artifact",
        "in a workflow artifact",
        "either in a PR comment or as an artifact",
    ],
)
def test_issue3835_capability_subject_governor_partition(actor, verb, modal, destination):
    criterion = f"The {actor} {modal} {verb} users to upload evidence {destination}"
    assert verifier._required_evidence_channels(criterion) == set()
    independent = criterion + "; the reviewer must upload evidence to a PR comment"
    assert verifier._required_evidence_channels(independent) == {"comments"}


@pytest.mark.parametrize("governor,expected", [("must", {"artifacts"}), ("may", set())])
def test_issue3835_direct_human_delivery_retains_modality(governor, expected):
    criterion = f"The reviewer {governor} upload evidence to an artifact"
    assert verifier._required_evidence_channels(criterion) == expected


@pytest.mark.parametrize("joiner", [";", ", and"])
def test_issue3835_capability_cannot_erase_independent_direct_reviewer_delivery(joiner):
    criterion = (
        "The reviewer must allow users to upload evidence to an artifact"
        + joiner
        + " the reviewer must upload evidence to a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion,expected",
    [
        (
            "The application must allow users to upload evidence in a PR comment and then post evidence as an artifact",
            set(),
        ),
        (
            "The application must allow users to upload evidence in a PR comment, then post evidence as an artifact",
            set(),
        ),
        (
            "The application must allow users to upload evidence in a PR comment, an artifact",
            set(),
        ),
        (
            "The application must allow users to upload test logs in a PR comment and then post test logs as an artifact",
            set(),
        ),
        (
            "The application must allow users to upload evidence in a PR comment and then post it as an artifact",
            set(),
        ),
        (
            "The application must allow users to upload evidence files to the PR body and an artifact; the reviewer must record it in a PR comment",
            {"comments"},
        ),
    ],
)
def test_issue3835_capability_owned_coordinated_deliveries_keep_only_independent_duties(
    criterion,
    expected,
):
    assert verifier._required_evidence_channels(criterion) == expected
    assert verifier._required_evidence_options(criterion) == [expected]
    assert _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == (
        "CONCERNS" if expected else "PASS"
    )


@pytest.mark.parametrize("operation", ["submit", "deliver", "supply"])
@pytest.mark.parametrize("connector", ["", "and then"])
def test_issue3835_capability_registered_delivery_aliases_are_not_evidence_duties(
    operation,
    connector,
):
    continuation = f" {connector} {operation} evidence as an artifact" if connector else ""
    criterion = (
        f"The application must allow users to {operation} evidence either in a PR comment or as an artifact"
        + continuation
    )
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize("operation", ["submit", "deliver", "supply"])
@pytest.mark.parametrize("adverb", ["securely", "then", "also"])
def test_issue3835_capability_initial_delivery_adverbs_use_shared_operation_grammar(
    operation,
    adverb,
):
    criterion = f"The application must allow users to {adverb} {operation} evidence either in a PR comment or as an artifact"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


def test_issue3835_capability_marker_keeps_a_prior_unlocated_delivery_duty():
    criterion = (
        "The reviewer must provide evidence and allow users to upload evidence in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"overall"}
    assert verifier._required_evidence_options(criterion) == [{"overall"}]
    assert (
        _floor_verdict(
            criterion, body="present", comments="present", artifacts="present", overall="absent"
        )
        == "CONCERNS"
    )


def test_issue3835_capability_coordination_preserves_separate_reviewer_delivery():
    criterion = (
        "The application must allow users to upload evidence in a PR comment and then post evidence as an artifact; "
        "the reviewer must record evidence in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_mandatory_capability_workflow_artifact_does_not_create_a_floor():
    criterion = "The reviewer must allow users to upload evidence in a workflow artifact"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )


def test_issue3835_capability_segment_cannot_erase_prior_finite_proof_delivery():
    criterion = "Reviewers must post evidence in the PR body and allow users to upload evidence in a workflow artifact"
    assert verifier._required_evidence_channels(criterion) == {"body"}
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )


def test_issue3835_checkbox_unknown_component_capability_is_nongating():
    criterion = "- [ ] The novel engine may permit users to upload evidence to an artifact"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


@pytest.mark.parametrize("operation", ["send"])
@pytest.mark.parametrize(
    "destination,channel",
    [("in a PR comment", "comments"), ("in the PR body", "body"), ("as an artifact", "artifacts")],
)
def test_issue3835_active_command_output_send_requires_the_named_destination(
    operation,
    destination,
    channel,
):
    criterion = f"The author must {operation} command output {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_options(criterion) == [{channel}]
    statuses = {"body": "present", "comments": "present", "artifacts": "present"}
    statuses[channel] = "absent"
    assert _floor_verdict(criterion, **statuses) == "CONCERNS"


@pytest.mark.parametrize(
    "criterion",
    [
        "The author sends command output in a PR comment",
        "The author is sending command output in a PR comment",
        "The API sends command output in a PR comment",
    ],
)
def test_issue3835_grammatical_active_command_output_send_requires_comment(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize("governor", ["may", "must not"])
def test_issue3835_active_command_output_send_optional_or_prohibited_is_not_required(governor):
    criterion = f"The author {governor} send command output in a PR comment"
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The application must not allow users to upload evidence to an artifact and allow users to send command output in a PR comment",
        "The application must not allow users to upload evidence to an artifact, but the application prevents authenticated users from sending command output in a PR comment",
        "The application must not allow users to upload evidence to an artifact, but the application disallows authenticated users from sending command output in a PR comment",
    ],
)
def test_issue3835_negative_capability_chain_is_not_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize("governor", ["must prevent", "prevents", "must disallow", "disallows"])
@pytest.mark.parametrize("recipient", ["users", "authenticated users", "all users", "operators"])
def test_issue3835_prohibitive_command_output_send_capability_is_not_delivery(governor, recipient):
    criterion = (
        f"The application {governor} {recipient} from sending command output in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )


@pytest.mark.parametrize("governor", ["must prevent", "prevents", "must disallow", "disallows"])
@pytest.mark.parametrize("recipient", ["users", "authenticated users", "all users", "operators"])
def test_issue3835_finite_prohibitive_command_output_send_preserves_independent_reviewer_delivery(
    governor,
    recipient,
):
    criterion = (
        f"The application {governor} {recipient} from sending command output in a PR comment; "
        "the reviewer must send command output in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_product_owned_command_output_send_matches_shared_delivery_operation():
    criterion = "The API must send command output in a PR comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The API sends command output as an artifact",
        "The API is sending command output as an artifact",
        "The API must send command output as an artifact",
    ],
)
def test_issue3835_product_command_output_send_artifact_is_not_delivery(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]


def test_issue3835_product_command_output_send_preserves_independent_reviewer_delivery():
    criterion = (
        "The API is sending command output as an artifact; "
        "the reviewer must send command output in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_product_command_output_send_preserves_later_reviewer_artifact_delivery():
    criterion = (
        "The API is sending command output as an artifact; "
        "the reviewer must attach command output as an artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


def test_issue3835_product_command_output_send_preserves_pronoun_comment_delivery():
    criterion = (
        "The API is sending command output as an artifact; "
        "the reviewer must send it in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


def test_issue3835_reviewer_send_logs_artifact_remains_required():
    criterion = "The reviewer must send logs as an artifact"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "subject", ["The reviewer", "The API is sending command output as an artifact; the reviewer"]
)
@pytest.mark.parametrize("payload", ["command output"])
@pytest.mark.parametrize(
    "destination,channel",
    [("in a PR comment", "comments"), ("in the PR body", "body"), ("as an artifact", "artifacts")],
)
def test_issue3835_shared_send_operation_keeps_required_destination(
    subject, payload, destination, channel
):
    criterion = f"{subject} must send {payload} {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    assert verifier._required_evidence_options(criterion) == [{channel}]


def test_issue3835_author_command_output_send_artifact_remains_required():
    criterion = "The author must send command output as an artifact"
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


def test_issue3835_product_command_output_send_explicit_pr_destination_remains_required():
    criterion = "The API must send command output in a PR comment"
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]


def test_issue3835_coordinated_command_output_send_retains_each_destination_floor():
    criterion = "The author must send command output in a PR comment and attach command output as an artifact"
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize("pronoun", ["it", "them", "this", "these", "those", "both"])
def test_issue3835_capability_owned_logs_do_not_supply_artifact_floor(pronoun):
    criterion = (
        "The application must allow users to upload logs to the PR body and an artifact; "
        f"the reviewer must send {pronoun} in a PR comment"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}]
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion,expected_channels,expected_options",
    [
        (
            "The reviewer must upload evidence from results.json both in a PR comment and in an artifact",
            {"comments", "artifacts"},
            [{"comments", "artifacts"}],
        ),
        (
            "The reviewer must upload evidence from results.json either in a PR comment or in an artifact",
            {"comments", "artifacts"},
            [{"comments"}, {"artifacts"}],
        ),
    ],
)
def test_issue3883_filename_qualified_quantified_destinations(
    criterion, expected_channels, expected_options
):
    assert verifier._required_evidence_channels(criterion) == expected_channels
    assert verifier._required_evidence_options(criterion) == expected_options


def test_issue3883_filename_qualified_both_requires_every_destination():
    criterion = "The reviewer must upload evidence from results.json both in a PR comment and in an artifact"
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="present", artifacts="absent")
        == "CONCERNS"
    )


def test_issue3883_filename_qualified_either_accepts_one_destination():
    criterion = "The reviewer must upload evidence from results.json either in a PR comment or in an artifact"
    assert (
        _floor_verdict(criterion, body="absent", comments="present", artifacts="absent") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )
    assert (
        _floor_verdict(criterion, body="absent", comments="absent", artifacts="absent")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The reviewer must not upload evidence from results.json both in a PR comment and in an artifact",
        "The reviewer may upload evidence from results.json both in a PR comment and in an artifact",
        "The UI allows users to upload evidence from results.json both in a PR comment and in an artifact",
        'The parser recognizes "The reviewer must upload evidence from results.json both in a PR comment and in an artifact"',
    ],
)
def test_issue3883_filename_qualified_controls_stay_nongating(criterion):
    """Negation, optionality, product capability and quoted examples stay nongating."""
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize("filename", ["./out/results.json", '"results.json"'])
@pytest.mark.parametrize(
    "control",
    [
        "The reviewer must not upload {delivery}",
        "The reviewer may upload {delivery}",
        "The UI allows users to upload {delivery}",
        "The parser recognizes `The reviewer must upload {delivery}`",
    ],
)
@pytest.mark.parametrize("independent_first", [False, True])
@pytest.mark.parametrize("body", ["present", "absent", "unavailable"])
def test_issue3883_filename_qualified_controls_preserve_independent_body_floor(
    filename, control, independent_first, body
):
    """A nongating alternative neither adds destinations nor erases another duty."""
    delivery = f"evidence from {filename} either in a PR comment or in an artifact"
    controlled = control.format(delivery=delivery)
    independent = "An independent reviewer must include evidence in the PR body"
    clauses = [independent, controlled] if independent_first else [controlled, independent]
    criterion = "; ".join(clauses)
    assert verifier._required_evidence_channels(criterion) == {"body"}
    assert verifier._required_evidence_options(criterion) == [{"body"}]
    assert _floor_verdict(criterion, body=body, comments="absent", artifacts="absent") == (
        "PASS" if body == "present" else "CONCERNS"
    )


def test_issue3883_filename_qualified_retains_independent_reviewer_body_duty():
    criterion = (
        "The reviewer must upload evidence from results.json both in a PR comment and in an artifact; "
        "an independent reviewer must include evidence in the PR body"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts", "body"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts", "body"}]
    assert (
        _floor_verdict(criterion, body="absent", comments="present", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "filename", ["results.json", "./out/results.json", "/tmp/results.json", '"results.json"']
)
@pytest.mark.parametrize(
    "body,comments,artifacts,expected_verdict",
    [
        ("present", "present", "present", "PASS"),
        ("present", "present", "absent", "PASS"),
        ("present", "absent", "present", "PASS"),
        ("present", "absent", "absent", "CONCERNS"),
        ("absent", "present", "present", "CONCERNS"),
        ("absent", "present", "absent", "CONCERNS"),
        ("absent", "absent", "present", "CONCERNS"),
        ("absent", "absent", "absent", "CONCERNS"),
        ("unavailable", "present", "present", "CONCERNS"),
        ("present", "unavailable", "absent", "CONCERNS"),
        ("present", "absent", "unavailable", "CONCERNS"),
    ],
)
def test_issue3883_filename_qualified_either_retains_independent_body_floor(
    filename, body, comments, artifacts, expected_verdict
):
    """An alternative delivery cannot waive a separate reviewer's body obligation."""
    criterion = (
        f"The reviewer must upload evidence from {filename} either in a PR comment or in an artifact; "
        "an independent reviewer must include evidence in the PR body"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts", "body"}
    assert verifier._required_evidence_options(criterion) == [
        {"comments", "body"},
        {"artifacts", "body"},
    ]
    assert (
        _floor_verdict(criterion, body=body, comments=comments, artifacts=artifacts)
        == expected_verdict
    )


def test_issue3883_quoted_filename_still_retains_quantified_destinations():
    criterion = 'Upload evidence from "results.json" both in a PR comment and in an artifact'
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]


def test_issue3883_optional_clause_does_not_erase_filename_qualified_either():
    criterion = (
        "Evidence may be attached as an artifact; the reviewer must upload evidence from "
        "results.json either in a PR comment or in an artifact"
    )
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments"}, {"artifacts"}]
    assert (
        _floor_verdict(criterion, body="absent", comments="present", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The reviewer must upload evidence from ./out/results.json both in a PR comment and in an artifact",
        "The reviewer must upload evidence from /tmp/results.json both in a PR comment and in an artifact",
        'Upload evidence from "results.json" both in a PR comment and in an artifact',
    ],
)
def test_issue3883_path_and_quoted_filenames_retain_destinations(criterion):
    assert verifier._required_evidence_channels(criterion) == {"comments", "artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"comments", "artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present")
        == "CONCERNS"
    )


@pytest.mark.parametrize(
    "criterion,expected_normalized",
    [
        (
            'Upload evidence from "results.json" both in a PR comment and in an artifact',
            "Upload evidence both in a PR comment and in an artifact",
        ),
        (
            "Upload evidence from results.json before merging the PR",
            "Upload evidence from results.json before merging the PR",
        ),
    ],
)
def test_issue3883_filename_qualifier_normalizes_only_with_destination(
    criterion, expected_normalized
):
    """Quoted+destination strips; filename without a destination stays intact."""
    assert verifier._normalize_evidence_source_filename_qualifiers(criterion) == expected_normalized


def test_issue3883_filename_without_destination_is_not_rewritten_as_quantified():
    criterion = "Upload evidence from results.json before merging the PR"
    normalized = verifier._normalize_evidence_source_filename_qualifiers(criterion)
    assert normalized == criterion
    assert "comments" not in verifier._required_evidence_channels(criterion)
    assert "artifacts" not in verifier._required_evidence_channels(criterion)


def test_issue3883_sentence_period_is_not_part_of_filename_qualifier():
    """A following sentence must not be joined via a trailing period on the filename."""
    criterion = "Upload evidence from results.json. In an artifact the logs are stored separately"
    assert verifier._normalize_evidence_source_filename_qualifiers(criterion) == criterion
    assert "artifacts" not in verifier._required_evidence_channels(criterion)
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == "PASS"
    )


def test_issue3883_standalone_exist_in_artifact_requires_artifact_floor():
    """Bare standalone destinations stay wired after plain-artifact normalization."""
    criterion = "Evidence must exist in an artifact"
    assert "workflow artifact" in verifier._normalize_bare_artifact_destinations(criterion)
    assert verifier._required_evidence_channels(criterion) == {"artifacts"}
    assert verifier._required_evidence_options(criterion) == [{"artifacts"}]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent")
        == "CONCERNS"
    )
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="present") == "PASS"
    )


def test_issue3883_artifact_registry_product_noun_stays_nongating():
    criterion = "The UI must store evidence in an artifact registry"
    assert "workflow artifact" not in verifier._normalize_bare_artifact_destinations(criterion)
    assert verifier._required_evidence_channels(criterion) == set()
    assert verifier._required_evidence_options(criterion) == [set()]
    assert (
        _floor_verdict(criterion, body="present", comments="absent", artifacts="absent") == "PASS"
    )


@pytest.mark.parametrize(
    "criterion",
    [
        "The service must save transcripts to its database",
        "The service must persist command output in its database",
        "The service must log command output in its audit log",
    ],
)
def test_save_persist_log_product_storage_does_not_require_review_evidence(criterion):
    assert verifier._required_evidence_channels(criterion) == set()
    for missing in ("absent", "unavailable"):
        assert (
            _floor_verdict(
                criterion, body=missing, comments=missing, artifacts=missing, overall=missing
            )
            == "PASS"
        )
        independent = criterion + "; the reviewer must report test results in a PR comment"
        assert verifier._required_evidence_channels(independent) == {"comments"}
        assert _floor_verdict(independent, body="present", comments=missing) == "CONCERNS"


@pytest.mark.parametrize("operation", ["save", "persist", "log"])
@pytest.mark.parametrize(
    "destination,channel",
    [("a PR comment", "comments"), ("workflow artifacts", "artifacts"), ("the PR body", "body")],
)
@pytest.mark.parametrize("payload", ["evidence", "transcripts", "command output", "artifacts"])
def test_bounded_storage_shared_review_destination_preserves_floor(
    operation, destination, channel, payload
):
    criterion = f"The service must {operation} {payload} in its database and in {destination}"
    assert verifier._required_evidence_channels(criterion) == {channel}
    for missing in ("absent", "unavailable"):
        assert (
            _floor_verdict(
                criterion,
                body=missing if channel == "body" else "present",
                comments=missing if channel == "comments" else "present",
                artifacts=missing if channel == "artifacts" else "present",
            )
            == "CONCERNS"
        )
