import ast,hashlib,importlib.util,itertools,json,math,subprocess
from pathlib import Path
ROOT=Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/wf3904-bounded-grammar-20261016')
OUT=Path(__file__).parent
path='tests/scripts/test_pr_verifier_delivery_destinations.py'
old=subprocess.check_output(['git','show','12cea89599a67c3004d1d469d669c2daa33dfd35:'+path],cwd=ROOT,text=True)
new=(ROOT/path).read_text()
functions=lambda s:{n.name:n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
before,after=functions(old),functions(new)
manifest=json.loads((ROOT/'docs/ci/verifier-grammar-matrices.json').read_text())
original_tests={n for n in before if n.startswith('test_')};current_tests={n for n in after if n.startswith('test_')}
assert original_tests <= current_tests
assert current_tests-original_tests=={'test_product_component_coordination_real_floor'}
dump=lambda n:ast.dump(n,include_attributes=False)
changed={row['function'] for row in manifest}
unchanged_bodies=[]
for name in original_tests-{'test_product_component_coordination_preserves_bare_other_channel'}:
 assert [dump(n) for n in before[name].body]==[dump(n) for n in after[name].body],name
 if name not in changed:assert [dump(n) for n in before[name].decorator_list]==[dump(n) for n in after[name].decorator_list],name
 unchanged_bodies.append(name)
checks=[]
for row in manifest:
 names=list(row['dimensions']);sizes=[len(row['dimensions'][n]) for n in names]
 axes=row['semantic'];spines=row['lexical_spines'];keys=set()
 for group in [axes,*[[alias,*spine] for alias,spine in spines.items()]]:
  for indices in itertools.product(*(range(len(row['dimensions'][n])) for n in group)):
   selected=dict(zip(group,indices,strict=True));keys.add(tuple(selected.get(n,0) for n in names))
 assert len(keys)==row['retained_count']
 for original in itertools.product(*(range(size) for size in sizes)):
  indexed=dict(zip(names,original,strict=True))
  for group in [axes,*[[alias,*spine] for alias,spine in spines.items()]]:
   projected=tuple(indexed[n] if n in group else 0 for n in names)
   assert projected in keys,(row['function'],original,group)
 checks.append({'function':row['function'],'old_count':math.prod(sizes),'retained_count':len(keys),'all_projection_witnesses_present':True})
for path in ['scripts/langchain/pr_verifier.py','templates/consumer-repo/scripts/langchain/pr_verifier.py','tests/scripts/test_pr_verifier_prompt_coverage.py','tests/scripts/test_pr_verifier_body_overall_integration.py','pyproject.toml']:
 base=subprocess.check_output(['git','show','HEAD:'+path],cwd=ROOT)
 assert base==(ROOT/path).read_bytes(),path
result={'source_base':'12cea89599a67c3004d1d469d669c2daa33dfd35','original_test_names_preserved':len(original_tests),'unchanged_assertion_bodies':len(unchanged_bodies),'unchanged_parametrizations':len(original_tests-changed),'new_real_floor_cases':288,'projection_checks':checks,'production_and_adjacent_inputs_unchanged':True,'test_sha256':hashlib.sha256(new.encode()).hexdigest(),'limitation':'Projection witnesses preserve explicit marginals/interactions, not all deleted joint lexical tuples; compare real production line/arc coverage and mutants separately.'}
(OUT/'mapping-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['projection_checks','limitation']}))
