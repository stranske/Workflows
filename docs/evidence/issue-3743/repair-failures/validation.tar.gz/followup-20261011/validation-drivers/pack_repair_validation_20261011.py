import hashlib
import json
import shutil
import sys
import tarfile
from pathlib import Path

sys.path.insert(0, '/tmp/repair-proof-deps')
from defusedxml import ElementTree as ET

ROOT = Path('/home/runner/work/Workflows/Workflows')
EVIDENCE = ROOT / 'docs/evidence/issue-3743/repair-failures'
OUT = Path('/tmp/repair-validation-20261011')
PREFIX = 'followup-20261011'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def outcomes(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    result = {}
    for case in cases:
        key = (case.attrib['classname'], case.attrib['name'])
        assert key not in result, key
        result[key] = next((status for status in ['error', 'failure', 'skipped'] if case.find(status) is not None), 'pass')
    return result

baseline = outcomes(OUT / 'baseline.xml')
candidate = outcomes(OUT / 'candidate.xml')
assert len(baseline) == 294 and set(baseline.values()) == {'pass'}
assert len(candidate) == 300 and set(candidate.values()) == {'pass'}
new = sorted(set(candidate) - set(baseline))
assert len(new) == 6 and all(key[0].endswith('test_check_deliberate_break_repair_failures') for key in new)
assert baseline.items() <= candidate.items()
focused = outcomes(OUT / 'focused.xml')
assert len(focused) == 6 and set(focused.values()) == {'pass'}
coverage = {}
for name in ['baseline', 'candidate']:
    report = json.loads((OUT / (name + '.json')).read_text())
    assert set(report['files']) == {'scripts/check_deliberate_break.py'}
    coverage[name] = report['files']['scripts/check_deliberate_break.py']
    s = coverage[name]['summary']
    assert (s['num_statements'], s['num_branches'], s['excluded_lines']) == (591, 262, 0)
    assert coverage[name]['excluded_lines'] == []
before, after = coverage['baseline'], coverage['candidate']
line_universe = lambda c: set(c['executed_lines']) | set(c['missing_lines'])
branch_universe = lambda c: {tuple(b) for b in c['executed_branches'] + c['missing_branches']}
assert line_universe(before) == line_universe(after)
assert branch_universe(before) == branch_universe(after)
assert set(before['executed_lines']) <= set(after['executed_lines'])
assert {tuple(b) for b in before['executed_branches']} <= {tuple(b) for b in after['executed_branches']}
assert (before['summary']['covered_lines'], after['summary']['covered_lines']) == (563, 568)
assert (before['summary']['covered_branches'], after['summary']['covered_branches']) == (241, 241)

controls = json.loads((OUT / 'mutations/controls.json').read_text())
assert len(controls['controls']) == 6
supplemental = json.loads((OUT / 'supplemental/controls.json').read_text())
assert len(supplemental) == 4
for control in controls['controls'] + supplemental:
    assert control['red']['exit'] == 1 and control['green']['exit'] == 0
    assert control['original_sha256'] == control['restored_sha256']
    assert control['mutated_sha256'] != control['original_sha256']
reuse = json.loads((OUT / 'reuse-control.json').read_text())
assert reuse['before'] == reuse['after'] and len(reuse['before']) == 37

fresh = dict(
    interpreter=json.loads((OUT / 'interpreter.json').read_text()),
    baseline_tests=len(baseline), candidate_tests=len(candidate), new_nodes=new,
    removed_nodes=[], old_outcome_changes=[], covered_line_regressions=[], covered_branch_regressions=[],
    baseline=before['summary'], candidate=after['summary'],
    new_covered_lines=sorted(set(after['executed_lines']) - set(before['executed_lines'])),
    production_mutations=6, supplemental_mutations=4, output_reuse_unchanged_files=37,
    assertions='Independent retries do not cache failed repairs; reporting exceptions propagate with the original repair exception chain after archive cleanup.',
    caller_bindings=controls['caller_identity'], evidence_prefix=PREFIX + '/',
)
(OUT / 'comparison.json').write_text(json.dumps(fresh, indent=2) + '\n')
shutil.copy2(__file__, OUT / 'validation-drivers' / Path(__file__).name)
comparison = json.loads((EVIDENCE / 'comparison.json').read_text())
comparison['followup_20261011'] = fresh
(EVIDENCE / 'comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')

manifest = json.loads((EVIDENCE / 'manifest.json').read_text())
archive_path = EVIDENCE / 'validation.tar.gz'
old_members = manifest['members']
archive_bytes = archive_path.read_bytes()
assert digest(archive_bytes) == manifest['archive']['sha256']
assert len(archive_bytes) == manifest['archive']['bytes']
new_archive = OUT / 'packed.tar.gz'
with tarfile.open(archive_path) as old, tarfile.open(new_archive, 'w:gz') as new_archive_file:
    assert set(old.getnames()) == set(old_members)
    for member in old.getmembers():
        data = old.extractfile(member).read()
        assert digest(data) == old_members[member.name]['sha256']
        assert len(data) == old_members[member.name]['bytes']
        new_archive_file.addfile(member, old.extractfile(member))
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path != new_archive:
            new_archive_file.add(path, arcname=PREFIX + '/' + str(path.relative_to(OUT)), recursive=False)
shutil.copy2(new_archive, archive_path)
members = {}
with tarfile.open(archive_path) as archive:
    assert len(archive.getnames()) == len(set(archive.getnames()))
    for member in archive.getmembers():
        data = archive.extractfile(member).read()
        members[member.name] = dict(sha256=digest(data), bytes=len(data))
    assert old_members.items() <= members.items()
manifest['archive'] = dict(file='validation.tar.gz', sha256=digest(archive_path.read_bytes()), bytes=archive_path.stat().st_size)
manifest['members'] = members
manifest['current_files'] = {path: digest((EVIDENCE / path).read_bytes()) for path in manifest['current_files']}
manifest['test_file']['sha256'] = digest((ROOT / manifest['test_file']['path']).read_bytes())
assert all(digest((ROOT / path).read_bytes()) == value for path, value in manifest['production_files'].items())
manifest['preserved_members'] = len(old_members)
(EVIDENCE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(baseline=294, candidate=300, new_nodes=6, members=len(members), preserved=len(old_members))))
