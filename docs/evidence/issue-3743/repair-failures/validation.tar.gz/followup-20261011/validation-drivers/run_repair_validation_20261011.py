import concurrent.futures
import datetime
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path('/home/runner/work/Workflows/Workflows')
OUT = Path('/tmp/repair-validation-20261011')
DEPS = '/tmp/repair-proof-deps'
TEST = 'tests/scripts/test_check_deliberate_break_repair_failures.py'
DRIVER = 'docs/evidence/issue-3743/repair-failures/replay.py'
HELPER = 'scripts/check_deliberate_break.py'
IDENTITIES = [TEST, DRIVER, HELPER, 'templates/consumer-repo/' + HELPER]
MODULES = [
    'test_check_deliberate_break', 'test_check_deliberate_break_archive',
    'test_check_deliberate_break_launch_boundaries', 'test_check_deliberate_break_runtime_probes',
    'test_launch_mutation_driver', 'test_runtime_probe_replay',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def hashes():
    return {path: digest((ROOT / path).read_bytes()) for path in IDENTITIES}

def output_hashes(path):
    return {str(p.relative_to(path)): digest(p.read_bytes()) for p in path.rglob('*') if p.is_file()}

def run(name, argv, extra=None, expected=0):
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.update(extra or {})
    before = hashes()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + '.log')).open('w') as log:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    receipt = dict(argv=argv, cwd=str(ROOT), exit=result.returncode, started_at=started,
                   finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   before=before, after=hashes(), environment=extra or {}, unset_environment=['PYTHONPATH'])
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == expected, (OUT / (name + '.log')).read_text()
    assert before == hashes()

def supplemental():
    sys.path.insert(0, DEPS)
    replay = runpy.run_path(str(ROOT / DRIVER))
    mutations = {
        'negative-cache': (
            '    repo = cwd or Path.cwd()\n    test_path = repo / spec.test_file',
            '    if "_repair_failure_cache" in globals():\n        return globals()["_repair_failure_cache"]\n'
            '    repo = cwd or Path.cwd()\n    test_path = repo / spec.test_file',
            '    except RuntimeDependencyError as wrapped:\n        return _runtime_dependency_error_result(wrapped.error)\n    except CommandUnavailableError as wrapped:',
            '    except RuntimeDependencyError as wrapped:\n'
            '        result = _runtime_dependency_error_result(wrapped.error)\n'
            '        globals()["_repair_failure_cache"] = result\n        return result\n'
            '    except CommandUnavailableError as wrapped:',
        ),
        'swallowed-reporter': (
            '    except RuntimeDependencyError as wrapped:\n        return _runtime_dependency_error_result(wrapped.error)\n    except CommandUnavailableError as wrapped:',
            '    except RuntimeDependencyError as wrapped:\n'
            '        try:\n            return _runtime_dependency_error_result(wrapped.error)\n'
            '        except RuntimeError:\n            return _json_result(VERDICT_BROKEN, reason="mutated-report")\n'
            '    except CommandUnavailableError as wrapped:',
        ),
    }
    controls = []
    with tempfile.TemporaryDirectory(prefix='repair-repeat-mutations-') as tmp:
        tree = Path(tmp)
        for relative in [TEST, HELPER, 'templates/consumer-repo/' + HELPER]:
            dst = tree / relative
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / relative, dst)
        for copy, prefix in [('root', ''), ('template', 'templates/consumer-repo/')]:
            source = tree / prefix / HELPER
            original = source.read_bytes()
            for kind, replacements in mutations.items():
                # Restrict replacements to verify_spec, keeping runtime ownership intact.
                start = original.index(b'def verify_spec(')
                block = original[start:].decode()
                for before, after in zip(replacements[::2], replacements[1::2], strict=True):
                    expected = 2 if before.startswith('    except RuntimeDependencyError') else 1
                    assert block.count(before) == expected, (kind, block.count(before))
                    # Only change the base-runtime handler, the final matching occurrence.
                    index = block.rindex(before)
                    block = block[:index] + block[index:].replace(before, after, 1)
                mutated = original[:start] + block.encode()
                case = OUT / 'supplemental' / f'{copy}-{kind}'
                case.mkdir(parents=True)
                node = TEST + '::test_base_dependency_failure_keeps_its_cause_and_cleans_real_archive' + f'[{copy}]'
                try:
                    source.write_bytes(mutated)
                    red = replay['run_case'](tree, case, node, 'red')
                finally:
                    source.write_bytes(original)
                assert source.read_bytes() == original
                green = replay['run_case'](tree, case, node, 'green')
                controls.append(dict(copy=copy, kind=kind, original_sha256=digest(original),
                                     mutated_sha256=digest(mutated), restored_sha256=digest(source.read_bytes()),
                                     test_sha256=digest((tree / TEST).read_bytes()), red=red, green=green))
    (OUT / 'supplemental' / 'controls.json').write_text(json.dumps(controls, indent=2) + '\n')
    print('Four supplemental mutations RED then restored GREEN', flush=True)

def suite(name):
    files = ['tests/scripts/' + p + '.py' for p in MODULES]
    if name == 'candidate':
        files.append(TEST)
    run(name, [sys.executable, '-m', 'pytest', *files, '-q', '-o', 'addopts=', '-m', 'not slow',
               '--cov=scripts.check_deliberate_break', '--cov-branch', '--cov-report=term-missing',
               '--cov-report=json:' + str(OUT / (name + '.json')),
               '--junitxml=' + str(OUT / (name + '.xml'))],
        extra={'COVERAGE_FILE': str(OUT / (name + '.coverage')),
               'GITHUB_STEP_SUMMARY': str(OUT / (name + '-step-summary.md'))})

if __name__ == '__main__':
    stage = sys.argv[1]
    if stage == 'proof':
        OUT.mkdir(exist_ok=False)
        run('focused', [sys.executable, '-m', 'pytest', TEST, '-q', '-o', 'addopts=', '-m', 'not slow',
                        '--junitxml=' + str(OUT / 'focused.xml')])
        (OUT / 'interpreter.json').write_text(json.dumps(dict(available=sys.executable, version=sys.version,
            requested='/opt/anaconda3/bin/python3', requested_available=Path('/opt/anaconda3/bin/python3').exists()), indent=2))
        run('mutations', [sys.executable, DRIVER, '--output', '/tmp/new-repair-proof'], extra={'PYTHONPATH': DEPS})
        proof = Path('/tmp/new-repair-proof')
        before = output_hashes(proof)
        run('reuse', [sys.executable, DRIVER, '--output', str(proof)], extra={'PYTHONPATH': DEPS}, expected=1)
        after = output_hashes(proof)
        assert before == after
        (OUT / 'reuse-control.json').write_text(json.dumps(dict(before=before, after=after), indent=2))
        shutil.copytree(proof, OUT / 'mutations')
        supplemental()
        dst = OUT / 'validation-drivers' / Path(__file__).name
        dst.parent.mkdir(); shutil.copy2(__file__, dst)
        for relative in IDENTITIES:
            dst = OUT / 'snapshots' / relative
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(ROOT / relative, dst)
    elif stage == 'suites':
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(suite, ['baseline', 'candidate']))
    elif stage == 'checks':
        run('black-repo', ['black', '--check', '--line-length', '100', '--exclude', '(\\.workflows-lib|node_modules)', '.'],
            extra={'BLACK_CACHE_DIR': '/tmp/repair-black-cache-20261011', 'BLACK_NUM_WORKERS': '1'})
        run('ruff', ['ruff', 'check', TEST, DRIVER])
        run('template-completeness', [sys.executable, 'scripts/validate_template_completeness.py'],
            extra={'GITHUB_STEP_SUMMARY': str(OUT / 'template-step-summary.md')})
        run('diff-check', ['git', 'diff', '--check'])
        run('base-parity', [sys.executable, '-c',
            "import hashlib,subprocess; from pathlib import Path; "
            "paths=['scripts/check_deliberate_break.py','templates/consumer-repo/scripts/check_deliberate_break.py']; "
            "originals=[subprocess.check_output(['git','show','9a0219f361e4ba4b9072a554362ef378ff47ec4c:'+p]) for p in paths]; "
            "current=[Path(p).read_bytes() for p in paths]; assert originals[0]==originals[1]==current[0]==current[1]; "
            "print(hashlib.sha256(current[0]).hexdigest())"])
