import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/runner/work/Workflows/Workflows')
OUT = Path('/tmp/repair-validation-20261010')
OUT.mkdir(exist_ok=False)
IDENTITIES = ['scripts/check_deliberate_break.py', 'templates/consumer-repo/scripts/check_deliberate_break.py', 'tests/scripts/test_check_deliberate_break_repair_failures.py', 'docs/evidence/issue-3743/repair-failures/replay.py']

def hashes():
    return {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in IDENTITIES}

def run(name, argv, *, extra=None, expected=0):
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.update(extra or {})
    before = hashes()
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + '.log')).open('w') as stream:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    receipt = dict(argv=argv, cwd=str(ROOT), exit=result.returncode, started_at=start, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), before=before, after=hashes(), environment=extra or {}, unset_environment=['PYTHONPATH'])
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == expected, name
    assert before == hashes()

run('focused', [sys.executable, '-m', 'pytest', IDENTITIES[2], '-q', '-o', 'addopts=', '-m', 'not slow', '--junitxml=' + str(OUT / 'focused.xml')])
run('mutations', [sys.executable, 'docs/evidence/issue-3743/repair-failures/replay.py', '--output', '/tmp/new-repair-proof'], extra={'PYTHONPATH': '/tmp/repair-replay-deps'})
proof = Path('/tmp/new-repair-proof')
before = {str(p.relative_to(proof)): hashlib.sha256(p.read_bytes()).hexdigest() for p in proof.rglob('*') if p.is_file()}
run('reuse', [sys.executable, 'docs/evidence/issue-3743/repair-failures/replay.py', '--output', str(proof)], extra={'PYTHONPATH': '/tmp/repair-replay-deps'}, expected=1)
after = {str(p.relative_to(proof)): hashlib.sha256(p.read_bytes()).hexdigest() for p in proof.rglob('*') if p.is_file()}
assert before == after
(OUT / 'reuse-control.json').write_text(json.dumps(dict(before=before, after=after), indent=2) + '\n')
modules = ['test_check_deliberate_break', 'test_check_deliberate_break_archive', 'test_check_deliberate_break_launch_boundaries', 'test_check_deliberate_break_runtime_probes', 'test_launch_mutation_driver', 'test_runtime_probe_replay']
for name in ['baseline', 'candidate']:
    files = ['tests/scripts/' + p + '.py' for p in modules]
    if name == 'candidate':
        files.append(IDENTITIES[2])
    run(name, [sys.executable, '-m', 'pytest', *files, '-q', '-o', 'addopts=', '-m', 'not slow', '--cov=scripts.check_deliberate_break', '--cov-branch', '--cov-report=term-missing', '--cov-report=json:' + str(OUT / (name + '.json')), '--junitxml=' + str(OUT / (name + '.xml'))], extra={'COVERAGE_FILE': str(OUT / (name + '.coverage')), 'GITHUB_STEP_SUMMARY': str(OUT / (name + '-step-summary.md'))})
run('black-serial', [sys.executable, 'docs/evidence/issue-3743/runtime-probes/revalidation/black_serial.py'], extra={'BLACK_CACHE_DIR': '/tmp/repair-black-cache'})
run('black-repo', ['black', '--check', '--line-length', '100', '--exclude', '(\\.workflows-lib|node_modules)', '.'], extra={'BLACK_CACHE_DIR': '/tmp/repair-black-cache', 'BLACK_NUM_WORKERS': '1'})
run('ruff', ['ruff', 'check', IDENTITIES[2], IDENTITIES[3]])
run('template-completeness', [sys.executable, 'scripts/validate_template_completeness.py'])
run('diff-check', ['git', 'diff', '--check'])
run('base-parity', [sys.executable, '-c', "import hashlib,subprocess; from pathlib import Path; paths=['scripts/check_deliberate_break.py','templates/consumer-repo/scripts/check_deliberate_break.py']; originals=[subprocess.check_output(['git','show','9a0219f361e4ba4b9072a554362ef378ff47ec4c:'+p]) for p in paths]; current=[Path(p).read_bytes() for p in paths]; assert originals[0]==originals[1]==current[0]==current[1]; print(hashlib.sha256(current[0]).hexdigest())"])
