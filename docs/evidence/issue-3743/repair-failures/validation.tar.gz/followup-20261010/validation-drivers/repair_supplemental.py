import hashlib
import json
import runpy
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, '/tmp/repair-replay-deps')
root = Path('/home/runner/work/Workflows/Workflows')
replay = runpy.run_path(str(root / 'docs/evidence/issue-3743/repair-failures/replay.py'))
output = Path('/tmp/repair-validation-20261010/supplemental')
output.mkdir(exist_ok=False)
controls = []
mutations = {
    'early-report': (
        '            base_run = _run_with_runtime_deps(spec.command, base_dir)',
        '            try:\n                base_run = _run_with_runtime_deps(spec.command, base_dir)\n            except RuntimeDependencyError as wrapped:\n                return _runtime_dependency_error_result(wrapped.error)',
        'test_base_dependency_failure_keeps_its_cause_and_cleans_real_archive',
    ),
    'extra-probe': (
        '    except (subprocess.TimeoutExpired, subprocess.CalledProcessError, ImportError, OSError) as exc:\n        raise RuntimeDependencyError(exc) from exc',
        '    except (subprocess.TimeoutExpired, subprocess.CalledProcessError, ImportError, OSError) as exc:\n        _run((sys.executable, "-c", "pass"), cwd)\n        raise RuntimeDependencyError(exc) from exc',
        'test_base_dependency_failure_keeps_its_cause_and_cleans_real_archive',
    ),
}
with tempfile.TemporaryDirectory(prefix='repair-added-assertions-') as private:
    tree = Path(private)
    for relative in [replay['TEST'], replay['HELPER'], 'templates/consumer-repo/' + replay['HELPER']]:
        target = tree / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / relative, target)
    for copy, prefix in [('root', ''), ('template', 'templates/consumer-repo/')]:
        source = tree / prefix / replay['HELPER']
        original = source.read_bytes()
        for kind, (before, after, name) in mutations.items():
            case = output / (copy + '-' + kind)
            case.mkdir()
            assert original.decode().count(before) == 1
            mutated = original.decode().replace(before, after).encode()
            node = f"{replay['TEST']}::{name}[{copy}]"
            try:
                source.write_bytes(mutated)
                red = replay['run_case'](tree, case, node, 'red')
            finally:
                source.write_bytes(original)
            green = replay['run_case'](tree, case, node, 'green')
            controls.append(dict(copy=copy, kind=kind, red=red, green=green, original_sha256=hashlib.sha256(original).hexdigest(), mutated_sha256=hashlib.sha256(mutated).hexdigest(), restored_sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(output / 'controls.json').write_text(json.dumps(controls, indent=2) + '\n')
print('4 supplemental production mutations RED, exact restorations GREEN')
