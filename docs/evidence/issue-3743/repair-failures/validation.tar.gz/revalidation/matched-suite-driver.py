from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/runner/work/Workflows/Workflows')
OUT = Path('/tmp/repair-matched-suites')
OUT.mkdir(exist_ok=False)
MODULES = ['tests/scripts/test_check_deliberate_break.py',
           'tests/scripts/test_check_deliberate_break_archive.py',
           'tests/scripts/test_check_deliberate_break_launch_boundaries.py',
           'tests/scripts/test_check_deliberate_break_runtime_probes.py',
           'tests/scripts/test_launch_mutation_driver.py',
           'tests/scripts/test_runtime_probe_replay.py']
PATHS = ['scripts/check_deliberate_break.py',
         'templates/consumer-repo/scripts/check_deliberate_break.py',
         'tests/scripts/test_check_deliberate_break_repair_failures.py',
         'docs/evidence/issue-3743/repair-failures/replay.py']

def hashes():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in PATHS}

def run(name):
    tests = MODULES + ([PATHS[2]] if name == 'candidate' else [])
    argv = [sys.executable, '-m', 'pytest', *tests, '-q', '-o', 'addopts=',
            '-m', 'not slow', '--cov=scripts.check_deliberate_break', '--cov-branch',
            '--cov-report=term-missing', '--cov-report=json:' + str(OUT / (name + '.json')),
            '--junitxml=' + str(OUT / (name + '.xml'))]
    env = dict(os.environ, BLACK_NUM_WORKERS='1', BLACK_CACHE_DIR='/tmp/repair-black-cache',
               GITHUB_STEP_SUMMARY=str(OUT / (name + '-step-summary.md')),
               COVERAGE_FILE=str(OUT / (name + '.coverage')))
    env.pop('PYTHONPATH', None)
    before = hashes()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + '.log')).open('w') as stream:
        process = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=600)
    receipt = {'argv': argv, 'cwd': str(ROOT), 'exit': process.returncode,
               'started_at': started,
               'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'before': before, 'after': hashes(),
               'environment': {k: env[k] for k in ('BLACK_NUM_WORKERS', 'BLACK_CACHE_DIR',
                                                 'GITHUB_STEP_SUMMARY', 'COVERAGE_FILE')},
               'unset_environment': ['PYTHONPATH']}
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    assert before == receipt['after']
    assert process.returncode == 0, (OUT / (name + '.log')).read_text()
    print(name, 'exit', process.returncode, flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run, ['baseline', 'candidate']))
