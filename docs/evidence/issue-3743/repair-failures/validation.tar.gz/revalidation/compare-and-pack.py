import hashlib
from io import BytesIO
import json
from pathlib import Path
import subprocess
import tarfile

from defusedxml import ElementTree as ET, EntitiesForbidden

ROOT = Path('/home/runner/work/Workflows/Workflows')
OUT = Path('/tmp/repair-validation-v3')
SUITES = Path('/tmp/repair-matched-suites')
EVIDENCE = ROOT / 'docs/evidence/issue-3743/repair-failures'
HELPER = 'scripts/check_deliberate_break.py'
TEST = 'tests/scripts/test_check_deliberate_break_repair_failures.py'
DRIVER = 'docs/evidence/issue-3743/repair-failures/replay.py'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def nodes(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    result = {(c.get('classname'), c.get('name')):
              tuple(child.tag for child in c if child.tag in ('failure', 'error', 'skipped'))
              for c in cases}
    assert len(result) == len(cases)
    assert all(not outcome for outcome in result.values())
    return result

b = json.loads((SUITES / 'baseline.json').read_text())['files'][HELPER]
c = json.loads((SUITES / 'candidate.json').read_text())['files'][HELPER]
bn = nodes(SUITES / 'baseline.xml')
cn = nodes(SUITES / 'candidate.xml')
new = sorted(set(cn) - set(bn))
assert len(bn) == 294 and len(cn) == 300 and len(new) == 6
assert not (set(bn) - set(cn))
assert all(cn[node] == outcome for node, outcome in bn.items())
for scope in ('num_statements', 'num_branches', 'excluded_lines'):
    assert b['summary'][scope] == c['summary'][scope]
assert [b['summary'][k] for k in ('num_statements', 'num_branches', 'excluded_lines')] == [591, 262, 0]
assert set(b['executed_lines']).issubset(c['executed_lines'])
assert set(map(tuple, b['executed_branches'])).issubset(map(tuple, c['executed_branches']))
assert b['summary']['covered_lines'] == 563 and c['summary']['covered_lines'] == 568
assert b['summary']['covered_branches'] == c['summary']['covered_branches'] == 241
controls = json.loads(Path('/tmp/new-repair-proof/controls.json').read_text())
assert len(controls['controls']) == 6 and len(controls['caller_identity']) == 4
for path, digest in controls['caller_identity'].items():
    assert sha((ROOT / path).read_bytes()) == digest
for control in controls['controls']:
    assert control['original_sha256'] == control['restored_sha256']
    assert control['original_sha256'] != control['mutated_sha256']
    assert control['red']['exit'] == 1 and control['green']['exit'] == 0
reuse = json.loads((OUT / 'output-reuse-hashes.json').read_text())
assert reuse['before'] == reuse['after'] and len(reuse['before']) == 37
try:
    ET.fromstring('<!DOCTYPE proof [<!ENTITY boom "blocked">]><proof>&boom;</proof>')
except EntitiesForbidden:
    (OUT / 'parser-hardening-control.json').write_text(json.dumps({'entity': 'EntitiesForbidden',
        'version': '0.7.1', 'location': '/tmp/repair-python-deps'}, indent=2) + '\n')
else:
    raise AssertionError('entity accepted')

comparison = json.loads((EVIDENCE / 'comparison.json').read_text())
prior_comparison = (EVIDENCE / 'comparison.json').read_bytes()
comparison.update(test_sha256=sha((ROOT / TEST).read_bytes()),
                  driver_sha256=sha((ROOT / DRIVER).read_bytes()),
                  baseline=b['summary'], candidate=c['summary'], new_nodes=new)
comparison['revalidation'] = {
    'python': '3.14.7', 'interpreter': '/opt/hostedtoolcache/Python/3.14.7/x64/bin/python3',
    'requested_interpreter_available': False,
    'requested_interpreter': '/opt/anaconda3/bin/python3',
    'previous_test_sha256': json.loads(prior_comparison)['test_sha256'],
    'caller_bindings': controls['caller_identity'],
    'output_reuse_files_unchanged': 37,
    'archive_assertions': 'Populated base archive, current candidate overlay, exact repair exception identity, and exactly one head/base launch.',
    'dependency_provenance': 'revalidation/dependency-provenance.json',
    'no_covered_branch_regressions': True,
    'suite_environment': 'PYTHONPATH unset for both matched suites; parser dependency path only needed for repair replay.',
}
(EVIDENCE / 'comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')

members = {}
with tarfile.open(EVIDENCE / 'validation.tar.gz', 'r:gz') as archive:
    for item in archive.getmembers():
        assert item.isfile() and item.name not in members
        members[item.name] = archive.extractfile(item).read()
original_manifest = json.loads((EVIDENCE / 'manifest.json').read_text())
assert set(members) == set(original_manifest['members'])
assert all(sha(data) == original_manifest['members'][name]['sha256'] and
           len(data) == original_manifest['members'][name]['bytes']
           for name, data in members.items())

members['revalidation/prior-comparison.json'] = prior_comparison
for relative, name in [(TEST, 'prior-test.py'), (DRIVER, 'prior-replay.py')]:
    members['revalidation/' + name] = subprocess.run(
        ['git', 'show', 'HEAD:' + relative], cwd=ROOT, check=True, capture_output=True).stdout
assert sha(members['revalidation/prior-test.py']) == json.loads(prior_comparison)['test_sha256']
assert sha(members['revalidation/prior-replay.py']) == json.loads(prior_comparison)['driver_sha256']
for relative, name in [(TEST, 'test.py'), (DRIVER, 'replay.py')]:
    members['revalidation/' + name] = (ROOT / relative).read_bytes()
for path in OUT.iterdir():
    if path.is_file() and path.suffix in ('.json', '.log', '.xml', '.md'):
        prefix = ('revalidation/with-replay-import-path/'
                  if path.name.startswith(('baseline', 'candidate')) else 'revalidation/')
        members[prefix + path.name] = path.read_bytes()
for path in SUITES.iterdir():
    if path.is_file() and path.suffix in ('.json', '.log', '.xml', '.md'):
        members['revalidation/' + path.name] = path.read_bytes()
for path in Path('/tmp/new-repair-proof').rglob('*'):
    if path.is_file():
        members['revalidation/mutations/' + str(path.relative_to('/tmp/new-repair-proof'))] = path.read_bytes()
provenance = json.loads(Path('/tmp/repair-dependency-provenance.json').read_text())
for item in provenance['files']:
    item['sha256'] = sha(Path(item['path']).read_bytes())
    item['archive_member'] = 'revalidation/dependency-source/defusedxml/' + Path(item['path']).name
    members[item['archive_member']] = Path(item['path']).read_bytes()
members['revalidation/dependency-provenance.json'] = (json.dumps(provenance, indent=2) + '\n').encode()
members['revalidation/process-driver.py'] = Path('/tmp/repair_validation.py').read_bytes()
members['revalidation/matched-suite-driver.py'] = Path('/tmp/repair_matched_suites.py').read_bytes()
members['revalidation/compare-and-pack.py'] = Path(__file__).read_bytes()
for path in Path('/tmp/repair-validation-v2').iterdir():
    if path.is_file():
        members['revalidation/initial-attempt/' + path.name] = path.read_bytes()

archive_path = EVIDENCE / 'validation.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, data in sorted(members.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        archive.addfile(item, BytesIO(data))
manifest = {
    'archive': {'file': 'validation.tar.gz', 'sha256': sha(archive_path.read_bytes()),
                'bytes': archive_path.stat().st_size},
    'members': {name: {'sha256': sha(data), 'bytes': len(data)}
                for name, data in sorted(members.items())},
    'current_files': {name: sha((EVIDENCE / name).read_bytes())
                      for name in ('replay.py', 'comparison.json')},
    'test_file': {'path': TEST, 'sha256': sha((ROOT / TEST).read_bytes())},
    'production_files': {path: sha((ROOT / path).read_bytes())
                         for path in (HELPER, 'templates/consumer-repo/' + HELPER)},
    'preserved_members': len(original_manifest['members']),
}
(EVIDENCE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive_path) as archive:
    assert {item.name for item in archive.getmembers()} == set(manifest['members'])
    for name, binding in manifest['members'].items():
        data = archive.extractfile(name).read()
        assert sha(data) == binding['sha256'] and len(data) == binding['bytes']
for name, digest in manifest['current_files'].items():
    assert sha((EVIDENCE / name).read_bytes()) == digest
assert sha((ROOT / manifest['test_file']['path']).read_bytes()) == manifest['test_file']['sha256']
assert manifest['production_files'][HELPER] == manifest['production_files']['templates/consumer-repo/' + HELPER]
for path, digest in manifest['production_files'].items():
    base_bytes = subprocess.run(['git', 'show', comparison['base'] + ':' + path],
                                cwd=ROOT, check=True, capture_output=True).stdout
    assert sha(base_bytes) == digest == comparison['source_sha256']
for item in provenance['files']:
    assert sha(members[item['archive_member']]) == item['sha256']
print('294 -> 300 PASS; 591 statements/262 branches/0 exclusions;',
      '563 -> 568 covered statements/241 covered branches;', len(members), 'verified archive members')
