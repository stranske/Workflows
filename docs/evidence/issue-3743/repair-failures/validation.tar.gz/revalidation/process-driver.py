import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/runner/work/Workflows/Workflows')
OUT = Path('/tmp/repair-validation-v3')
OUT.mkdir(exist_ok=False)
DRIVER = 'docs/evidence/issue-3743/repair-failures/replay.py'
TEST = 'tests/scripts/test_check_deliberate_break_repair_failures.py'
HELPER = 'scripts/check_deliberate_break.py'

def hashes():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
            for p in (HELPER, 'templates/consumer-repo/' + HELPER, TEST, DRIVER)}

def run(name, argv, expected=0):
    before = hashes()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = dict(os.environ, BLACK_NUM_WORKERS='1', BLACK_CACHE_DIR='/tmp/repair-black-cache',
               PYTHONPATH='/tmp/repair-python-deps', GITHUB_STEP_SUMMARY=str(OUT / 'step-summary.md'),
               COVERAGE_FILE=str(OUT / (name + '.coverage')))
    with (OUT / (name + '.log')).open('w') as stream:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=300)
    receipt = {'argv': argv, 'cwd': str(ROOT), 'exit': result.returncode,
               'started_at': started,
               'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'before': before, 'after': hashes(),
               'environment': {k: env[k] for k in ('BLACK_NUM_WORKERS', 'BLACK_CACHE_DIR',
                   'PYTHONPATH', 'GITHUB_STEP_SUMMARY', 'COVERAGE_FILE')}}
    (OUT / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, 'exit', result.returncode, flush=True)
    assert receipt['before'] == receipt['after']
    assert result.returncode == expected, (OUT / (name + '.log')).read_text()

run('focused', [sys.executable, '-m', 'pytest', TEST, '-q', '-o', 'addopts=',
                '-m', 'not slow', '--junitxml=' + str(OUT / 'focused.xml')])
run('replay', ['python3', DRIVER, '--output', '/tmp/new-repair-proof'])
replay = Path('/tmp/new-repair-proof')
previous = {str(p.relative_to(replay)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in replay.rglob('*') if p.is_file()}
run('output-reuse-refusal', ['python3', DRIVER, '--output', str(replay)], expected=1)
current = {str(p.relative_to(replay)): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in replay.rglob('*') if p.is_file()}
assert previous == current
(OUT / 'output-reuse-hashes.json').write_text(json.dumps({'before': previous, 'after': current}, indent=2))
modules = ['tests/scripts/test_check_deliberate_break.py',
           'tests/scripts/test_check_deliberate_break_archive.py',
           'tests/scripts/test_check_deliberate_break_launch_boundaries.py',
           'tests/scripts/test_check_deliberate_break_runtime_probes.py',
           'tests/scripts/test_launch_mutation_driver.py',
           'tests/scripts/test_runtime_probe_replay.py']
for name, tests in [('baseline', modules), ('candidate', modules + [TEST])]:
    run(name, [sys.executable, '-m', 'pytest', *tests, '-q', '-o', 'addopts=',
               '-m', 'not slow', '--cov=scripts.check_deliberate_break', '--cov-branch',
               '--cov-report=term-missing', '--cov-report=json:' + str(OUT / (name + '.json')),
               '--junitxml=' + str(OUT / (name + '.xml'))])
run('black-repo', ['black', '--check', '--line-length', '100', '--exclude',
                   r'(\.workflows-lib|node_modules)', '.'])
run('ruff', ['ruff', 'check', TEST, DRIVER])
run('template-completeness', [sys.executable, 'scripts/validate_template_completeness.py'])
run('diff-check', ['git', 'diff', '--check'])
run('production-parity', ['git', 'diff', '--exit-code',
                         '9a0219f361e4ba4b9072a554362ef378ff47ec4c', '--', HELPER,
                         'templates/consumer-repo/' + HELPER])
assert (ROOT / HELPER).read_bytes() == (ROOT / 'templates/consumer-repo' / HELPER).read_bytes()
