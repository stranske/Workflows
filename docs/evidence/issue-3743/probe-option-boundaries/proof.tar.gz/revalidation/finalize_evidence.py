from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

ROOT=Path.cwd()
OUT=Path('/tmp/probe-option-revalidation')
EVIDENCE=ROOT/'docs/evidence/issue-3743/probe-option-boundaries'
archive_path=EVIDENCE/'proof.tar.gz'

def fingerprint(data):
    return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}

with tarfile.open(archive_path) as archive:
    members={m.name:archive.extractfile(m).read() for m in archive.getmembers()}
original_members=dict(members)
for path in OUT.rglob('*'):
    if not path.is_file() or path.name.startswith('.coverage') or '__pycache__' in path.parts:
        continue
    name='revalidation/'+str(path.relative_to(OUT))
    if name in members:
        assert members[name]==path.read_bytes(),name
    else:
        members[name]=path.read_bytes()
manifest_name='revalidation/manifest.json'
members[manifest_name]=(json.dumps({name:fingerprint(data) for name,data in sorted(members.items()) if name!=manifest_name},indent=2)+'\n').encode()
with tarfile.open(archive_path,'w:gz') as archive:
    for name,data in sorted(members.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        info.mode=0o644
        info.mtime=0
        archive.addfile(info,io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    observed={m.name:archive.extractfile(m).read() for m in archive.getmembers()}
assert observed==members
assert all(members[name]==data for name,data in original_members.items() if name!=manifest_name)
manifest=json.loads(members[manifest_name])
assert set(manifest)==set(members)-{manifest_name}
assert all(fingerprint(members[name])==record for name,record in manifest.items())
with tarfile.open(fileobj=io.BytesIO(members['historical-proof.tar.gz'])) as historical:
    old={m.name:historical.extractfile(m).read() for m in historical.getmembers()}
assert all(members[name]==data for name,data in old.items())
summary=json.loads((EVIDENCE/'summary.json').read_text())
for relative,entry in summary['current_validation']['current_inputs'].items():
    assert fingerprint((ROOT/relative).read_bytes())==entry
assert summary['test_sha256']==summary['current_validation']['current_inputs']['tests/scripts/test_check_deliberate_break_probe_option_boundaries.py']['sha256']
assert summary['replay_sha256']==summary['current_validation']['current_inputs']['docs/evidence/issue-3743/probe-option-boundaries/replay.py']['sha256']
assert fingerprint(members['historical-proof.tar.gz'])=={'sha256':summary['historical_proof']['archive_sha256'],'bytes':summary['historical_proof']['archive_bytes']}
assert summary['metrics']==summary['current_validation']['metrics']
allowed={str(p.relative_to(ROOT)) for p in [EVIDENCE/'README.md',EVIDENCE/'proof.tar.gz',EVIDENCE/'replay.py',EVIDENCE/'summary.json',ROOT/'tests/scripts/test_check_deliberate_break_probe_option_boundaries.py']}
changed=set(subprocess.run(['git','diff','--name-only'],capture_output=True,text=True,check=True).stdout.splitlines())
assert changed==allowed
subprocess.run(['git','diff','--check'],check=True)
summary['archive_sha256']=fingerprint(archive_path.read_bytes())['sha256']
summary['archive_bytes']=archive_path.stat().st_size
summary['archive_member_count']=len(members)
(EVIDENCE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Final audit PASS:',len(members),'member hashes/lengths, current bindings, all historical proof bytes, five scoped paths')
