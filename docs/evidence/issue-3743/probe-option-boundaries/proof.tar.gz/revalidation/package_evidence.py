from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path.cwd()
OUT = Path('/tmp/probe-option-revalidation')
EVIDENCE = ROOT / 'docs/evidence/issue-3743/probe-option-boundaries'
archive_path = EVIDENCE / 'proof.tar.gz'
original_archive = archive_path.read_bytes()
original_summary = json.loads((OUT / 'historical-summary.json').read_text())
audit = json.loads((OUT / 'audit-summary.json').read_text())

def fingerprint(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

with tarfile.open(fileobj=io.BytesIO(original_archive)) as archive:
    original_members = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
all_members = dict(original_members)
all_members['historical-proof.tar.gz'] = original_archive
for path in OUT.rglob('*'):
    if not path.is_file() or path.name.startswith('.coverage') or '__pycache__' in path.parts:
        continue
    name = 'revalidation/' + str(path.relative_to(OUT))
    assert name not in all_members
    all_members[name] = path.read_bytes()
for path in Path('/tmp/fresh-probe-option-proof').rglob('*'):
    if path.is_file():
        all_members['revalidation/mutation-proof/' + str(path.relative_to('/tmp/fresh-probe-option-proof'))] = path.read_bytes()
manifest = {name: fingerprint(data) for name, data in sorted(all_members.items())}
manifest_name = 'revalidation/manifest.json'
all_members[manifest_name] = (json.dumps(manifest, indent=2) + '\n').encode()
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, data in sorted(all_members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    members = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
assert members == all_members
assert all(members[name] == data for name, data in original_members.items())
assert all(fingerprint(members[name]) == entry for name, entry in manifest.items())
summary = dict(original_summary)
summary.update({'test_sha256': audit['current_inputs']['tests/scripts/test_check_deliberate_break_probe_option_boundaries.py']['sha256'], 'replay_sha256': audit['current_inputs']['docs/evidence/issue-3743/probe-option-boundaries/replay.py']['sha256'], 'archive_sha256': fingerprint(archive_path.read_bytes())['sha256'], 'archive_bytes': archive_path.stat().st_size, 'archive_manifest': manifest_name, 'archive_member_count': len(all_members), 'historical_proof': {'archive_sha256': original_summary['archive_sha256'], 'archive_bytes': original_summary['archive_bytes'], 'archive_member': 'historical-proof.tar.gz', 'summary_member': 'revalidation/historical-summary.json', 'all_original_members_unchanged': True}, 'current_validation': audit, 'current_evidence_prefix': 'revalidation/'})
(EVIDENCE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Packaged',len(all_members),'members;',len(original_members),'historical members and the original archive preserved byte for byte')
