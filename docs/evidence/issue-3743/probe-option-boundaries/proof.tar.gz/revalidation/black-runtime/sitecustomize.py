"""Keep Black's event loop polling when sandbox thread wakeups are lost."""
import black.concurrency

_original_loop_factory = black.concurrency.maybe_use_uvloop


def _polling_loop():
    loop = _original_loop_factory()

    def poll():
        loop.call_later(0.1, poll)

    loop.call_later(0.1, poll)
    return loop


black.concurrency.maybe_use_uvloop = _polling_loop
