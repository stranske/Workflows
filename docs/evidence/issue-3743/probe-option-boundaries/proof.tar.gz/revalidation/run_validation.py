from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path.cwd()
OUT = Path('/tmp/probe-option-revalidation')

def run(name, argv, env=None):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, env=env)
    (OUT / f'{name}.stdout').write_bytes(result.stdout)
    (OUT / f'{name}.stderr').write_bytes(result.stderr)
    record = {'argv': argv, 'cwd': str(ROOT), 'exit': result.returncode}
    (OUT / f'{name}.command.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name, 'exit', result.returncode, flush=True)
    print(result.stdout.decode()[-3000:], flush=True)
    if result.returncode:
        print(result.stderr.decode()[-3000:], flush=True)
    return result

mode = sys.argv[1]
if mode in {'baseline', 'candidate'}:
    historical = json.loads((OUT / f'historical-{mode}-invocation.json').read_text())
    tests = [item for item in historical['argv'] if item.startswith('tests/')]
    argv = [sys.executable, '-m', 'pytest', *tests, '-q', '-o', 'addopts=', '-m', 'not slow', '--cov',
            '--cov-config=docs/evidence/issue-3743/probe-option-boundaries/coverage.ini', '--cov-branch',
            f'--cov-report=json:{OUT}/{mode}-coverage.json', f'--junitxml={OUT}/{mode}.xml']
    env = os.environ.copy()
    env['COVERAGE_FILE'] = str(OUT / f'.coverage-{mode}')
    result = run(mode, argv, env)
elif mode == 'focused':
    result = run(mode, [sys.executable, '-m', 'pytest', 'tests/scripts/test_check_deliberate_break_probe_option_boundaries.py', '-q', '-o', 'addopts=', '-m', 'not slow', f'--junitxml={OUT}/focused.xml'])
elif mode == 'replay':
    result = run(mode, [sys.executable, 'docs/evidence/issue-3743/probe-option-boundaries/replay.py', '--output', '/tmp/fresh-probe-option-proof'])
else:
    raise ValueError(mode)
raise SystemExit(result.returncode)
