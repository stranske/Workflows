from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
OUT = Path('/tmp/probe-option-revalidation')
EVIDENCE = ROOT / 'docs/evidence/issue-3743/probe-option-boundaries'
HELPERS = ['scripts/check_deliberate_break.py', 'templates/consumer-repo/scripts/check_deliberate_break.py']
TEST = 'tests/scripts/test_check_deliberate_break_probe_option_boundaries.py'
REPLAY = 'docs/evidence/issue-3743/probe-option-boundaries/replay.py'


def fingerprint(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def outcomes(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    assert cases
    records = {}
    for case in cases:
        node = case.get('classname') + '::' + case.get('name')
        assert node not in records
        assert not case.findall('error') and not case.findall('skipped')
        assert not case.findall('failure')
        records[node] = 'passed'
    return records


def audit():
    original_summary = json.loads((OUT / 'historical-summary.json').read_text())
    original_archive = EVIDENCE / 'proof.tar.gz'
    assert fingerprint(original_archive.read_bytes()) == {'sha256': original_summary['archive_sha256'], 'bytes': original_summary['archive_bytes']}
    with tarfile.open(original_archive) as archive:
        members = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
    original_manifest = json.loads(members['manifest.json'])
    assert set(original_manifest) == set(members) - {'manifest.json'}
    assert all(fingerprint(members[name]) == entry for name, entry in original_manifest.items())
    baseline = outcomes(OUT / 'baseline.xml')
    candidate = outcomes(OUT / 'candidate.xml')
    focused = outcomes(OUT / 'focused.xml')
    assert len(baseline) == 322 and len(candidate) == 326 and len(focused) == 4
    assert all(candidate.get(node) == result for node, result in baseline.items())
    new_nodes = sorted(set(candidate) - set(baseline))
    assert new_nodes == sorted(original_summary['new_nodes']) == sorted(focused)
    current_cov = {phase: json.loads((OUT / f'{phase}-coverage.json').read_text()) for phase in ['baseline', 'candidate']}
    historical_cov = {'baseline': json.loads(members['baseline-both-coverage.json']), 'candidate': json.loads(members['candidate-coverage.json'])}
    metrics = {}
    for phase, coverage in current_cov.items():
        assert set(coverage['files']) == set(HELPERS)
        assert sum(file['summary']['num_statements'] for file in coverage['files'].values()) == 1182
        assert sum(file['summary']['num_branches'] for file in coverage['files'].values()) == 524
        assert sum(file['summary']['excluded_lines'] for file in coverage['files'].values()) == 0
        for name, file in coverage['files'].items():
            historical = historical_cov[phase]['files'][name]
            assert set(file['executed_lines']) == set(historical['executed_lines'])
            assert set(map(tuple, file['executed_branches'])) == set(map(tuple, historical['executed_branches']))
    for name in HELPERS:
        before = current_cov['baseline']['files'][name]
        after = current_cov['candidate']['files'][name]
        before_lines, after_lines = set(before['executed_lines']), set(after['executed_lines'])
        before_branches, after_branches = set(map(tuple, before['executed_branches'])), set(map(tuple, after['executed_branches']))
        assert before_lines <= after_lines and before_branches <= after_branches
        metrics[name] = {'baseline': before['summary'], 'candidate': after['summary'], 'new_lines': sorted(after_lines - before_lines), 'new_branches': [list(pair) for pair in sorted(after_branches - before_branches)]}
    assert metrics == original_summary['metrics']
    sources = {name: (ROOT / name).read_bytes() for name in HELPERS}
    assert sources[HELPERS[0]] == sources[HELPERS[1]]
    for name, data in sources.items():
        base = subprocess.run(['git', 'show', original_summary['base'] + ':' + name], check=True, capture_output=True).stdout
        assert data == base
    proof = Path('/tmp/fresh-probe-option-proof')
    replay = json.loads((proof / 'summary.json').read_text())
    assert replay['pair_count'] == 4
    pair_nodes = set()
    for pair in replay['pairs']:
        pair_nodes.add(pair['node'])
        # Case directory names are determined by the named test, without its parameter suffix.
        directory = proof / (('template-' if pair['source'].startswith('templates/') else 'root-') + pair['node'].split('::')[1].split('[')[0])
        original = (directory / 'original.py').read_bytes()
        restored = (directory / 'restored.py').read_bytes()
        mutant = (directory / 'mutant.py').read_bytes()
        assert original == restored == sources[pair['source']] and mutant != original
        assert pair['original_sha256'] == pair['restored_sha256'] == fingerprint(original)['sha256']
        assert pair['mutant_sha256'] == fingerprint(mutant)['sha256']
        for phase, exit_code in [('red', 1), ('green', 0)]:
            record = json.loads((directory / f'{phase}.json').read_text())
            assert record == pair[phase] and record['exit'] == exit_code
            assert record['node'] == pair['node']
            assert 'not slow' in record['argv']
            cases = list(ET.parse(directory / f'{phase}.xml').getroot().iter('testcase'))
            assert len(cases) == 1 and cases[0].get('name') == pair['node'].split('::')[1]
            assert not cases[0].findall('error') and not cases[0].findall('skipped')
            failures = cases[0].findall('failure')
            assert len(failures) == (1 if phase == 'red' else 0)
            if failures:
                assert 'AssertionError' in ''.join(failures[0].itertext())
    assert pair_nodes == {TEST + '::' + node.split('::')[1] for node in new_nodes}
    for relative in [*HELPERS, TEST]:
        assert (proof / 'inputs' / relative).read_bytes() == (ROOT / relative).read_bytes()
    assert (proof / 'inputs/replay.py').read_bytes() == (ROOT / REPLAY).read_bytes()
    reuse = json.loads((OUT / 'reuse-audit.json').read_text())
    assert reuse['files_unchanged'] and reuse['member_count'] == 49
    assert reuse['before'] == reuse['after']
    for name, entry in reuse['before'].items():
        assert fingerprint((proof / name).read_bytes()) == entry
    for name in ['focused', 'baseline', 'candidate', 'replay', 'black', 'ruff', 'template', 'diff']:
        assert json.loads((OUT / f'{name}.command.json').read_text())['exit'] == 0
    assert json.loads((OUT / 'reuse.command.json').read_text())['exit'] == 1
    summary = {'baseline_pass': 322, 'candidate_pass': 326, 'focused_pass': 4, 'new_nodes': new_nodes, 'old_outcomes_unchanged': True, 'coverage_regressions': 0, 'coverage_matches_historical_exact_sets': True, 'metrics': metrics, 'pair_count': 4, 'reuse_refused': True, 'reuse_files_unchanged': 49, 'production_unchanged_from_base': True, 'historical_archive_members_unchanged': len(members), 'current_inputs': {relative: fingerprint((ROOT / relative).read_bytes()) for relative in [*HELPERS, TEST, REPLAY]}, 'runtime': json.loads((OUT / 'runtime.json').read_text()), 'requested_interpreter_available': Path('/opt/anaconda3/bin/python3').exists()}
    (OUT / 'audit-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('Verified 322/326 PASS, four named mutation pairs, exact coverage sets, current input bindings and historical archive members')
    return summary


if __name__ == '__main__':
    audit()
