"""Run Black's normal CLI with a serial scheduler for this sandbox."""

import os

import black
import black.concurrency


def serial(sources, fast, write_back, mode, report, workers, no_cache=False):
    for source in sorted(sources):
        black.reformat_one(
            src=source,
            fast=fast,
            write_back=write_back,
            mode=mode,
            report=report,
            no_cache=no_cache,
        )


os.environ.setdefault("BLACK_CACHE_DIR", "/tmp/launcher-admission-black-cache")
black.concurrency.reformat_many = serial
black.patched_main()
