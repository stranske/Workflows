"""Append raw revalidation, preserving all earlier proof bytes and hashes."""

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path.cwd()
EVIDENCE = ROOT / 'docs/evidence/issue-3743/launcher-admission'
OUT = Path('/tmp/launcher-admission-revalidation-2')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


summary = json.loads((OUT / 'summary.json').read_text())
assert summary['mutation_pairs'] == 4
assert summary['candidate_tests'] - summary['baseline_tests'] == 4
assert not summary['covered_line_regressions'] and not summary['covered_branch_regressions']
write_json(OUT / 'black-exact-command.json', {
    'argv': ['black', '--check', '--line-length', '100', '--exclude', r'(\.workflows-lib|node_modules)', '.'],
    'cwd': str(ROOT), 'exit': 0,
    'env_override': {'BLACK_CACHE_DIR': '/tmp/launcher-admission-black-cache', 'BLACK_NUM_WORKERS': '1'},
})
write_json(OUT / 'commit-environment.json', {
    'checkout_git_writable': False,
    'staging_exit': 128,
    'staging_error': 'Unable to create .git/index.lock: Read-only file system',
    'isolated_git_directory': '/tmp/launcher-admission-commit.git',
})
write_json(OUT / 'requested-interpreter.json', {
    'path': '/opt/anaconda3/bin/python3', 'available': False,
    'exact_acceptance_commands_repeated': False,
    'reason': 'Requested interpreter is absent on this Linux runner.',
})
old_archive = (EVIDENCE / 'proof.tar.gz').read_bytes()
members = {}
with tarfile.open(fileobj=io.BytesIO(old_archive)) as archive:
    for entry in archive.getmembers():
        assert entry.isfile() and entry.name not in members
        members[entry.name] = archive.extractfile(entry).read()
old_manifest = json.loads(subprocess.check_output(['git', 'show', 'HEAD:docs/evidence/issue-3743/launcher-admission/manifest.json']))
assert {name: digest(data) for name, data in members.items()} == old_manifest['proof_members']
for name in ('README.md', 'replay.py', 'summary.json', 'manifest.json'):
    members['revalidation/prior-' + name] = subprocess.check_output(['git', 'show', 'HEAD:docs/evidence/issue-3743/launcher-admission/' + name])
members['revalidation/prior-proof.tar.gz'] = old_archive
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        name = 'revalidation/' + path.relative_to(OUT).as_posix()
        assert name not in members
        members[name] = path.read_bytes()
for name in ('launcher_admission_verify.py', 'launcher_admission_finish.py', 'launcher_serial_black.py', 'launcher_admission_package.py'):
    members['revalidation/tools/' + name] = (Path('/tmp') / name).read_bytes()
summary['prior_archive_sha256'] = digest(old_archive)
summary['prior_raw_members_unchanged'] = len(old_manifest['proof_members'])
summary['requested_interpreter_commands_repeated'] = False
summary['verified_tasks'] = [
    'Four paired root/template missing and opaque launcher cases.',
    'Four assertion RED/byte-identical restored GREEN pairs with source/test hashes; output reuse rejected.',
    'Nine identical existing modules, four new PASS nodes, no outcome or coverage regressions.',
]
summary['validation_commands'] = ['black-exact', 'ruff', 'template-completeness', 'diff-check', 'replay-tests']
summary['black_scheduler'] = 'Serial Black cache population, then required Black CLI with BLACK_NUM_WORKERS=1.'
summary['limits'] = [
    'Coverage is for the root helper; paired template behavior is tested separately.',
    'The specified /opt/anaconda3/bin/python3 interpreter is absent; this run uses the recorded Linux interpreter.',
    'The checkout Git directory is read-only; the new commit and patch are retained in /tmp.',
]
write_json(EVIDENCE / 'summary.json', summary)
with (EVIDENCE / 'proof.tar.gz').open('wb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
files = [
    'tests/scripts/test_check_deliberate_break_launcher_admission.py',
    'tests/scripts/test_launcher_admission_replay.py',
    'scripts/check_deliberate_break.py',
    'templates/consumer-repo/scripts/check_deliberate_break.py',
    *['docs/evidence/issue-3743/launcher-admission/' + name for name in ('README.md', 'replay.py', 'summary.json', 'proof.tar.gz')],
]
write_json(EVIDENCE / 'manifest.json', {
    'files': {name: digest((ROOT / name).read_bytes()) for name in files},
    'proof_members': {name: digest(data) for name, data in sorted(members.items())},
})
with tarfile.open(EVIDENCE / 'proof.tar.gz') as archive:
    assert {entry.name: digest(archive.extractfile(entry).read()) for entry in archive.getmembers()} == {name: digest(data) for name, data in members.items()}
assert all(digest((ROOT / name).read_bytes()) == value for name, value in json.loads((OUT / 'historical-hashes.json').read_text()).items())
print('Packed', len(members), 'raw members; all 35 earlier member hashes and 633 historical files preserved.')
