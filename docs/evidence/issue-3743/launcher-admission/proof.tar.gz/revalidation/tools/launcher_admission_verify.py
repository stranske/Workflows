"""Retain fresh launcher admission verification without replacing historical raw inputs."""

import hashlib
import json
import os
import platform
import subprocess
import sys
import tarfile
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path.cwd()
OUT = Path('/tmp/launcher-admission-revalidation-2')
OUT.mkdir(exist_ok=False)
EVIDENCE = ROOT / 'docs/evidence/issue-3743/launcher-admission'
SOURCE = 'scripts/check_deliberate_break.py'
TEMPLATE = 'templates/consumer-repo/' + SOURCE
NEW = 'tests/scripts/test_check_deliberate_break_launcher_admission.py'
BASE = '71f89d431dc65873db189cb6fcf1a4405422c4c7'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def run(name, argv, overrides=None, expected=0):
    env = os.environ.copy()
    env.update(overrides or {})
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=300)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    write_json(OUT / (name + '-command.json'), {
        'argv': argv, 'cwd': str(ROOT), 'exit': result.returncode,
        'env_override': overrides or {},
    })
    print(name, result.returncode, flush=True)
    if result.returncode != expected:
        print(result.stdout.decode(errors='replace')[-3000:])
        print(result.stderr.decode(errors='replace')[-3000:])
        raise RuntimeError(name)
    return result


tracked = subprocess.check_output(['git', 'ls-files', 'docs/evidence/issue-3743'], text=True).splitlines()
historical = {
    name: digest((ROOT / name).read_bytes()) for name in tracked
    if not name.startswith('docs/evidence/issue-3743/launcher-admission/')
}
write_json(OUT / 'historical-hashes.json', historical)
with tarfile.open(EVIDENCE / 'proof.tar.gz') as archive:
    baseline_command = json.load(archive.extractfile('matched/baseline-command.json'))
modules = baseline_command['argv'][3:12]
assert len(modules) == 9 and all(name.endswith('.py') for name in modules)
inputs = {name: digest((ROOT / name).read_bytes()) for name in [*modules, NEW, SOURCE, TEMPLATE]}
write_json(OUT / 'input-hashes.json', inputs)
for name in [SOURCE, TEMPLATE]:
    assert digest(subprocess.check_output(['git', 'show', f'{BASE}:{name}'])) == inputs[name]
assert inputs[SOURCE] == inputs[TEMPLATE]

run('focused', [sys.executable, '-m', 'pytest', NEW, '-q', '-o', 'addopts=', '-m', 'not slow', f'--junitxml={OUT}/focused.xml'])
run('replay', [sys.executable, str(EVIDENCE / 'replay.py'), '--output', str(OUT / 'mutations')])
proof_files = {str(path.relative_to(OUT)): digest(path.read_bytes()) for path in (OUT / 'mutations').iterdir()}
run('reuse', [sys.executable, str(EVIDENCE / 'replay.py'), '--output', str(OUT / 'mutations')], expected=1)
assert proof_files == {str(path.relative_to(OUT)): digest(path.read_bytes()) for path in (OUT / 'mutations').iterdir()}
write_json(OUT / 'reuse-verification.json', {'unchanged_files': proof_files, 'exit': 1})
rows = json.loads((OUT / 'mutations/receipts.json').read_text())
assert len(rows) == 4
assert all(row['original_sha256'] == row['restored_sha256'] == inputs[SOURCE] for row in rows)
assert all(row['phases'][phase]['test_sha256'] == inputs[NEW] for row in rows for phase in ('red', 'green'))

for phase, files in [('baseline', modules), ('candidate', [*modules, NEW])]:
    run(phase, [sys.executable, '-m', 'pytest', *files, '-q', '-o', 'addopts=', '-m', 'not slow',
                '--cov=scripts.check_deliberate_break', '--cov-branch',
                '--cov-report=term-missing', f'--cov-report=json:{OUT}/{phase}-coverage.json',
                f'--junitxml={OUT}/{phase}.xml'], {'COVERAGE_FILE': str(OUT / (phase + '.coverage'))})


def nodes(phase):
    tree = ElementTree.parse(OUT / (phase + '.xml'))
    result = {}
    for case in tree.iter('testcase'):
        key = case.get('classname') + '::' + case.get('name')
        assert key not in result
        result[key] = next((name for name in ('failure', 'error', 'skipped') if case.find(name) is not None), 'pass')
    return result


before, after = nodes('baseline'), nodes('candidate')
new_nodes = sorted(after.keys() - before.keys())
assert len(new_nodes) == 4 and all(after[node] == 'pass' for node in new_nodes)
assert all(node in after and before[node] == after[node] for node in before)
coverage = {}
for phase in ('baseline', 'candidate'):
    raw = json.loads((OUT / (phase + '-coverage.json')).read_text())
    coverage[phase] = raw['files'][SOURCE]
    totals = coverage[phase]['summary']
    assert (totals['num_statements'], totals['num_branches'], totals['excluded_lines']) == (591, 262, 0)
assert set(coverage['baseline']['executed_lines']) <= set(coverage['candidate']['executed_lines'])
assert set(map(tuple, coverage['baseline']['executed_branches'])) <= set(map(tuple, coverage['candidate']['executed_branches']))
run('replay-tests', [sys.executable, '-m', 'pytest', 'tests/scripts/test_launcher_admission_replay.py', '-q', '-o', 'addopts=', '-m', 'not slow', f'--junitxml={OUT}/replay-tests.xml'])
run('black', [sys.executable, '/tmp/launcher_serial_black.py', '--check', '--line-length', '100', '--exclude', r'(\.workflows-lib|node_modules)', '.'])
run('ruff', ['ruff', 'check', NEW, 'tests/scripts/test_launcher_admission_replay.py', str(EVIDENCE / 'replay.py')])
run('template-completeness', [sys.executable, 'scripts/validate_template_completeness.py', '--strict'])
run('diff-check', ['git', 'diff', '--check'])
assert historical == {name: digest((ROOT / name).read_bytes()) for name in historical}
assert inputs == {name: digest((ROOT / name).read_bytes()) for name in inputs}
write_json(OUT / 'summary.json', {
    'base': BASE,
    'environment': {'interpreter': sys.executable, 'python': sys.version, 'platform': platform.platform()},
    'requested_interpreter_available': Path('/opt/anaconda3/bin/python3').exists(),
    'baseline': coverage['baseline']['summary'], 'candidate': coverage['candidate']['summary'],
    'baseline_tests': len(before), 'candidate_tests': len(after), 'new_nodes': new_nodes,
    'removed_nodes': [], 'changed_old_outcomes': {},
    'covered_line_regressions': [], 'covered_branch_regressions': [],
    'newly_covered_lines': sorted(set(coverage['candidate']['executed_lines']) - set(coverage['baseline']['executed_lines'])),
    'newly_covered_branches': sorted(set(map(tuple, coverage['candidate']['executed_branches'])) - set(map(tuple, coverage['baseline']['executed_branches']))),
    'production_sha256': inputs[SOURCE], 'production_unchanged': True, 'root_template_identical': True,
    'historical_tracked_files': len(historical), 'historical_unchanged': True,
    'mutation_pairs': len(rows), 'reuse_unchanged_files': len(proof_files),
    'black_scheduler': 'serial Black CLI; process/thread scheduler unavailable in sandbox',
    'matched_modules': modules,
})
print(json.dumps(json.loads((OUT / 'summary.json').read_text()), indent=2), flush=True)
