"""Finish validation after routing the Actions summary to a writable path."""

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path.cwd()
OUT = Path("/tmp/launcher-admission-suite-proof")
SOURCE = "scripts/check_deliberate_break.py"
BASE = "71f89d431dc65873db189cb6fcf1a4405422c4c7"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def run(name, argv, overrides=None):
    env = os.environ.copy()
    env.update(overrides or {})
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=60)
    (OUT / (name + ".stdout")).write_bytes(result.stdout)
    (OUT / (name + ".stderr")).write_bytes(result.stderr)
    write_json(
        OUT / (name + "-command.json"),
        {
            "argv": argv,
            "cwd": str(ROOT),
            "exit": result.returncode,
            "env_override": overrides or {},
        },
    )
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    print(name, result.returncode)


run(
    "template-completeness",
    [sys.executable, "scripts/validate_template_completeness.py", "--strict"],
    {"GITHUB_STEP_SUMMARY": str(OUT / "template-step-summary.md")},
)
run("diff-check", ["git", "diff", "--check"])


def nodes(phase):
    result = {}
    for case in ElementTree.parse(OUT / (phase + ".xml")).iter("testcase"):
        key = case.get("classname") + "::" + case.get("name")
        assert key not in result
        result[key] = next(
            (name for name in ("failure", "error", "skipped") if case.find(name) is not None),
            "pass",
        )
    return result


before, after = nodes("baseline"), nodes("candidate")
new_nodes = sorted(after.keys() - before.keys())
assert len(new_nodes) == 4 and all(after[node] == "pass" for node in new_nodes)
assert all(node in after and before[node] == after[node] for node in before)
coverage = {
    phase: json.loads((OUT / (phase + "-coverage.json")).read_text())["files"][SOURCE]
    for phase in ("baseline", "candidate")
}
for data in coverage.values():
    totals = data["summary"]
    assert (totals["num_statements"], totals["num_branches"], totals["excluded_lines"]) == (
        591,
        262,
        0,
    )
assert set(coverage["baseline"]["executed_lines"]) <= set(coverage["candidate"]["executed_lines"])
assert set(map(tuple, coverage["baseline"]["executed_branches"])) <= set(
    map(tuple, coverage["candidate"]["executed_branches"])
)
historical = json.loads((OUT / "historical-hashes.json").read_text())
inputs = json.loads((OUT / "input-hashes.json").read_text())
assert historical == {name: digest((ROOT / name).read_bytes()) for name in historical}
assert inputs == {name: digest((ROOT / name).read_bytes()) for name in inputs}
rows = json.loads((OUT / "mutations/receipts.json").read_text())
assert len(rows) == 4
assert all(row["original_sha256"] == row["restored_sha256"] == inputs[SOURCE] for row in rows)
for name in (
    "focused",
    "replay",
    "baseline",
    "candidate",
    "replay-tests",
    "black",
    "ruff",
    "template-completeness",
    "diff-check",
):
    assert json.loads((OUT / (name + "-command.json")).read_text())["exit"] == 0
modules = json.loads((OUT / "baseline-command.json").read_text())["argv"][3:12]
assert len(modules) == 9
write_json(
    OUT / "summary.json",
    {
        "base": BASE,
        "environment": {
            "interpreter": sys.executable,
            "python": sys.version,
            "platform": platform.platform(),
        },
        "requested_interpreter_available": Path("/opt/anaconda3/bin/python3").exists(),
        "baseline": coverage["baseline"]["summary"],
        "candidate": coverage["candidate"]["summary"],
        "baseline_tests": len(before),
        "candidate_tests": len(after),
        "new_nodes": new_nodes,
        "removed_nodes": [],
        "changed_old_outcomes": {},
        "covered_line_regressions": [],
        "covered_branch_regressions": [],
        "newly_covered_lines": sorted(
            set(coverage["candidate"]["executed_lines"])
            - set(coverage["baseline"]["executed_lines"])
        ),
        "newly_covered_branches": sorted(
            set(map(tuple, coverage["candidate"]["executed_branches"]))
            - set(map(tuple, coverage["baseline"]["executed_branches"]))
        ),
        "production_sha256": inputs[SOURCE],
        "production_unchanged": True,
        "root_template_identical": True,
        "historical_tracked_files": len(historical),
        "historical_unchanged": True,
        "mutation_pairs": len(rows),
        "reuse_unchanged_files": len(
            json.loads((OUT / "reuse-verification.json").read_text())["unchanged_files"]
        ),
        "matched_modules": modules,
        "template_validation_summary_override": str(OUT / "template-step-summary.md"),
    },
)
print(
    "Verified:",
    len(before),
    "to",
    len(after),
    "PASS;",
    len(historical),
    "historical files unchanged.",
)
