"""Append suite validation receipts without changing prior raw proof members."""

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

root = Path.cwd()
evidence = root / "docs/evidence/issue-3743/launcher-admission"
out = Path("/tmp/launcher-admission-suite-proof")


def digest(data):
    return hashlib.sha256(data).hexdigest()


summary = json.loads((out / "summary.json").read_text())
for name in (
    "focused",
    "replay",
    "baseline",
    "candidate",
    "replay-tests",
    "black",
    "black-exact",
    "ruff",
    "template-completeness",
    "diff-check",
):
    assert json.loads((out / (name + "-command.json")).read_text())["exit"] == 0
assert summary["mutation_pairs"] == 4
assert summary["candidate_tests"] - summary["baseline_tests"] == 4
assert not summary["covered_line_regressions"] and not summary["covered_branch_regressions"]
old_archive = (evidence / "proof.tar.gz").read_bytes()
old_manifest = json.loads((evidence / "manifest.json").read_text())
members = {}
with tarfile.open(fileobj=io.BytesIO(old_archive)) as archive:
    for entry in archive.getmembers():
        assert entry.isfile() and entry.name not in members
        members[entry.name] = archive.extractfile(entry).read()
assert {name: digest(data) for name, data in members.items()} == old_manifest["proof_members"]
summary.update(
    {
        "prior_archive_sha256": digest(old_archive),
        "prior_raw_members_unchanged": len(members),
        "requested_interpreter_commands_repeated": False,
        "verified_tasks": json.loads((evidence / "summary.json").read_text())["verified_tasks"],
        "validation_commands": [
            "black-exact",
            "ruff",
            "template-completeness",
            "diff-check",
            "replay-tests",
        ],
        "replay_validation_tests": 27,
        "new_receipt_validation_cases": 18,
        "receipt_regressions_detected_against_previous_validator": 15,
        "pr_body_update_applied": False,
        "pr_body_update_blocker": "MCP tool call requires approval, but approval policy is never",
        "pr_verified_state": "open",
        "pr_verified_isDraft": False,
        "pending_acceptance": "Revised replay with /opt/anaconda3/bin/python3; interpreter absent on this runner.",
        "black_scheduler": "Serial Black cache population, then required Black CLI with BLACK_NUM_WORKERS=1.",
        "limits": [
            "Coverage measures the root helper; paired template behavior is tested separately.",
            "The requested Anaconda interpreter is absent; Linux interpreter recorded in raw receipts.",
            "The checkout Git directory is read-only; an isolated commit and patch are retained in /tmp.",
            "Automatic approval review rejected the live PR-body update; reconciled body is retained for handoff.",
        ],
    }
)
(evidence / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
(out / "summary.json").write_bytes((evidence / "summary.json").read_bytes())
for name in ("README.md", "replay.py", "summary.json", "manifest.json"):
    members["suite-validation/prior-" + name] = subprocess.check_output(
        ["git", "show", "HEAD:docs/evidence/issue-3743/launcher-admission/" + name]
    )
members["suite-validation/prior-proof.tar.gz"] = old_archive
for path in sorted(out.rglob("*")):
    if path.is_file():
        name = "suite-validation/" + path.relative_to(out).as_posix()
        assert name not in members
        members[name] = path.read_bytes()
for path in [
    Path("/tmp/launcher_admission_suite_verify.py"),
    Path("/tmp/launcher_admission_suite_package.py"),
    Path("/tmp/launcher_admission_suite_finish.py"),
    Path("/tmp/launcher_serial_black.py"),
]:
    members["suite-validation/tools/" + path.name] = path.read_bytes()
for name in ("replay.py",):
    members["suite-validation/inputs/" + name] = (evidence / name).read_bytes()
for name in (
    "test_launcher_admission_replay.py",
    "test_check_deliberate_break_launcher_admission.py",
):
    members["suite-validation/inputs/" + name] = (root / "tests/scripts" / name).read_bytes()
with (evidence / "proof.tar.gz").open("wb") as destination:
    with gzip.GzipFile(filename="", mode="wb", fileobj=destination, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
files = list(old_manifest["files"])
manifest = {
    "files": {name: digest((root / name).read_bytes()) for name in files},
    "proof_members": {name: digest(data) for name, data in sorted(members.items())},
}
(evidence / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
with tarfile.open(evidence / "proof.tar.gz") as archive:
    assert {
        entry.name: digest(archive.extractfile(entry).read()) for entry in archive.getmembers()
    } == manifest["proof_members"]
assert all(
    digest((root / name).read_bytes()) == value
    for name, value in json.loads((out / "historical-hashes.json").read_text()).items()
)
print(
    "Packed",
    len(members),
    "raw members; all",
    len(old_manifest["proof_members"]),
    "previous members and 633 historical files preserved.",
)
