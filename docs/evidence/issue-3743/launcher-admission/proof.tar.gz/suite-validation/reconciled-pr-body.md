Missing or opaque pytest launchers must not authorize repair of the active Python runtime. Four root/template tests exercise real PATH lookup and shebang parsing. The private mutation replay now also rejects contradictory JUnit totals, missing counts, extra suites, misplaced outcomes and duplicate failures.

Validation with the recorded Linux interpreter:
- Four launcher cases PASS; four assertion RED exit-1/restored GREEN exit-0 pairs; existing-output reuse preserves all 17 proof files.
- 27 replay tests PASS. The 18 new receipt cases expose 15 failures against the previous validator.
- Matched nine-module baseline 312 PASS, candidate 316 PASS; exactly four new nodes, unchanged old outcomes, no coverage regressions. Root helper: 581 to 583/591 statements and 249 to 251/262 branches, zero exclusions.
- Full-repository Black, focused Ruff, strict template completeness and git diff --check PASS. Production copies and 633 historical evidence files remain unchanged.

Raw inputs and receipts are retained in `docs/evidence/issue-3743/launcher-admission/proof.tar.gz`, including all 112 previous members byte-identically. This is a bounded helper coverage chunk; the broader coverage initiative remains open.

The exact Anaconda command for the revised replay remains pending because `/opt/anaconda3/bin/python3` is absent on this runner. The earlier Anaconda receipts are preserved. Live checkbox reconciliation was rejected by automatic approval review (`never` policy); this body is retained locally for handoff.

<!-- pr-preamble:start -->
<!-- meta:issue:3743 -->
> **Source:** Issue #3743

Closes #3743

<!-- pr-preamble:end -->

<!-- auto-status-summary:start -->
## Automated Status Summary
#### Scope
Continue the broader coverage initiative with the next small chunk selected from fresh last400 scripts-touching commits: check_deliberate_break.py remains first with73 repair-subject matches/82 touches (a proxy, not verified escaped incidents). Current matched helper coverage leaves missing/opaque pytest launcher rejection unexecuted. These boundaries prevent a launcher with no known Python interpreter from authorizing repair of the active PyYAML environment.

<!-- Updated WORKFLOW_OUTPUTS.md context:start -->
## Context for Agent

### Related Issues/PRs
- [stranske/Workflows#3832](https://github.com/stranske/Workflows/issues/3832)
- [#3832](https://github.com/stranske/Workflows/issues/3832)
- [#3743](https://github.com/stranske/Workflows/issues/3743)
- [#948](https://github.com/stranske/Workflows/issues/948)
- [#389](https://github.com/stranske/Workflows/issues/389)
- [#3820](https://github.com/stranske/Workflows/issues/3820)
- [#3814](https://github.com/stranske/Workflows/issues/3814)
- [#3808](https://github.com/stranske/Workflows/issues/3808)
<!-- Updated WORKFLOW_OUTPUTS.md context:end -->

#### Tasks
- [x] Add paired root/template missing and opaque pytest launcher rejection cases using real filesystem/PATH and shebang parsing.
- [x] Run all four cases against their own production return-False-to-True mutation in private copies, then byte-identical restoration; retain complete console, JUnit, argv/cwd/exits and source/test hashes.
- [x] Compare identical nine current helper/replay modules before/after adding only this test file; retain raw coverageJSON/JUnit and prove four new nodes, zero old outcome changes, zero coverage regressions, unchanged production/root-template bytes and historical evidence.

#### Acceptance criteria
- [x] /opt/anaconda3/bin/python3 -m pytest tests/scripts/test_check_deliberate_break_launcher_admission.py -q -o addopts= exits0 with4PASS, proving real missing and opaque launchers do not admit the active runtime. Raw logs/JUnit retained in docs/evidence/issue-3743/launcher-admission/proof.tar.gz.
- [ ] /opt/anaconda3/bin/python3 docs/evidence/issue-3743/launcher-admission/replay.py --output /tmp/new-launcher-admission-proof exits0 after4 assertionREDexit1/restoredGREENexit0 pairs with equal original/restored hashes and no errors/skips. Reusing output fails before mutation and preserves all existing proof files. Raw receipts in the same archive.
- [x] Matched nine-module baseline and candidate with only the new module added have exactly4 new PASS nodes, no removed/changed old outcomes and no line/branch regressions. Preserve591statements/262branches/zeroexclusions, record exact measured counts and new coverage in summary.json with complete raw inputs in the archive.
- [x] Full-repositoryBlack, focusedRuff, template completeness and git diff --check exit0. Production root/template bytes are equal and unchanged from base; historical proof files remain byte-identical. Retain validation logs and hash manifest in the new evidence directory.

<!-- auto-status-summary:end -->

Reconciliation: the two recent commits and all 112 hashed archive members establish the three implementation tasks, the retained Anaconda four-case run, the matched 312/316 comparison, and validation. The exact-interpreter replay criterion remains pending for the revised replay: this Linux runner lacks `/opt/anaconda3/bin/python3`. Its preserved earlier Anaconda receipts remain available.

