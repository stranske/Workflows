"""Keep Black's event loop polling when sandboxed thread wakeups are unavailable."""
import black
import black.concurrency

original_loop_factory = black.concurrency.maybe_use_uvloop


def polling_loop():
    loop = original_loop_factory()

    def tick():
        loop.call_later(0.05, tick)

    loop.call_later(0.05, tick)
    return loop


black.concurrency.maybe_use_uvloop = polling_loop
