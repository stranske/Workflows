"""Retain launch-failure replay controls and a private restoration mutation proof."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(output, name, argv, cwd, expected):
    with (output / f"{name}.log").open("w") as log:
        result = subprocess.run(argv, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    receipt = {"argv": argv, "cwd": str(cwd), "exit": result.returncode}
    (output / f"{name}-command.json").write_text(json.dumps(receipt, indent=2))
    if result.returncode != expected:
        raise ValueError(f"{name}: expected exit {expected}, got {result.returncode}")
    return receipt


def pytest_args(output, name, tests, selection=None):
    argv = [sys.executable, "-m", "pytest", *tests, "-q", "-o", "addopts=", "-m", "not slow"]
    if selection:
        argv.extend(["-k", selection])
    return [*argv, f"--junitxml={output / name}.xml"]


def outcomes(path):
    result = {}
    for case in ElementTree.parse(path).getroot().iter("testcase"):
        key = (case.get("classname"), case.get("name"))
        if key in result:
            raise ValueError(f"duplicate test: {key}")
        result[key] = next(
            (tag for tag in ("error", "failure", "skipped") if case.find(tag) is not None),
            "passed",
        )
    return result


def main():
    root = Path.cwd()
    output = Path(sys.argv[1]).resolve()
    output.mkdir(parents=True, exist_ok=False)
    driver = "docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py"
    target = "tests/scripts/test_uv_resolution_replay_restoration.py"
    boundary = "tests/scripts/test_check_deliberate_break_uv_resolution.py"
    cli = "tests/scripts/test_uv_resolution_replay_cli.py"
    helper = "scripts/check_deliberate_break.py"
    inputs = [driver, target, boundary, cli, helper, "templates/consumer-repo/" + helper]
    identities = {relative: digest((root / relative).read_bytes()) for relative in inputs}
    run(output, "focused", pytest_args(output, "focused", [boundary, cli, target]), root, 0)
    focused = outcomes(output / "focused.xml")
    if len(focused) != 49 or set(focused.values()) != {"passed"}:
        raise ValueError("expected 49 passing focused tests")

    with tempfile.TemporaryDirectory(prefix="uv-launch-validation-") as temporary:
        private = Path(temporary)
        for relative in inputs:
            destination = private / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / relative, destination)
        source = private / driver
        original = source.read_bytes()
        before = b"source.write_bytes(original)"
        if original.count(before) != 1:
            raise ValueError("restoration mutation anchor drift")
        mutated = original.replace(before, b"source.write_bytes(mutated)")
        try:
            source.write_bytes(mutated)
            red = run(
                output,
                "restoration-red",
                pytest_args(output, "restoration-red", [target], "launch-error"),
                private,
                1,
            )
        finally:
            source.write_bytes(original)
        if source.read_bytes() != original:
            raise ValueError("private driver restoration drift")
        green = run(
            output,
            "restoration-green",
            pytest_args(output, "restoration-green", [target], "launch-error"),
            private,
            0,
        )
        red_cases = outcomes(output / "restoration-red.xml")
        green_cases = outcomes(output / "restoration-green.xml")
        if len(red_cases) != 4 or set(red_cases.values()) != {"failure"}:
            raise ValueError("expected four executed RED failures")
        if red_cases.keys() != green_cases.keys() or set(green_cases.values()) != {"passed"}:
            raise ValueError("expected the same four executed GREEN passes")
        proof = {
            "original_sha256": digest(original),
            "mutated_sha256": digest(mutated),
            "restored_sha256": digest(source.read_bytes()),
            "red": red,
            "green": green,
        }
    if identities != {relative: digest((root / relative).read_bytes()) for relative in inputs}:
        raise ValueError("caller input drift")
    (output / "proof.json").write_text(
        json.dumps({"inputs": identities, "focused_passes": 49, "restoration": proof}, indent=2)
    )
    shutil.copy2(__file__, output / Path(__file__).name)
    print("49 focused PASS; four launch-failure controls RED then GREEN; caller bytes unchanged")


if __name__ == "__main__":
    main()
