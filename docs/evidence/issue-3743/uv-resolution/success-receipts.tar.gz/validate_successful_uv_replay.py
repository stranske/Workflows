"""Prove successful replay controls detect private production mutations."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree

DRIVER = "docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py"
TEST = "tests/scripts/test_uv_resolution_replay_restoration.py"
INPUTS = [
    DRIVER,
    TEST,
    "tests/scripts/test_check_deliberate_break_uv_resolution.py",
    "scripts/check_deliberate_break.py",
    "templates/consumer-repo/scripts/check_deliberate_break.py",
]
MUTATIONS = {
    "slow-selector": ('        "-m",\n        "not slow",\n', ""),
    "restoration-hash": (
        '"restored_sha256": digest(source.read_bytes()),',
        '"restored_sha256": digest(mutated),',
    ),
    "receipt-exit": (
        '"exit": process.returncode, "node": node',
        '"exit": process.returncode + 1, "node": node',
    ),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def run(tree, reports, phase):
    node = TEST + "::test_successful_replay_records_all_restored_proofs"
    argv = [
        sys.executable,
        "-m",
        "pytest",
        node,
        "-q",
        "-o",
        "addopts=",
        "-m",
        "not slow",
        f"--junitxml={reports / phase}.xml",
    ]
    with (reports / f"{phase}.log").open("w") as log:
        result = subprocess.run(argv, cwd=tree, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    cases = list(ElementTree.parse(reports / f"{phase}.xml").getroot().iter("testcase"))
    expected = int(phase == "red")
    require(result.returncode == expected, (phase, result.returncode))
    require(len(cases) == 1 and cases[0].get("name") == node.rsplit("::", 1)[-1], "case drift")
    require(cases[0].find("error") is None and cases[0].find("skipped") is None, "invalid result")
    require((cases[0].find("failure") is not None) == bool(expected), "outcome drift")
    receipt = {"argv": argv, "cwd": str(tree), "exit": result.returncode, "node": node}
    (reports / f"{phase}.json").write_text(json.dumps(receipt, indent=2))
    return receipt


def main():
    root = Path.cwd()
    output = Path(sys.argv[1]).resolve()
    output.mkdir(parents=True, exist_ok=False)
    originals = {relative: (root / relative).read_bytes() for relative in INPUTS}
    controls = []
    with tempfile.TemporaryDirectory(prefix="uv-success-controls-") as temporary:
        tree = Path(temporary)
        for relative, original in originals.items():
            destination = tree / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(original)
        source = tree / DRIVER
        original = originals[DRIVER]
        for kind, (before, after) in MUTATIONS.items():
            text = original.decode()
            require(text.count(before) == 1, f"mutation anchor drift: {kind}")
            mutated = text.replace(before, after).encode()
            reports = output / kind
            reports.mkdir()
            try:
                source.write_bytes(mutated)
                red = run(tree, reports, "red")
            finally:
                source.write_bytes(original)
            require(source.read_bytes() == original, "restoration drift")
            green = run(tree, reports, "green")
            controls.append(
                {
                    "mutation": kind,
                    "original_sha256": digest(original),
                    "mutated_sha256": digest(mutated),
                    "restored_sha256": digest(source.read_bytes()),
                    "red": red,
                    "green": green,
                }
            )
    require(
        all((root / name).read_bytes() == data for name, data in originals.items()), "caller drift"
    )
    (output / "controls.json").write_text(
        json.dumps(
            {
                "controls": controls,
                "caller_identity": {name: digest(data) for name, data in originals.items()},
                "scope": "Synthetic pytest results; real replay orchestration and receipt validation",
            },
            indent=2,
        )
    )
    print("3 private driver mutations RED; 3 byte-identical restorations GREEN; caller unchanged")


if __name__ == "__main__":
    main()
