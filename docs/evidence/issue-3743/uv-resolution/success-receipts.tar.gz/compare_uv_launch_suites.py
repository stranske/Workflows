"""Verify matched focused coverage and named outcomes from fresh suite reports."""

import json
import sys
from pathlib import Path
from xml.etree import ElementTree


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def outcomes(path):
    result = {}
    for case in ElementTree.parse(path).getroot().iter("testcase"):
        key = (case.get("classname"), case.get("name"))
        require(key not in result, f"duplicate case: {key}")
        require(all(case.find(tag) is None for tag in ("error", "failure", "skipped")), key)
        result[key] = "passed"
    return result


def main():
    reports = Path(sys.argv[1])
    root = Path.cwd()
    historical = json.loads(
        (root / "docs/evidence/issue-3743/uv-resolution/comparison.json").read_text()
    )
    tests = {phase: outcomes(reports / f"{phase}.xml") for phase in ("baseline", "candidate")}
    require(len(tests["baseline"]) == 300, "expected 300 baseline passes")
    require(len(tests["candidate"]) == 308, "expected 308 candidate passes")
    require(tests["baseline"].keys() <= tests["candidate"].keys(), "old outcome regression")
    added = sorted(tests["candidate"].keys() - tests["baseline"].keys())
    require(added == [tuple(node) for node in historical["added_nodes"]], "added node drift")
    summaries = {}
    coverage = {}
    for phase in ("baseline", "candidate"):
        require(json.loads((reports / f"{phase}-exit.json").read_text()) == {"exit": 0}, phase)
        data = json.loads((reports / f"{phase}.json").read_text())
        require(set(data["files"]) == {"scripts/check_deliberate_break.py"}, "coverage scope")
        coverage[phase] = data["files"]["scripts/check_deliberate_break.py"]
        summaries[phase] = coverage[phase]["summary"]
        for key in (
            "num_statements",
            "num_branches",
            "excluded_lines",
            "covered_lines",
            "covered_branches",
        ):
            require(summaries[phase][key] == historical[phase][key], f"{phase} {key}")
    before, after = coverage["baseline"], coverage["candidate"]
    require(set(before["executed_lines"]) <= set(after["executed_lines"]), "line regression")
    before_arcs = {tuple(arc) for arc in before["executed_branches"]}
    after_arcs = {tuple(arc) for arc in after["executed_branches"]}
    require(before_arcs <= after_arcs, "branch regression")
    require(summaries["candidate"]["percent_covered"] >= 95, "focused coverage below 95%")
    result = {
        "baseline_tests": len(tests["baseline"]),
        "candidate_tests": len(tests["candidate"]),
        "baseline": summaries["baseline"],
        "candidate": summaries["candidate"],
        "added_nodes": added,
        "new_lines": sorted(set(after["executed_lines"]) - set(before["executed_lines"])),
        "new_branches": sorted(after_arcs - before_arcs),
        "old_test_outcome_regressions": [],
        "old_covered_line_regressions": [],
        "old_covered_branch_regressions": [],
        "repository_90_percent": "UNKNOWN; not measured here",
        "merge_authority": False,
    }
    (reports / "verified-comparison.json").write_text(json.dumps(result, indent=2))
    print("300/308 PASS; focused helper 94.84% -> 95.31%; no prior outcome/line/branch regressions")


if __name__ == "__main__":
    main()
