#!/usr/bin/env python
"""Run Black's standard CLI with its standard per-file safety checks sequentially."""

import black
import black.concurrency


def sequential(sources, fast, write_back, mode, report, workers, no_cache=False):
    for source in sorted(sources):
        black.reformat_one(
            src=source,
            fast=fast,
            write_back=write_back,
            mode=mode,
            report=report,
            no_cache=no_cache,
        )


black.concurrency.reformat_many = sequential
black.patched_main()
