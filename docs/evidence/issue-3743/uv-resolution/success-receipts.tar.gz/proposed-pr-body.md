<!-- workflow-source:review_followup -->
Related to #3743; next bounded coverage chunk after independently accepted #3814. Keep the umbrella issue open: repository-wide 90% coverage is UNKNOWN in this focused run.

A failed `uv which` lookup could go untested even when its stdout resembles a valid executable. Eight root/template tests now exercise real subprocesses with nonzero or whitespace-only results at both pytest and shebang-Python lookups, asserting no runnable probe and exact lookup history. Production code and its template copy are unchanged.

### Tasks and acceptance for this chunk
- [x] Add eight named subprocess boundary cases across both checked-in helper copies.
- [x] Prove every new case with a real production guard mutation RED and byte-identical restoration GREEN; retain commands, JUnit and hashes.
- [x] Compare an identical baseline/candidate suite: 300 → 308 PASS, no old outcome/line/branch regressions, unchanged 591 statements / 262 branches / zero exclusions.
- [x] Retain transparent selection ranking and reproducible evidence under docs/evidence/issue-3743/uv-resolution/.
- [x] Whole-tree Black, focused Ruff, template completeness and diff whitespace checks pass.

Validation: focused helper combined coverage 94.84% → 95.31% (two new lines and two new branch arcs). New eight-case module passes; all eight named mutation/restoration pairs pass their RED/GREEN proof. Exact baseline/candidate argv and 61 archive members are indexed with SHA256. Replay: `python3 docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py --output /tmp/uv-resolution-fresh-proof` (fresh path required).

Evidence limitations: selection is a repair-subject history proxy, not a measured escaped-defect count. Tests execute a private uv-shaped executable, not an installed uv distribution. Prior #3814 provider CONCERNS are preserved; independent closer acceptance is recorded separately in selection.json. Broader issue acceptance remains incomplete. Keepalive owns hosted checks/new review findings; closer owns exact-head expected topology, thread/floor/merge and compare gates.


### Acceptance Criteria

- [x] **Tests**
  - [x] Added coverage for failed or blank `uv` lookups in both the root and template checks.
  - [x] Added replay tests for report paths containing spaces, invalid proof results, and restoration after failures or timeouts.
  - [x] Replay checks also verify test outcomes and confirm temporary changes are restored.
- [x] **Documentation**
  - [x] Added test evidence, coverage comparisons, replay instructions, and artifact integrity records.
  - [x] Repository-wide coverage remains unmeasured, and the evidence does not authorize merging or closing the issue.

Reconciliation: reviewed commits b00f3696 through 36a321c8; reran the three focused test modules (49 PASS, `-m "not slow"`); verified seven indexed archives, all 306 member hashes, and ten selected suite input hashes. Evidence: docs/evidence/issue-3743/uv-resolution/README.md. Hosted checks and independent closer gates remain required.

Latest replay validation: added a successful-replay receipt/restoration control; the mutation replay now selects `-m "not slow"`. The three focused modules pass 50 tests. Three private driver mutations are detected RED and pass after byte-identical restoration. New indexed evidence: docs/evidence/issue-3743/uv-resolution/success-receipts-index.json. Publication remains blocked by read-only Git metadata and the standard Black sandbox worker failure.

<!-- This is an auto-generated comment: release notes by coderabbit.ai -->
## Summary by CodeRabbit

* **Tests**
  * Added coverage for failed or blank `uv` lookups in both the root and template checks.
  * Added replay tests for report paths containing spaces, invalid proof results, and restoration after failures or timeouts.
  * Replay checks also verify test outcomes and confirm temporary changes are restored.

* **Documentation**
  * Added test evidence, coverage comparisons, replay instructions, and artifact integrity records.
  * Repository-wide coverage remains unmeasured, and the evidence does not authorize merging or closing the issue.
<!-- end of auto-generated comment: release notes by coderabbit.ai -->
