"""Verify indexed historical artifacts and all eight retained mutation proofs."""

import hashlib
import json
import tarfile
from pathlib import Path
from xml.etree import ElementTree

root = Path('docs/evidence/issue-3743/uv-resolution')
verified = []
for archive, index in [('validation.tar.gz', 'archive-index.json'),
                       ('review-recovery.tar.gz', 'review-recovery-index.json'),
                       ('ci-portability.tar.gz', 'ci-portability-index.json')]:
    receipt = json.loads((root / index).read_text())
    actual = hashlib.sha256((root / archive).read_bytes()).hexdigest()
    if actual != receipt['archive_sha256']:
        raise ValueError(f'archive digest drift: {archive}')
    raw = receipt['members']
    members = raw if isinstance(raw, list) else [
        {'path': name, 'sha256': sha} for name, sha in raw.items()]
    with tarfile.open(root / archive) as packed:
        files = [member for member in packed.getmembers() if member.isfile()]
        if sorted(member.name for member in files) != sorted(member['path'] for member in members):
            raise ValueError(f'member inventory drift: {archive}')
        for expected in members:
            data = packed.extractfile(expected['path']).read()
            if len(data) != expected.get('bytes', len(data)) or hashlib.sha256(data).hexdigest() != expected['sha256']:
                raise ValueError(f'member digest drift: {expected["path"]}')
        if archive == 'validation.tar.gz':
            controls = json.load(packed.extractfile('mutations/controls.json'))['controls']
            if len(controls) != 8:
                raise ValueError('expected eight retained controls')
            seen = set()
            for control in controls:
                copy, kind = control['copy'], control['kind']
                seen.add((copy, kind))
                helper = Path(('templates/consumer-repo/' if copy == 'template' else '') + 'scripts/check_deliberate_break.py')
                sha = hashlib.sha256(helper.read_bytes()).hexdigest()
                if not sha == control['original_sha256'] == control['restored_sha256']:
                    raise ValueError('helper identity drift')
                if control['mutated_sha256'] == sha:
                    raise ValueError('missing production mutation')
                for phase, expected_exit in [('red', 1), ('green', 0)]:
                    command = control[phase]
                    if command['exit'] != expected_exit:
                        raise ValueError('retained command exit drift')
                    xml = packed.extractfile(f'mutations/{copy}-{kind}/{phase}.xml').read()
                    cases = list(ElementTree.fromstring(xml).iter('testcase'))
                    if len(cases) != 1 or cases[0].get('name') != command['node'].rsplit('::', 1)[-1]:
                        raise ValueError('retained test identity drift')
                    case = cases[0]
                    if case.find('error') is not None or case.find('skipped') is not None:
                        raise ValueError('retained proof did not execute')
                    if (case.find('failure') is not None) != (phase == 'red'):
                        raise ValueError('retained proof outcome drift')
            if seen != {(copy, kind) for copy in ('root', 'template') for kind in
                        ('pytest-nonzero', 'pytest-empty', 'python-nonzero', 'python-empty')}:
                raise ValueError('retained control inventory drift')
    verified.append({'archive': archive, 'sha256': actual, 'members': len(files)})
Path('/tmp/uv-restoration-validation-final/historical-integrity.json').write_text(
    json.dumps({'archives': verified, 'retained_controls': 8, 'helper_bytes_unchanged': True}, indent=2))
print('3 archive digests / 125 member records PASS; eight retained RED/GREEN proofs PASS; helper identities unchanged')
