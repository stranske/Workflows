import hashlib
import json
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

root = Path.cwd()
driver = root / 'docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py'
output = Path('/tmp/uv-restoration-validation-final')
output.mkdir(exist_ok=False)
original = driver.read_bytes()
before = b'                    source.write_bytes(original)'
after = b'                    source.write_bytes(mutated)'
if original.count(before) != 1:
    raise ValueError('restoration anchor drift')
mutated = original.replace(before, after)

def run(phase):
    xml = output / f'{phase}.xml'
    argv = [sys.executable, '-m', 'pytest',
            'tests/scripts/test_uv_resolution_replay_restoration.py', '-q',
            '-o', 'addopts=', '-m', 'not slow', f'--junitxml={xml}']
    with (output / f'{phase}.log').open('w') as log:
        process = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    (output / f'{phase}-command.json').write_text(json.dumps(
        {'argv': argv, 'cwd': str(root), 'exit': process.returncode}, indent=2))
    cases = list(ElementTree.parse(xml).getroot().iter('testcase'))
    expected = 1 if phase == 'red' else 0
    if process.returncode != expected or len(cases) != 8:
        raise ValueError((phase, process.returncode, len(cases)))
    for case in cases:
        if case.find('error') is not None or case.find('skipped') is not None:
            raise ValueError('non-executed control')
        if (case.find('failure') is not None) != (phase == 'red'):
            raise ValueError('unexpected outcome')
    return [case.get('name') for case in cases]

try:
    driver.write_bytes(mutated)
    red = run('red')
finally:
    driver.write_bytes(original)
if driver.read_bytes() != original:
    raise ValueError('driver restoration drift')
green = run('green')
if red != green:
    raise ValueError('control identity drift')
sha = lambda data: hashlib.sha256(data).hexdigest()
(output / 'restoration.json').write_text(json.dumps({
    'original_sha256': sha(original), 'mutated_sha256': sha(mutated),
    'restored_sha256': sha(driver.read_bytes()), 'nodes': red,
    'test_sha256': sha((root / 'tests/scripts/test_uv_resolution_replay_restoration.py').read_bytes()),
    'validation_driver_sha256': sha(Path(__file__).read_bytes())
}, indent=2))
print('8 executed failures RED; 8 passes GREEN; replay driver restored byte-for-byte')
