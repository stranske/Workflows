"""Verify a fresh matched suite against the checked-in bounded coverage evidence."""

import json
import sys
from pathlib import Path
from xml.etree import ElementTree

evidence = Path('docs/evidence/issue-3743/uv-resolution')
historical = json.loads((evidence / 'comparison.json').read_text())
output = Path(sys.argv[1])

def outcomes(phase):
    if json.loads((output / f'{phase}-exit.json').read_text()) != {'exit': 0}:
        raise ValueError(f'{phase} failed')
    cases = list(ElementTree.parse(output / f'{phase}.xml').getroot().iter('testcase'))
    nodes = [(case.get('classname'), case.get('name')) for case in cases]
    if len(nodes) != len(set(nodes)):
        raise ValueError(f'{phase} contains duplicate nodes')
    if any(list(case) for case in cases):
        raise ValueError(f'{phase} contains non-passing outcomes')
    return set(nodes)

baseline, candidate = outcomes('baseline'), outcomes('candidate')
added = sorted(candidate - baseline)
if len(baseline) != 300 or len(candidate) != 308 or baseline - candidate:
    raise ValueError('outcome inventory regression')
if added != [tuple(node) for node in historical['added_nodes']]:
    raise ValueError('new-node identity drift')
coverage = {}
for phase in ('baseline', 'candidate'):
    report = json.loads((output / f'{phase}.json').read_text())
    module = report['files']['scripts/check_deliberate_break.py']
    summary = module['summary']
    for field, expected in historical[phase].items():
        if summary[field] != expected:
            raise ValueError((phase, field, summary[field], expected))
    coverage[phase] = module
old, new = coverage['baseline'], coverage['candidate']
if set(old['executed_lines']) - set(new['executed_lines']):
    raise ValueError('covered line regression')
if {tuple(arc) for arc in old['executed_branches']} - {tuple(arc) for arc in new['executed_branches']}:
    raise ValueError('covered branch regression')
if new['summary']['percent_covered'] < 95:
    raise ValueError('focused coverage below 95%')
result = {
    'baseline_tests': len(baseline), 'candidate_tests': len(candidate),
    'added_nodes': added, 'baseline': old['summary'], 'candidate': new['summary'],
    'old_test_outcome_regressions': [], 'old_covered_line_regressions': [],
    'old_covered_branch_regressions': [], 'repository_coverage': 'UNKNOWN; not measured',
}
(output / 'verified-comparison.json').write_text(json.dumps(result, indent=2))
print('300/308 PASS; unchanged 591 statements / 262 branches / zero exclusions;')
print(f"focused helper coverage {old['summary']['percent_covered']:.2f}% -> {new['summary']['percent_covered']:.2f}%; no regressions")
