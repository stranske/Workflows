"""Mutate individual GREEN proof guards in a private copy; never edit caller bytes."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path.cwd()
OUTPUT = Path(sys.argv[1]).resolve()
OUTPUT.mkdir(parents=True, exist_ok=False)
TEST = "tests/scripts/test_uv_resolution_replay_cli.py"
DRIVER = "docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py"
GUARDS = {
    "exit": "process.returncode == expected",
    "error": 'not list(cases[0].iter("error"))',
    "skip": 'not list(cases[0].iter("skipped"))',
    "identity": 'cases[0].get("name") == node.rsplit("::", 1)[-1]',
    "unexpected-failure": 'bool(list(cases[0].iter("failure"))) is (phase == "red")',
    "case-count": "len(cases) == 1",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


originals = {path: (ROOT / path).read_bytes() for path in (TEST, DRIVER)}
controls = []
with tempfile.TemporaryDirectory(prefix="uv-green-guards-") as temporary:
    tree = Path(temporary)
    for relative in originals:
        target = tree / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    source = tree / DRIVER
    original = originals[DRIVER]
    for kind, guard in GUARDS.items():
        before = "require(" + guard + ","
        text = original.decode()
        if text.count(before) != 1:
            raise ValueError(("guard anchor drift", kind))
        mutated = text.replace(before, "require(True,").encode()
        node = f"{TEST}::test_optimized_green_replay_rejects_invalid_proof[{kind}]"
        results = {}
        try:
            source.write_bytes(mutated)
            for phase, code in [("red", 1), ("green", 0)]:
                if phase == "green":
                    source.write_bytes(original)
                prefix = OUTPUT / f"{kind}-{phase}"
                argv = [
                    sys.executable,
                    "-m",
                    "pytest",
                    node,
                    "-q",
                    "-o",
                    "addopts=",
                    "-m",
                    "not slow",
                    f"--junitxml={prefix}.xml",
                ]
                with prefix.with_suffix(".log").open("w") as log:
                    result = subprocess.run(
                        argv, cwd=tree, stdout=log, stderr=subprocess.STDOUT, timeout=60
                    )
                cases = list(
                    ElementTree.parse(prefix.with_suffix(".xml")).getroot().iter("testcase")
                )
                if result.returncode != code or len(cases) != 1:
                    raise ValueError((kind, phase, "exit or case count"))
                case = cases[0]
                if case.get("name") != node.rsplit("::", 1)[-1]:
                    raise ValueError((kind, phase, "wrong case"))
                if list(case.iter("error")) or list(case.iter("skipped")):
                    raise ValueError((kind, phase, "error or skip"))
                if bool(list(case.iter("failure"))) != (phase == "red"):
                    raise ValueError((kind, phase, "wrong outcome"))
                receipt = {"argv": argv, "cwd": str(tree), "exit": result.returncode}
                prefix.with_suffix(".json").write_text(json.dumps(receipt, indent=2))
                results[phase] = receipt
        finally:
            source.write_bytes(original)
        if source.read_bytes() != original:
            raise ValueError((kind, "restoration drift"))
        controls.append(
            {
                "kind": kind,
                "original_sha256": digest(original),
                "mutated_sha256": digest(mutated),
                "restored_sha256": digest(source.read_bytes()),
                **results,
            }
        )
if any((ROOT / path).read_bytes() != data for path, data in originals.items()):
    raise ValueError("caller bytes changed")
(OUTPUT / "controls.json").write_text(
    json.dumps(
        {
            "caller_identity": {path: digest(data) for path, data in originals.items()},
            "controls": controls,
        },
        indent=2,
    )
)
print("6 individual GREEN proof guard mutations: RED1 / restored GREEN0; caller bytes unchanged")
