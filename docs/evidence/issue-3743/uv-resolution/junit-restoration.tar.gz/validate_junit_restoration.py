"""Run private production-guard mutations; preserve caller source bytes."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET

root = Path.cwd()
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=False)
driver = 'docs/evidence/issue-3743/uv-resolution/replay_uv_resolution.py'
test = 'tests/scripts/test_uv_resolution_replay_restoration.py'
inputs = [driver, test, 'tests/scripts/test_check_deliberate_break_uv_resolution.py',
          'scripts/check_deliberate_break.py',
          'templates/consumer-repo/scripts/check_deliberate_break.py']
identity = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs}
mutations = [
    ('restoration', 'source.write_bytes(original)', 'source.write_bytes(mutated)', '', 16),
    ('outcome', 'require(bool(list(cases[0].iter("failure"))) is (phase == "red"), (node, phase))',
     'require(True, (node, phase))', 'outcome', 4),
    ('identity', 'require(cases[0].get("name") == node.rsplit("::", 1)[-1], (node, phase, "wrong case"))',
     'require(True, (node, phase, "wrong case"))', 'identity', 4),
]
receipts = []
with tempfile.TemporaryDirectory(prefix='uv-junit-controls-') as temporary:
    tree = Path(temporary)
    for name in inputs:
        target = tree / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, target)
    source = tree / driver
    original = source.read_bytes()
    for kind, before, after, selection, count in mutations:
        text = original.decode()
        assert text.count(before) == 1
        mutant = text.replace(before, after).encode()
        for phase in ['red', 'green']:
            if phase == 'red':
                source.write_bytes(mutant)
            else:
                source.write_bytes(original)
            argv = [sys.executable, '-m', 'pytest',
                    test + '::test_junit_rejection_restores_private_helpers',
                    '-q', '-o', 'addopts=', '-m', 'not slow',
                    '--junitxml=' + str(output / f'{kind}-{phase}.xml')]
            if selection:
                argv += ['-k', selection]
            try:
                with (output / f'{kind}-{phase}.log').open('w') as log:
                    result = subprocess.run(argv, cwd=tree, stdout=log,
                                            stderr=subprocess.STDOUT, timeout=60)
            finally:
                source.write_bytes(original)
            cases = list(ET.parse(output / f'{kind}-{phase}.xml').getroot().iter('testcase'))
            assert result.returncode == int(phase == 'red')
            assert len(cases) == count
            assert all(bool(list(case.iter('failure'))) == (phase == 'red') for case in cases)
            assert all(not list(case.iter('error')) and not list(case.iter('skipped')) for case in cases)
            assert source.read_bytes() == original
            receipt = {'argv': argv, 'cwd': str(tree), 'exit': result.returncode,
                       'kind': kind, 'phase': phase, 'cases': count,
                       'original_sha256': hashlib.sha256(original).hexdigest(),
                       'mutated_sha256': hashlib.sha256(mutant).hexdigest(),
                       'restored_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
            (output / f'{kind}-{phase}.json').write_text(json.dumps(receipt, indent=2))
            receipts.append(receipt)
            print(kind, phase, count, 'cases', flush=True)
assert identity == {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs}
(output / 'controls.json').write_text(json.dumps({'caller_identity': identity, 'controls': receipts}, indent=2))
