import ast
import json
import os
import runpy
import subprocess
import sys
from pathlib import Path

import pytest
import scripts.check_deliberate_break as deliberate_break
from scripts.check_deliberate_break import (
    PYTEST_RUNTIME_DEPENDENCIES,
    VERDICT_BROKEN,
    VERDICT_HOLLOW,
    VERDICT_PASS,
    _extract_fallback_test_name,
    parse_deliberate_break_spec,
    verify_spec,
)


def _run(repo: Path, *args: str) -> None:
    subprocess.run(args, cwd=repo, check=True, text=True, capture_output=True)


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_named_pytest_command_ignores_suite_wide_addopts(tmp_path, prefix) -> None:
    root = Path(__file__).resolve().parents[2]
    helper = runpy.run_path(str(root / prefix / "scripts/check_deliberate_break.py"))
    (tmp_path / "pytest.ini").write_text(
        "[pytest]\naddopts = --suite-only-plugin-option\n", encoding="utf-8"
    )
    (tmp_path / "test_named.py").write_text(
        "def test_named():\n    assert True\n", encoding="utf-8"
    )
    command = helper["_pytest_command"]("test_named.py::test_named")
    result = subprocess.run(command, cwd=tmp_path, capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "1 passed" in result.stdout


def test_explicit_deliberate_break_command_preserves_author_options() -> None:
    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py break-file=app.py "
        'command="python -m pytest tests/test_app.py::test_value --maxfail=1" -->'
    )
    assert spec is not None
    assert spec.command[-1] == "--maxfail=1"
    assert "addopts=" not in spec.command


def _init_repo(repo: Path) -> None:
    _run(repo, "git", "init", "-q")
    _run(repo, "git", "config", "user.email", "test@example.com")
    _run(repo, "git", "config", "user.name", "Test User")


def _commit(repo: Path, message: str) -> str:
    _run(repo, "git", "add", ".")
    _run(repo, "git", "commit", "-qm", message)
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        text=True,
    ).strip()


def _write_app(repo: Path, value: int) -> None:
    (repo / "app.py").write_text(
        f"def value():\n    return {value}\n",
        encoding="utf-8",
    )


def _write_test(repo: Path, expected: int) -> None:
    test_file = repo / "tests" / "test_app.py"
    test_file.parent.mkdir(exist_ok=True)
    test_file.write_text(
        f"import app\n\n\ndef test_value():\n    assert app.value() == {expected}\n",
        encoding="utf-8",
    )


def test_hollow_detected(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 1)
    base = _commit(repo, "base behavior")
    _write_test(repo, 1)
    _commit(repo, "candidate test")
    monkeypatch.chdir(repo)

    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    result = verify_spec(spec, base=base, enforce_tamper=False)

    assert result["verdict"] == VERDICT_HOLLOW


def test_sound_passes(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    base = _commit(repo, "base behavior")
    _write_app(repo, 1)
    _write_test(repo, 1)
    _commit(repo, "implementation and test")
    monkeypatch.chdir(repo)

    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    result = verify_spec(spec, base=base, enforce_tamper=False)

    assert result["verdict"] == VERDICT_PASS


def test_no_marker_returns_none() -> None:
    assert parse_deliberate_break_spec("## Acceptance Criteria\n- [ ] normal check") is None


def test_prose_deliberate_break_colon_is_not_incomplete_marker() -> None:
    """Checklist prose with 'Deliberate-break:' must not raise or false-match."""
    assert (
        parse_deliberate_break_spec(
            "## Test plan\n"
            "- [x] Deliberate-break: revert the `[403, 404]` branch → "
            "tests/assertions fail → restore\n"
        )
        is None
    )


def test_incomplete_key_value_marker_still_raises() -> None:
    with pytest.raises(ValueError, match="requires test, test-file, and break-file"):
        parse_deliberate_break_spec("<!-- deliberate-break: test=tests/test_app.py::test_value -->")


def test_issue_acceptance_wording_is_supported() -> None:
    spec = parse_deliberate_break_spec(
        "## Acceptance Criteria\n\n"
        "- [ ] Named test: add `tests/scripts/test_check_deliberate_break.py` "
        "with `test_hollow_detected` (build a tmp git repo).\n"
        "- [ ] **Deliberate-break gate:** temporarily edit "
        "`scripts/check_deliberate_break.py` to skip the base-rerun.\n"
    )

    assert spec is not None
    assert spec.test_id == "tests/scripts/test_check_deliberate_break.py::test_hollow_detected"
    assert spec.test_file == "tests/scripts/test_check_deliberate_break.py"
    assert spec.break_file == "scripts/check_deliberate_break.py"


def test_issue_acceptance_named_test_precedes_harness_description() -> None:
    spec = parse_deliberate_break_spec(
        "## Acceptance Criteria\n\n"
        "- [ ] **Named test:** a new `test_virtual_poll_budget` in "
        "`tests/workflows/test_keepalive_post_work.py`, running the scenario "
        "with the harness's fake clock.\n"
        "- [ ] **Deliberate-break → revert:** restore the wall-clock form in "
        "` .github/scripts/keepalive_post_work.js`.\n"
    )

    assert spec is not None
    assert spec.test_id == "tests/workflows/test_keepalive_post_work.py::test_virtual_poll_budget"


def test_fallback_ignores_english_with_a_phrase() -> None:
    """Do not treat 'with a …' as a pytest node id (Gate false FAIL_BROKEN)."""
    spec = parse_deliberate_break_spec(
        "## Acceptance Criteria\n"
        "- [x] Named test: `tests/workflows/test_issue_bridge_seed.py`, "
        "asserts (a) run-unique token and (b) ahead-of-base guard with a "
        "non-crashing report branch.\n"
        "- [x] Deliberate-break → revert: restore constant marker in "
        "`.github/workflows/reusable-agents-issue-bridge.yml`.\n"
    )
    assert spec is None


def test_fallback_test_name_parser_rejects_near_misses_and_accepts_valid_tokens() -> None:
    """Quoted, unquoted, and malformed named-test prose must parse predictably."""
    reject_cases = [
        "Named test: `tests/test_app.py`, guard with a non-crashing branch.",
        "Named test: `tests/test_app.py` with the harness's fake clock.",
    ]
    for named_line in reject_cases:
        assert _extract_fallback_test_name(named_line) is None

    assert (
        _extract_fallback_test_name("Named test: `tests/test_app.py` with `test_widget`.")
        == "test_widget"
    )
    assert (
        _extract_fallback_test_name("Named test: run `tests/test_app.py` with test_widget.")
        == "test_widget"
    )
    assert (
        _extract_fallback_test_name("Named test: add `tests/test_app.py` with `test_widget`.")
        == "test_widget"
    )


def test_unquoted_fallback_test_name_treats_hyphen_as_boundary() -> None:
    """A literal '_A-Za-z0-9' membership check misread '-' as identifier continuation."""
    assert (
        _extract_fallback_test_name("Named test: run `tests/test_app.py` with test_widget-extra.")
        == "test_widget"
    )
    assert (
        _extract_fallback_test_name("Named test: run `tests/test_app.py` with test_widget7.")
        == "test_widget7"
    )
    assert (
        _extract_fallback_test_name("Named test: run `tests/test_app.py` with test_widget\u00e9.")
        == "test_widget"
    )


def _load_consumer_deliberate_break_helpers() -> dict[str, object]:
    consumer_path = (
        Path(__file__).resolve().parents[2]
        / "templates/consumer-repo/scripts/check_deliberate_break.py"
    )
    consumer_source = consumer_path.read_text(encoding="utf-8")
    namespace: dict[str, object] = {"re": __import__("re")}
    extract_start = consumer_source.index("def _extract_fallback_test_name")
    extract_end = consumer_source.index("\ndef _fallback_marker", extract_start)
    exec(consumer_source[extract_start:extract_end], namespace, namespace)
    infer_start = consumer_source.index("def _infer_break_file")
    infer_end = consumer_source.index("\ndef parse_deliberate_break_spec", infer_start)
    exec(consumer_source[infer_start:infer_end], namespace, namespace)
    return namespace


def test_consumer_template_fallback_test_name_matches_main_parser() -> None:
    consumer_extract = _load_consumer_deliberate_break_helpers()["_extract_fallback_test_name"]

    for sample in (
        "Named test: `tests/test_app.py` with test_widget.",
        "Named test: run `tests/test_app.py` with test_widget-extra.",
        "Named test: run `tests/test_app.py` with test_widget7.",
        "Named test: `tests/test_app.py` with `test_widget`.",
    ):
        assert consumer_extract(sample) == _extract_fallback_test_name(sample)


def test_consumer_template_infer_break_file_prefers_workflow_path() -> None:
    consumer_infer = _load_consumer_deliberate_break_helpers()["_infer_break_file"]

    assert (
        consumer_infer(
            break_line="- [ ] Deliberate break: temporarily break the named test.",
            named_line="- [ ] Named test: add `tests/test_widget.py` with `test_widget`.",
            markdown="## Scope\n- [ ] Update `.github/workflows/ci.yml`.\n",
        )
        == ".github/workflows/ci.yml"
    )

    assert (
        consumer_infer(
            break_line="- [ ] Deliberate break: prove the named test fails.",
            named_line="- [ ] Named test: add `tests/test_widget.py` with `test_widget`.",
            markdown=(
                "## Scope\n"
                "- [ ] Touch `config/app.yaml`.\n"
                "- [ ] Update `.github/workflows/reusable-ci.yml`.\n"
            ),
        )
        == ".github/workflows/reusable-ci.yml"
    )


def test_explicit_marker_outside_acceptance_section_is_honored() -> None:
    """Markers outside auto-status AC text must still drive deliberate-break."""
    spec = parse_deliberate_break_spec(
        "## Acceptance Criteria\n"
        "- Named test: `tests/workflows/test_issue_bridge_seed.py` with prose.\n"
        "- Deliberate-break → revert: restore constant marker.\n\n"
        "## Additional context\n"
        "<!-- deliberate-break: "
        "test=tests/workflows/test_issue_bridge_seed.py::"
        "TestIssueBridgeSeed::test_mk_step_marker_includes_run_unique_token "
        "test-file=tests/workflows/test_issue_bridge_seed.py "
        "break-file=.github/workflows/reusable-agents-issue-bridge.yml -->\n"
    )
    assert spec is not None
    assert (
        spec.test_id
        == "tests/workflows/test_issue_bridge_seed.py::TestIssueBridgeSeed::test_mk_step_marker_includes_run_unique_token"
    )


def test_issue_3007_acceptance_wording_is_supported() -> None:
    spec = parse_deliberate_break_spec(
        "## Tasks\n\n"
        "- [ ] `.github/workflows/maint-69-sync-labels.yml:24-25` — add `issues: write`.\n"
        "## Acceptance Criteria\n\n"
        "- [ ] Named test: extend `.github/scripts/__tests__/label_rules_assert_test.py` "
        "with a test `test_label_sync_fails_when_any_label_write_errors` that drives the "
        "aggregation/exit path.\n"
        "- [ ] Deliberate-break → revert: revert the `permissions:` change to "
        "`contents: read` only and dispatch against a single consumer repo.\n"
    )

    assert spec is not None
    assert (
        spec.test_id
        == ".github/scripts/__tests__/label_rules_assert_test.py::test_label_sync_fails_when_any_label_write_errors"
    )
    assert spec.test_file == ".github/scripts/__tests__/label_rules_assert_test.py"
    assert spec.break_file == ".github/workflows/maint-69-sync-labels.yml"


def test_break_line_target_beats_unrelated_workflow_path() -> None:
    spec = parse_deliberate_break_spec(
        "## Scope\n- [ ] Update `.github/workflows/ci.yml`.\n\n"
        "## Acceptance Criteria\n"
        "- [ ] Named test: add `tests/test_widget.py` with `test_widget`.\n"
        "- [ ] Deliberate break: temporarily revert `src/widget.py`.\n"
    )
    assert spec is not None
    assert spec.break_file == "src/widget.py"


def test_break_line_prefers_the_path_named_after_reverting() -> None:
    spec = parse_deliberate_break_spec(
        "## Acceptance Criteria\n"
        "- [ ] Named test: add `tests/test_widget.py` with `test_widget`.\n"
        "- [ ] Deliberate break: run `tests/test_widget.py` after reverting "
        "`.github/workflows/ci.yml`.\n"
    )
    assert spec is not None
    assert spec.break_file == ".github/workflows/ci.yml"


def test_fallback_marker_ignores_backticked_curl_command_and_keeps_trailing_colon_path() -> None:
    spec = parse_deliberate_break_spec("""## Acceptance Criteria
- [ ] Deliberate break: change `src/example.py:` and prove the named test fails.
- [ ] Named test: run `tests/test_example.py` with `test_example`.
- [ ] Verify with `curl https://example.test/health`.
""")

    assert spec is not None
    assert spec.break_file == "src/example.py"

    curl_only = parse_deliberate_break_spec("""## Acceptance Criteria
- [ ] Deliberate break: change `curl https://example.test/health` and prove the named test fails.
- [ ] Named test: run `tests/test_example.py` with `test_example`.
""")

    assert curl_only is None or curl_only.break_file != "curl https://example.test/health"


def test_fallback_marker_accepts_root_level_line_range_path() -> None:
    spec = parse_deliberate_break_spec("""## Acceptance Criteria
- [ ] Deliberate break: change `app.py:24-25` and prove the named test fails.
- [ ] Named test: run `tests/test_app.py` with `test_app`.
""")

    assert spec is not None
    assert spec.break_file == "app.py"


def test_assertion_replacement_removal_is_detected() -> None:
    old = "assert validate_store(without_page).valid  # validator allows document-only citations"
    new = "assert not validate_store(without_page).valid"
    diff = f"@@ -1 +1 @@\n-        {old}\n+        {new}\n"

    assert list(deliberate_break._assertion_diff_lines(diff)) == [f"-        {old}"]
    other_hunk = f"@@ -1 +0 @@\n-        {old}\n@@ -9 +9 @@\n+        {new}\n"
    assert list(deliberate_break._assertion_diff_lines(other_hunk)) == [f"-        {old}"]
    extra_removal = diff + "@@ -12 +0 @@\n-        assert unrelated_condition\n"
    assert list(deliberate_break._assertion_diff_lines(extra_removal)) == [
        f"-        {old}",
        "-        assert unrelated_condition",
    ]
    duplicate_removal = f"@@ -1,2 +1 @@\n-        {old}\n-        {old}\n+        {new}\n"
    assert list(deliberate_break._assertion_diff_lines(duplicate_removal)) == [
        f"-        {old}",
        f"-        {old}",
    ]


def test_pr_body_issue_marker_cannot_exempt_removed_assertion(monkeypatch, tmp_path) -> None:
    old = "assert validate_store(without_page).valid  # validator allows document-only citations"
    new = "assert not validate_store(without_page).valid"
    test_file = "tests/store/test_communication_render_profile.py"
    diff = f"@@ -1 +1 @@\n-        {old}\n+        {new}\n"

    def fake_git(args, _cwd):
        output = f"M\t{test_file}\n" if "--name-status" in args else diff
        return subprocess.CompletedProcess(args, 0, output, "")

    monkeypatch.setattr(deliberate_break, "_git", fake_git)
    monkeypatch.setenv("GITHUB_REPOSITORY", "stranske/Deliverable-Render")
    monkeypatch.setenv("PR_BODY", "<!-- meta:issue:36 -->")
    assert deliberate_break._changed_assertions("base", "HEAD", test_file, tmp_path) == [
        f"-        {old}"
    ]
    monkeypatch.setenv("PR_BODY", "<!-- meta:issue:35 -->")
    assert deliberate_break._changed_assertions(
        "base", "HEAD", test_file, tmp_path, "<!-- meta:issue:36 -->"
    ) == [f"-        {old}"]
    assert deliberate_break._changed_assertions(
        "base", "HEAD", test_file, tmp_path, pr_body="<!-- meta:issue:36 -->"
    ) == [f"-        {old}"]

    monkeypatch.setenv("PR_BODY", "<!-- meta:issue:35 -->")
    assert deliberate_break._changed_assertions("base", "HEAD", test_file, tmp_path) == [
        f"-        {old}"
    ]
    monkeypatch.setenv("PR_BODY", "<!-- meta:issue:36 -->")
    monkeypatch.setenv("GITHUB_REPOSITORY", "stranske/Other")
    assert deliberate_break._changed_assertions("base", "HEAD", test_file, tmp_path) == [
        f"-        {old}"
    ]


def test_assertion_tamper_is_flagged(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    _write_test(repo, 0)
    base = _commit(repo, "base test")
    _write_app(repo, 1)
    _write_test(repo, 1)
    _commit(repo, "tampered candidate")
    monkeypatch.chdir(repo)

    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    result = verify_spec(spec, base=base)

    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "test-assertion-tamper"


def test_tamper_git_failure_is_broken(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    _write_test(repo, 0)
    base = _commit(repo, "base test")
    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    def fail_tamper_check(*_args, **_kwargs):
        raise subprocess.CalledProcessError(
            128,
            ["git", "diff", f"{base}...HEAD"],
            output="",
            stderr="bad revision",
        )

    monkeypatch.setattr(deliberate_break, "_changed_assertions", fail_tamper_check)

    result = verify_spec(spec, base=base, cwd=repo)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "tamper-check-failed",
        "command": ["git", "diff", f"{base}...HEAD"],
        "returncode": 128,
        "stdout": "",
        "stderr": "bad revision",
    }


def test_tamper_os_error_is_broken(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    monkeypatch.setattr(
        deliberate_break,
        "_changed_assertions",
        lambda *_args: (_ for _ in ()).throw(FileNotFoundError("git unavailable")),
    )

    result = verify_spec(spec, base=base, cwd=repo)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "tamper-check-unavailable",
        "detail": "git unavailable",
    }


def test_tamper_timeout_has_distinct_reason(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    command = ["git", "diff", f"{base}...HEAD"]
    monkeypatch.setattr(
        deliberate_break,
        "_changed_assertions",
        lambda *_args: (_ for _ in ()).throw(subprocess.TimeoutExpired(command, 17)),
    )

    result = verify_spec(spec, base=base, cwd=repo)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "tamper-check-timeout",
        "command": command,
        "timeout": 17,
    }


def test_new_assertion_in_existing_test_file_is_not_tamper(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    test_file = repo / "tests" / "test_app.py"
    test_file.parent.mkdir(exist_ok=True)
    test_file.write_text(
        "def test_existing_value():\n    assert 1 + 1 == 2\n",
        encoding="utf-8",
    )
    base = _commit(repo, "base test")
    _write_app(repo, 1)
    test_file.write_text(
        "import app\n\n\n"
        "def test_existing_value():\n"
        "    assert 1 + 1 == 2\n\n\n"
        "def test_value():\n"
        "    assert app.value() == 1\n",
        encoding="utf-8",
    )
    _commit(repo, "implementation and added assertion")
    monkeypatch.chdir(repo)

    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    result = verify_spec(spec, base=base)

    assert result["verdict"] == VERDICT_PASS


def test_added_acceptance_test_is_not_tamper(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    base = _commit(repo, "base behavior")
    _write_app(repo, 1)
    _write_test(repo, 1)
    _commit(repo, "implementation and new test")
    monkeypatch.chdir(repo)

    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None

    result = verify_spec(spec, base=base)

    assert result["verdict"] == VERDICT_PASS


def test_cli_skips_without_marker(tmp_path) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            str(Path(__file__).parents[2] / "scripts" / "check_deliberate_break.py"),
            "--base",
            "HEAD",
        ],
        cwd=tmp_path,
        text=True,
        capture_output=True,
        env={
            **os.environ,
            "PR_BODY": "## Acceptance Criteria\n- [ ] normal",
            "GITHUB_OUTPUT": str(tmp_path / "github-output"),
        },
    )

    assert completed.returncode == 0
    assert "skipped: no deliberate-break marker" in completed.stdout


@pytest.mark.parametrize("installed_version", [None, "6.0.2"])
def test_runtime_dependency_installer_uses_locked_pyyaml(monkeypatch, installed_version) -> None:
    calls: list[tuple[object, dict[str, object]]] = []
    monkeypatch.setenv("GITHUB_ACTIONS", "true")

    def package_version(_name):
        if installed_version is None:
            raise deliberate_break.metadata.PackageNotFoundError
        return installed_version

    def record_install(*args, **kwargs):
        calls.append((args, kwargs))
        return subprocess.CompletedProcess(args[0], 0, "", "")

    monkeypatch.setattr(deliberate_break.metadata, "version", package_version)
    monkeypatch.setattr(deliberate_break, "import_module", lambda _name: object())
    monkeypatch.setattr(deliberate_break.subprocess, "run", record_install)

    deliberate_break._ensure_pytest_runtime_deps()

    assert calls == [
        (
            (
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    "--upgrade",
                    *PYTEST_RUNTIME_DEPENDENCIES,
                ],
            ),
            {
                "check": True,
                "text": True,
                "capture_output": True,
                "timeout": deliberate_break.DEFAULT_TIMEOUT_SECONDS,
            },
        )
    ]


def test_runtime_dependency_installer_accepts_exact_locked_pyyaml(monkeypatch) -> None:
    calls: list[object] = []

    monkeypatch.setattr(
        deliberate_break.metadata,
        "version",
        lambda _name: deliberate_break.PYYAML_VERSION,
    )
    monkeypatch.setattr(deliberate_break, "import_module", lambda _name: object())
    monkeypatch.setattr(
        deliberate_break.subprocess,
        "run",
        lambda *args, **kwargs: calls.append((args, kwargs)),
    )

    deliberate_break._ensure_pytest_runtime_deps()

    assert calls == []


@pytest.mark.parametrize(
    ("installed_version", "supported"),
    [
        (None, False),
        ("6.0.2", False),
        ("6.0.3", True),
        ("6.0.3.0", True),
        ("6.0.3.post1", True),
        ("6.0.2.post1", False),
        ("6.0.3+local.1", True),
        ("6.0.4", True),
        ("6.0.4rc1", True),
        ("6.0.4.dev0", True),
        ("99.0.0", True),
        ("6.0.3rc1", False),
        ("6.0.3.dev0", False),
        ("not-a-version", False),
    ],
)
def test_supported_pyyaml_version_uses_stdlib_only(installed_version, supported) -> None:
    assert deliberate_break._supported_pyyaml_version(installed_version) is supported


def test_pyyaml_version_check_does_not_import_packaging() -> None:
    module = ast.parse(Path(deliberate_break.__file__).read_text(encoding="utf-8"))
    imported_modules: set[str] = set()
    for node in ast.walk(module):
        if isinstance(node, ast.Import):
            imported_modules.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported_modules.add(node.module.split(".", 1)[0])

    assert "packaging" not in imported_modules


def test_runtime_dependency_installer_accepts_newer_compatible_pyyaml(monkeypatch) -> None:
    calls: list[object] = []
    monkeypatch.setattr(deliberate_break.metadata, "version", lambda _name: "99.0.0")
    monkeypatch.setattr(deliberate_break, "import_module", lambda _name: object())
    monkeypatch.setattr(
        deliberate_break.subprocess,
        "run",
        lambda *args, **kwargs: calls.append((args, kwargs)),
    )

    deliberate_break._ensure_pytest_runtime_deps()

    assert calls == []
    assert not deliberate_break._pyyaml_runtime_needs_repair()


@pytest.mark.parametrize("import_error", [ImportError, OSError, AttributeError, SyntaxError])
def test_runtime_dependency_installer_repairs_broken_pyyaml_import(
    monkeypatch, import_error
) -> None:
    calls: list[tuple[object, dict[str, object]]] = []
    imports = 0
    monkeypatch.setenv("GITHUB_ACTIONS", "true")

    def broken_import(_name):
        nonlocal imports
        imports += 1
        if imports == 1:
            raise import_error("broken PyYAML install")
        return object()

    monkeypatch.setattr(
        deliberate_break.metadata,
        "version",
        lambda _name: deliberate_break.PYYAML_VERSION,
    )
    monkeypatch.setattr(deliberate_break, "import_module", broken_import)
    monkeypatch.setattr(
        deliberate_break.subprocess,
        "run",
        lambda *args, **kwargs: calls.append((args, kwargs)),
    )

    deliberate_break._ensure_pytest_runtime_deps()

    assert len(calls) == 1
    assert calls[0][0][0][-1] == f"pyyaml=={deliberate_break.PYYAML_VERSION}"
    assert "--force-reinstall" in calls[0][0][0]
    assert imports == 2


def test_runtime_dependency_installer_preserves_initial_import_failure(
    monkeypatch,
) -> None:
    initial_error = OSError("broken PyYAML install")
    imports = 0
    monkeypatch.setenv("GITHUB_ACTIONS", "true")

    def broken_import(_name):
        nonlocal imports
        imports += 1
        if imports == 1:
            raise initial_error
        raise AttributeError("still broken after reinstall")

    monkeypatch.setattr(
        deliberate_break.metadata,
        "version",
        lambda _name: deliberate_break.PYYAML_VERSION,
    )
    monkeypatch.setattr(deliberate_break, "import_module", broken_import)
    monkeypatch.setattr(
        deliberate_break.subprocess,
        "run",
        lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, "", ""),
    )

    with pytest.raises(ImportError, match="still broken after reinstall") as caught:
        deliberate_break._ensure_pytest_runtime_deps()

    assert caught.value.__cause__ is initial_error
    assert imports == 2


def test_runtime_dependency_installer_does_not_modify_local_environment(monkeypatch) -> None:
    monkeypatch.delenv("GITHUB_ACTIONS", raising=False)
    monkeypatch.setattr(
        deliberate_break.metadata,
        "version",
        lambda _name: (_ for _ in ()).throw(deliberate_break.metadata.PackageNotFoundError),
    )
    monkeypatch.setattr(
        deliberate_break.subprocess,
        "run",
        lambda *_args, **_kwargs: pytest.fail("local dependency install should not run"),
    )

    with pytest.raises(ImportError, match=r"install 'PyYAML>=6\.0\.3'"):
        deliberate_break._ensure_pytest_runtime_deps()


def test_runtime_dependencies_are_not_installed_for_successful_custom_command(
    tmp_path, monkeypatch
) -> None:
    completed = subprocess.CompletedProcess(["custom-check"], 0, "ok", "")
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: completed)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: pytest.fail("dependency repair should not run"),
    )

    assert deliberate_break._run_with_runtime_deps(("custom-check",), tmp_path) is completed


def test_runtime_dependencies_are_not_installed_for_unrelated_failure(
    tmp_path, monkeypatch
) -> None:
    completed = subprocess.CompletedProcess(["custom-check"], 1, "", "assertion failed")
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: completed)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: pytest.fail("dependency repair should not run"),
    )

    assert deliberate_break._run_with_runtime_deps(("custom-check",), tmp_path) is completed


def test_runtime_dependencies_are_not_installed_for_unrelated_pyyaml_mention(
    tmp_path, monkeypatch
) -> None:
    completed = subprocess.CompletedProcess(
        ["custom-check"], 1, "", "test_pyyaml_behavior: assertion failed"
    )
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: completed)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: pytest.fail("dependency repair should not run"),
    )

    assert deliberate_break._run_with_runtime_deps(("custom-check",), tmp_path) is completed


def test_runtime_dependencies_retry_pyyaml_import_failure(tmp_path, monkeypatch) -> None:
    attempts = [
        subprocess.CompletedProcess(
            ["pytest"],
            1,
            "",
            "ModuleNotFoundError: No module named 'yaml'",
        ),
        subprocess.CompletedProcess(["pytest"], 0, "passed", ""),
    ]
    repairs: list[bool] = []
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_runtime_needs_repair",
        lambda: False,
    )
    monkeypatch.setattr(deliberate_break, "_pyyaml_probe_succeeds", lambda *_args: True)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: repairs.append(True),
    )

    completed = deliberate_break._run_with_runtime_deps((sys.executable, "-m", "pytest"), tmp_path)

    assert completed.returncode == 0
    assert repairs == [True]
    assert attempts == []


def test_runtime_dependencies_retry_broken_pyyaml_traceback(tmp_path, monkeypatch) -> None:
    attempts = [
        subprocess.CompletedProcess(
            ["pytest"],
            1,
            "",
            'File "/venv/lib/site-packages/yaml/__init__.py", line 1\nSyntaxError: invalid syntax',
        ),
        subprocess.CompletedProcess(["pytest"], 0, "passed", ""),
    ]
    repairs: list[bool] = []
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_runtime_needs_repair",
        lambda: True,
    )
    monkeypatch.setattr(deliberate_break, "_pyyaml_probe_succeeds", lambda *_args: True)
    monkeypatch.setattr(
        deliberate_break,
        "import_module",
        lambda _name: (_ for _ in ()).throw(SyntaxError("broken wheel")),
    )
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: repairs.append(True),
    )

    completed = deliberate_break._run_with_runtime_deps((sys.executable, "-m", "pytest"), tmp_path)

    assert completed.returncode == 0
    assert repairs == [True]
    assert attempts == []


def test_runtime_dependencies_do_not_preflight_pyyaml_for_successful_pytest(
    tmp_path, monkeypatch
) -> None:
    events: list[str] = []
    completed = subprocess.CompletedProcess(["pytest"], 0, "passed", "")
    monkeypatch.setattr(
        deliberate_break,
        "_run",
        lambda *_args: events.append("run") or completed,
    )
    monkeypatch.setattr(deliberate_break.metadata, "version", lambda _name: "0.0.0")
    monkeypatch.setattr(deliberate_break, "_pyyaml_probe_succeeds", lambda *_args: True)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: events.append("repair"),
    )

    result = deliberate_break._run_with_runtime_deps((sys.executable, "-m", "pytest"), tmp_path)

    assert result is completed
    assert events == ["run"]


def test_managed_runtime_rejects_unrepairable_command_import_context(tmp_path, monkeypatch) -> None:
    repairs: list[bool] = []
    completed = subprocess.CompletedProcess(
        ["pytest"],
        1,
        "",
        "ModuleNotFoundError: No module named 'yaml'",
    )
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: completed)
    monkeypatch.setattr(deliberate_break, "_pyyaml_runtime_needs_repair", lambda: False)
    monkeypatch.setattr(deliberate_break, "_pyyaml_probe_succeeds", lambda *_args: False)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: repairs.append(True),
    )

    with pytest.raises(deliberate_break.RuntimeDependencyError) as caught:
        deliberate_break._run_with_runtime_deps(
            (sys.executable, "-m", "pytest"),
            tmp_path,
        )

    assert repairs == [True]
    assert "managed pytest command environment" in str(caught.value.error)


def test_import_context_changed_active_python_is_not_repaired(tmp_path, monkeypatch) -> None:
    command = (sys.executable, "-s", "-m", "pytest")
    completed = subprocess.CompletedProcess(
        command,
        1,
        "",
        "ModuleNotFoundError: No module named 'yaml'",
    )
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: completed)
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: pytest.fail("flagged import context must not mutate the active environment"),
    )

    with pytest.raises(deliberate_break.RuntimeDependencyError) as caught:
        deliberate_break._run_with_runtime_deps(command, tmp_path)

    assert isinstance(caught.value.error, ImportError)
    assert "wrapped or custom" in str(caught.value.error)


@pytest.mark.parametrize(
    "command",
    [
        ("uv", "run", "pytest"),
        ("/other/venv/bin/python", "-m", "pytest"),
    ],
)
@pytest.mark.parametrize(
    "stderr",
    [
        "ModuleNotFoundError: No module named 'yaml'",
        "ERROR collecting tests/test_manifest.py\n"
        'File "/other/venv/lib/site-packages/yaml/__init__.py", line 1\n'
        "SyntaxError: broken wheel",
        "ERROR collecting tests/test_manifest.py\n"
        'File "/other/venv/lib/site-packages/yaml/__init__.py", line 1\n'
        "E   SyntaxError: broken wheel",
    ],
)
def test_runtime_dependencies_do_not_repair_unmanaged_command_environment(
    tmp_path, monkeypatch, command, stderr
) -> None:
    completed = subprocess.CompletedProcess(
        command,
        1,
        "",
        stderr,
    )
    attempts = [completed]
    if "No module named" not in stderr:
        attempts.append(subprocess.CompletedProcess(["probe"], 1, "", "broken import"))
    monkeypatch.setattr(
        deliberate_break,
        "_run",
        lambda *_args: attempts.pop(0),
    )
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_probe_command",
        lambda _command, _cwd: ("probe",),
    )
    monkeypatch.setattr(
        deliberate_break,
        "_ensure_pytest_runtime_deps",
        lambda: pytest.fail("wrapper-owned environment must not be mutated"),
    )

    with pytest.raises(deliberate_break.RuntimeDependencyError) as caught:
        deliberate_break._run_with_runtime_deps(command, tmp_path)

    assert isinstance(caught.value.error, ImportError)
    assert "wrapped or custom" in str(caught.value.error)
    assert attempts == []


def test_unmanaged_yaml_test_failure_is_not_misclassified_as_dependency_error(
    tmp_path, monkeypatch
) -> None:
    completed = subprocess.CompletedProcess(
        ["uv", "run", "pytest"],
        1,
        "",
        'File "/other/venv/lib/site-packages/yaml/parser.py", line 98\n'
        "yaml.parser.ParserError: malformed fixture",
    )
    attempts = [
        completed,
        subprocess.CompletedProcess(["probe"], 0, deliberate_break.PYYAML_PROBE_SENTINEL, ""),
    ]
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_probe_command",
        lambda _command, _cwd: ("probe",),
    )

    result = deliberate_break._run_with_runtime_deps(("uv", "run", "pytest"), tmp_path)

    assert result is completed
    assert attempts == []


def test_unmanaged_yaml_attribute_error_is_not_misclassified_as_import_failure(
    tmp_path, monkeypatch
) -> None:
    completed = subprocess.CompletedProcess(
        ["uv", "run", "pytest"],
        1,
        "",
        'File "/other/venv/lib/site-packages/yaml/__init__.py", line 125, in safe_load\n'
        "E   AttributeError: 'NoneType' object has no attribute 'read'",
    )
    attempts = [
        completed,
        subprocess.CompletedProcess(["probe"], 0, deliberate_break.PYYAML_PROBE_SENTINEL, ""),
    ]
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_probe_command",
        lambda _command, _cwd: ("probe",),
    )

    result = deliberate_break._run_with_runtime_deps(("uv", "run", "pytest"), tmp_path)

    assert result is completed
    assert attempts == []


def test_interactive_probe_traceback_is_dependency_failure_despite_zero_exit(
    tmp_path, monkeypatch
) -> None:
    command = ("uv", "run", "python", "-im", "pytest")
    attempts = [
        subprocess.CompletedProcess(
            command,
            1,
            "",
            'File "/venv/lib/site-packages/yaml/__init__.py", line 1\nSyntaxError: broken wheel',
        ),
        subprocess.CompletedProcess(
            ["probe"],
            0,
            "",
            "Traceback (most recent call last):\nSyntaxError: broken wheel\n>>> ",
        ),
    ]
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_probe_command",
        lambda _command, _cwd: ("probe",),
    )

    with pytest.raises(deliberate_break.RuntimeDependencyError):
        deliberate_break._run_with_runtime_deps(command, tmp_path)

    assert attempts == []


def test_probe_sentinel_ignores_unrelated_startup_traceback(tmp_path, monkeypatch) -> None:
    command = ("uv", "run", "python", "-im", "pytest")
    completed = subprocess.CompletedProcess(
        command,
        1,
        "",
        'File "/venv/lib/site-packages/yaml/parser.py", line 98\n'
        "yaml.parser.ParserError: malformed fixture",
    )
    attempts = [
        completed,
        subprocess.CompletedProcess(
            ["probe"],
            0,
            deliberate_break.PYYAML_PROBE_SENTINEL,
            "Traceback from unrelated .pth startup error",
        ),
    ]
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: attempts.pop(0))
    monkeypatch.setattr(
        deliberate_break,
        "_pyyaml_probe_command",
        lambda _command, _cwd: ("probe",),
    )

    result = deliberate_break._run_with_runtime_deps(command, tmp_path)

    assert result is completed
    assert attempts == []


def test_uv_pyyaml_probe_uses_resolved_pytest_shebang_interpreter(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "global" / "bin" / "pytest"
    pytest_launcher.parent.mkdir(parents=True)
    pytest_launcher.write_text("#!/global/python\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break,
        "_run",
        lambda *_args: subprocess.CompletedProcess(
            ["uv", "run", "which", "pytest"],
            0,
            f"{pytest_launcher}\n",
            "",
        ),
    )

    assert deliberate_break._pyyaml_probe_command(("uv", "run", "pytest"), tmp_path) == (
        "/global/python",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_uv_pyyaml_probe_preserves_uv_run_options(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "bin" / "pytest"
    pytest_launcher.parent.mkdir()
    pytest_launcher.write_text("#!/project/.venv/bin/python\n", encoding="utf-8")
    calls: list[tuple[str, ...]] = []

    def run(command, _cwd):
        calls.append(command)
        return subprocess.CompletedProcess(command, 0, f"{pytest_launcher}\n", "")

    monkeypatch.setattr(deliberate_break, "_run", run)
    command = (
        "uv",
        "run",
        "--frozen",
        "--group",
        "test",
        "-w",
        "pytest-xdist",
        "-p",
        "3.13",
        "--config-file",
        "uv.toml",
        "--isolated",
        "pytest",
        "-q",
    )

    assert deliberate_break._pyyaml_probe_command(command, tmp_path) == (
        "/project/.venv/bin/python",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )
    assert calls == [
        (
            "uv",
            "run",
            "--frozen",
            "--group",
            "test",
            "-w",
            "pytest-xdist",
            "-p",
            "3.13",
            "--config-file",
            "uv.toml",
            "--isolated",
            "which",
            "pytest",
        )
    ]


def test_uv_pyyaml_probe_preserves_python_shebang_flags(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "global" / "bin" / "pytest"
    pytest_launcher.parent.mkdir(parents=True)
    pytest_launcher.write_text("#!/usr/bin/python3 -I\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break,
        "_run",
        lambda *_args: subprocess.CompletedProcess(
            ["uv", "run", "which", "pytest"],
            0,
            f"{pytest_launcher}\n",
            "",
        ),
    )

    assert deliberate_break._pyyaml_probe_command(("uv", "run", "pytest"), tmp_path) == (
        "/usr/bin/python3",
        "-I",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_uv_pyyaml_probe_omits_interactive_python_shebang_flag(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "global" / "bin" / "pytest"
    pytest_launcher.parent.mkdir(parents=True)
    pytest_launcher.write_text("#!/usr/bin/python3 -i\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break,
        "_run",
        lambda *_args: subprocess.CompletedProcess(
            ["uv", "run", "which", "pytest"],
            0,
            f"{pytest_launcher}\n",
            "",
        ),
    )

    assert deliberate_break._pyyaml_probe_command(("uv", "run", "pytest"), tmp_path) == (
        "/usr/bin/python3",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_uv_pyyaml_probe_resolves_env_shebang_inside_uv_path(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "bin" / "pytest"
    pytest_launcher.parent.mkdir()
    pytest_launcher.write_text("#!/usr/bin/env -S python3 -I\n", encoding="utf-8")
    results = iter(
        (
            subprocess.CompletedProcess(["which", "pytest"], 0, f"{pytest_launcher}\n", ""),
            subprocess.CompletedProcess(
                ["which", "python3"], 0, "/project/.venv/bin/python3\n", ""
            ),
        )
    )
    monkeypatch.setattr(deliberate_break, "_run", lambda *_args: next(results))

    assert deliberate_break._pyyaml_probe_command(("uv", "run", "pytest"), tmp_path) == (
        "/project/.venv/bin/python3",
        "-I",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_uv_pyyaml_probe_rejects_shell_shim_launcher(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "bin" / "pytest"
    pytest_launcher.parent.mkdir()
    pytest_launcher.write_text("#!/usr/bin/env bash\n", encoding="utf-8")
    calls: list[tuple[str, ...]] = []

    def run(command, _cwd):
        calls.append(command)
        return subprocess.CompletedProcess(command, 0, f"{pytest_launcher}\n", "")

    monkeypatch.setattr(deliberate_break, "_run", run)

    assert deliberate_break._pyyaml_probe_command(("uv", "run", "pytest"), tmp_path) is None
    assert calls == [("uv", "run", "which", "pytest")]


def test_bare_pytest_probe_uses_launcher_shebang(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "bin" / "pytest"
    pytest_launcher.parent.mkdir()
    pytest_launcher.write_text("#!/usr/bin/env -S python3 -I\n", encoding="utf-8")

    def which(name):
        return str(pytest_launcher) if name == "pytest" else "/venv/bin/python3"

    monkeypatch.setattr(deliberate_break.shutil, "which", which)

    assert deliberate_break._pyyaml_probe_command(("pytest", "-q"), tmp_path) == (
        "/venv/bin/python3",
        "-I",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_python_module_probe_preserves_interpreter_flags(tmp_path) -> None:
    assert deliberate_break._pyyaml_probe_command(
        ("/venv/bin/python", "-I", "-m", "pytest", "-q"),
        tmp_path,
    ) == ("/venv/bin/python", "-I", "-c", deliberate_break.PYYAML_PROBE_CODE)


def test_active_python_with_flags_is_managed_pytest_runtime() -> None:
    assert deliberate_break._uses_pytest_runtime(
        (sys.executable, "-X", "dev", "-O", "-m", "pytest", "-q")
    )


def test_plain_pytest_with_active_python_shebang_is_managed(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "pytest"
    pytest_launcher.write_text(f"#!{sys.executable}\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break.shutil,
        "which",
        lambda name: str(pytest_launcher) if name == "pytest" else None,
    )

    assert deliberate_break._uses_pytest_runtime(("pytest", "-q"))


def test_plain_pytest_with_interactive_shebang_is_managed(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "pytest"
    pytest_launcher.write_text(f"#!{sys.executable} -i\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break.shutil,
        "which",
        lambda name: str(pytest_launcher) if name == "pytest" else None,
    )

    assert deliberate_break._uses_pytest_runtime(("pytest", "-q"))
    assert deliberate_break._pyyaml_probe_command(("pytest", "-q"), tmp_path) == (
        sys.executable,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_plain_pytest_with_changed_import_context_is_not_managed(tmp_path, monkeypatch) -> None:
    pytest_launcher = tmp_path / "pytest"
    pytest_launcher.write_text(f"#!{sys.executable} -I\n", encoding="utf-8")
    monkeypatch.setattr(
        deliberate_break.shutil,
        "which",
        lambda name: str(pytest_launcher) if name == "pytest" else None,
    )

    assert not deliberate_break._uses_pytest_runtime(("pytest", "-q"))


def test_active_python_with_hash_policy_is_managed_pytest_runtime() -> None:
    assert deliberate_break._uses_pytest_runtime(
        (
            sys.executable,
            "--check-hash-based-pycs",
            "default",
            "-m",
            "pytest",
        )
    )


def test_invalid_hash_policy_is_not_managed_pytest_runtime() -> None:
    assert not deliberate_break._uses_pytest_runtime(
        (
            sys.executable,
            "--check-hash-based-pycs",
            "bogus",
            "-m",
            "pytest",
        )
    )


def test_unsupported_lowercase_r_is_not_managed_pytest_runtime() -> None:
    assert not deliberate_break._uses_pytest_runtime((sys.executable, "-r", "-m", "pytest"))


@pytest.mark.parametrize(
    "options",
    [
        ("-S", "-m", "pytest"),
        ("-OSm", "pytest"),
        ("-OSmpytest",),
    ],
)
def test_site_disabled_python_is_not_managed_pytest_runtime(options) -> None:
    assert not deliberate_break._uses_pytest_runtime((sys.executable, *options))


@pytest.mark.parametrize("context_flag", ["-E", "-I", "-P", "-s"])
def test_import_context_changed_python_is_not_managed_pytest_runtime(context_flag) -> None:
    assert not deliberate_break._uses_pytest_runtime((sys.executable, context_flag, "-m", "pytest"))


@pytest.mark.parametrize(
    "compact_option",
    ["-Empytest", "-Impytest", "-Pmpytest", "-smpytest"],
)
def test_compact_import_context_changed_python_is_not_managed(compact_option) -> None:
    assert not deliberate_break._uses_pytest_runtime((sys.executable, compact_option))


def test_empty_command_is_not_managed_pytest_runtime() -> None:
    assert not deliberate_break._uses_pytest_runtime(())


@pytest.mark.parametrize(
    ("compact_option", "preserved"),
    [
        ("-im", ()),  # lowercase -i must not reach the import probe
        ("-OOm", ("-OO",)),
        ("-tm", ("-t",)),
        ("-Oim", ("-O",)),
    ],
)
def test_active_python_with_compact_flags_is_managed_pytest_runtime(
    compact_option, preserved
) -> None:
    command = (sys.executable, compact_option, "pytest", "-q")

    assert deliberate_break._uses_pytest_runtime(command)
    assert deliberate_break._pyyaml_probe_command(command, Path.cwd()) == (
        sys.executable,
        *preserved,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_active_python_separate_interactive_flag_omitted_from_probe() -> None:
    command = (sys.executable, "-i", "-m", "pytest", "-q")

    assert deliberate_break._uses_pytest_runtime(command)
    assert deliberate_break._pyyaml_probe_command(command, Path.cwd()) == (
        sys.executable,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    ("compact_option", "preserved"),
    [("-mpytest", ()), ("-Ompytest", ("-O",)), ("-impytest", ())],
)
def test_active_python_with_attached_pytest_module_is_managed_runtime(
    compact_option, preserved
) -> None:
    command = (sys.executable, compact_option, "-q")

    assert deliberate_break._uses_pytest_runtime(command)
    assert deliberate_break._pyyaml_probe_command(command, Path.cwd()) == (
        sys.executable,
        *preserved,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    "options",
    [
        ("-OW", "ignore"),
        ("-OX", "dev"),
        ("-OWignore",),
        ("-OXdev",),
    ],
)
def test_active_python_with_compact_value_option_is_managed_runtime(options) -> None:
    command = (sys.executable, *options, "-m", "pytest", "-q")

    assert deliberate_break._uses_pytest_runtime(command)
    assert deliberate_break._pyyaml_probe_command(command, Path.cwd()) == (
        sys.executable,
        *options,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    ("interactive_option", "preserved"),
    [
        ("-iWerror", "-Werror"),
        ("-iXdev", "-Xdev"),
        ("-OiWerror", "-OWerror"),
        ("-OiXdev", "-OXdev"),
    ],
)
def test_compact_interactive_value_option_is_removed_from_probe(
    interactive_option, preserved
) -> None:
    command = (sys.executable, interactive_option, "-m", "pytest")

    assert deliberate_break._uses_pytest_runtime(command)
    assert deliberate_break._pyyaml_probe_command(command, Path.cwd()) == (
        sys.executable,
        preserved,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    "terminator",
    [
        "--",
        "-",
        "-V",
        "-VV",
        "--version",
        "-h",
        "--help",
        "-cprint(1)",
        "-mthis",
        "-Icprint(1)",
        "-Imthis",
        "-IV",
        "-Ih",
        "-I?",
        "--bogus",
    ],
)
def test_python_terminator_prevents_managed_pytest_classification(terminator) -> None:
    assert not deliberate_break._uses_pytest_runtime((sys.executable, terminator, "-m", "pytest"))


def test_active_python_script_with_pytest_arguments_is_not_managed_runtime() -> None:
    assert not deliberate_break._uses_pytest_runtime(
        (sys.executable, "scripts/run_tests.py", "-m", "pytest")
    )


@pytest.mark.parametrize("module_option", ["-m", "--module"])
def test_uv_module_pytest_probe_uses_uv_selected_python(tmp_path, module_option) -> None:
    assert deliberate_break._pyyaml_probe_command(
        ("uv", "run", "--frozen", module_option, "pytest", "-q"),
        tmp_path,
    ) == (
        "uv",
        "run",
        "--frozen",
        "python",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


def test_uv_nested_python_module_probe_preserves_uv_and_python_options(tmp_path) -> None:
    assert deliberate_break._pyyaml_probe_command(
        (
            "uv",
            "run",
            "--no-project",
            "--python",
            "3.13",
            "python",
            "-I",
            "-m",
            "pytest",
            "-q",
        ),
        tmp_path,
    ) == (
        "uv",
        "run",
        "--no-project",
        "--python",
        "3.13",
        "python",
        "-I",
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    ("compact_option", "preserved"),
    [("-mpytest", ()), ("-Impytest", ("-I",))],
)
def test_minimal_uv_nested_attached_pytest_module_probe(
    tmp_path, compact_option, preserved
) -> None:
    assert deliberate_break._pyyaml_probe_command(
        ("uv", "run", "python", compact_option),
        tmp_path,
    ) == (
        "uv",
        "run",
        "python",
        *preserved,
        "-c",
        deliberate_break.PYYAML_PROBE_CODE,
    )


@pytest.mark.parametrize(
    "command",
    [
        ("uv", "run", "python", "scripts/run_tests.py", "-m", "pytest"),
        ("uv", "run", "python", "-c", "run_tests()", "-m", "pytest"),
        ("python", "scripts/run_tests.py", "-m", "pytest"),
    ],
)
def test_python_probe_stops_after_first_program_selector(tmp_path, command) -> None:
    assert deliberate_break._pyyaml_probe_command(command, tmp_path) is None


def _sound_spec(repo: Path) -> tuple[str, object]:
    _write_app(repo, 0)
    base = _commit(repo, "base behavior")
    _write_app(repo, 1)
    _write_test(repo, 1)
    _commit(repo, "implementation and test")
    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None
    return base, spec


def test_dependency_install_timeout_is_broken(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    command = [sys.executable, "-m", "pip", "install", *PYTEST_RUNTIME_DEPENDENCIES]

    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_args: (_ for _ in ()).throw(
            deliberate_break.RuntimeDependencyError(subprocess.TimeoutExpired(command, 17))
        ),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "dependency-install-timeout",
        "command": command,
        "timeout": 17,
    }


def test_dependency_install_failure_preserves_subprocess_context(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    error = subprocess.CalledProcessError(
        17,
        ["pip", "install", "pyyaml==6.0.3"],
        output="resolver output",
        stderr="pip denied",
    )

    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_args: (_ for _ in ()).throw(deliberate_break.RuntimeDependencyError(error)),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "dependency-install-failed",
        "command": ["pip", "install", "pyyaml==6.0.3"],
        "returncode": 17,
        "stdout": "resolver output",
        "stderr": "pip denied",
    }


def test_dependency_install_failure_normalizes_byte_output(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    error = subprocess.CalledProcessError(
        17,
        ["pip", "install", "pyyaml==6.0.3"],
        output=b"resolver \xff output",
        stderr=b"pip denied",
    )

    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_args: (_ for _ in ()).throw(deliberate_break.RuntimeDependencyError(error)),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "dependency-install-failed",
        "command": ["pip", "install", "pyyaml==6.0.3"],
        "returncode": 17,
        "stdout": "resolver \ufffd output",
        "stderr": "pip denied",
    }
    json.dumps(result)


def test_dependency_install_unavailable_is_broken(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)

    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_args: (_ for _ in ()).throw(
            deliberate_break.RuntimeDependencyError(OSError("pip unavailable"))
        ),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "dependency-install-unavailable",
        "detail": "pip unavailable",
    }


def test_dependency_import_failure_is_broken(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    original = OSError("original import failed")

    def failed() -> None:
        try:
            raise ImportError("retry failed") from original
        except ImportError as exc:
            raise deliberate_break.RuntimeDependencyError(exc) from exc

    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_args: failed(),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "dependency-import-failed",
        "detail": "retry failed",
        "cause": "original import failed",
    }


def test_base_archive_command_failure_is_not_dependency_failure(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    error = subprocess.CalledProcessError(
        17,
        ["git", "archive", base],
        output=b"archive output",
        stderr=b"bad ref",
    )
    monkeypatch.setattr(
        deliberate_break,
        "_archive_ref",
        lambda *_args: (_ for _ in ()).throw(error),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "archive-command-failed",
        "command": ["git", "archive", base],
        "returncode": 17,
        "stdout": "archive output",
        "stderr": "bad ref",
    }
    json.dumps(result)


def test_base_setup_failure_is_not_dependency_failure(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    monkeypatch.setattr(
        deliberate_break,
        "_archive_ref",
        lambda *_args: (_ for _ in ()).throw(OSError("disk unavailable")),
    )

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "base-setup-failed",
        "detail": "disk unavailable",
    }


def test_base_command_launch_failure_is_reported_as_command_unavailable(
    tmp_path, monkeypatch
) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    base, spec = _sound_spec(repo)
    calls = 0

    def run_command(*_args):
        nonlocal calls
        calls += 1
        if calls == 1:
            return subprocess.CompletedProcess(spec.command, 0, "", "")
        error = FileNotFoundError("base-only command is unavailable")
        raise deliberate_break.CommandUnavailableError(error) from error

    monkeypatch.setattr(deliberate_break, "_run_with_runtime_deps", run_command)

    result = verify_spec(spec, base=base, cwd=repo, enforce_tamper=False)

    assert result == {
        "verdict": VERDICT_BROKEN,
        "reason": "command-unavailable",
        "command": list(spec.command),
        "detail": "base-only command is unavailable",
    }


# =================================================================================================
# Interpreter resolution and output plumbing.
#
# Ranked here by `escaped_defect_priority`: this module carries more fix commits and more churn
# than anything else in the repo, and 88 of its statements were unexercised. The branches below are
# the ones that decide WHICH PYTHON runs a deliberate-break check. Every one of them returns None
# on a shape it cannot verify, and every one was unexercised — so a wrong answer here would run the
# check under an unintended interpreter, and the check's verdict is what gates a PR.
# =================================================================================================


def _launcher(tmp_path: Path, shebang: str, *, resolve=lambda name: f"/resolved/{name}"):
    script = tmp_path / "pytest-shim"
    script.write_text(f"{shebang}\nprint('hi')\n", encoding="utf-8")
    return deliberate_break._python_shebang_launcher(script, resolve)


def test_a_plain_python_shebang_is_used_as_the_launcher(tmp_path):
    assert _launcher(tmp_path, "#!/usr/bin/python3.12") == ("/usr/bin/python3.12",)


def test_interpreter_flags_are_preserved(tmp_path):
    """Dropping a flag silently changes how the verification runs.

    `-S` and friends alter import behaviour, so a launcher that keeps only the interpreter would
    run the candidate under a different environment than the one the shebang asked for.
    """
    assert _launcher(tmp_path, "#!/usr/bin/env -S python3 -X utf8") == (
        "/resolved/python3",
        "-X",
        "utf8",
    )


def test_an_env_shebang_resolves_the_interpreter_by_name(tmp_path):
    assert _launcher(tmp_path, "#!/usr/bin/env python3") == ("/resolved/python3",)


def test_an_env_name_that_cannot_be_resolved_is_refused(tmp_path):
    """Refusing beats guessing: an unresolvable name would otherwise be executed as written."""
    assert _launcher(tmp_path, "#!/usr/bin/env python3", resolve=lambda name: None) is None


@pytest.mark.parametrize(
    "shebang, why",
    [
        ("#!/bin/sh", "a non-Python interpreter must not be accepted as a Python launcher"),
        ("#!/usr/bin/env bash", "env pointing at a non-Python name must be refused"),
        ("#!", "a bare #! names no interpreter"),
        ("# not a shebang at all", "a file whose first line is not a shebang has no launcher"),
        ('#!/usr/bin/env "python3', "an unbalanced quote must be refused, not raised"),
    ],
)
def test_a_shape_that_cannot_be_verified_returns_none(tmp_path, shebang, why):
    assert _launcher(tmp_path, shebang) is None, why


def test_an_unreadable_script_returns_none_rather_than_raising(tmp_path):
    """The caller treats None as "no launcher"; an exception here would abort the whole check."""
    missing = tmp_path / "does-not-exist"
    assert deliberate_break._python_shebang_launcher(missing, lambda n: n) is None


def test_an_empty_file_returns_none(tmp_path):
    """`splitlines()[0]` on an empty file raises IndexError — caught, not propagated."""
    empty = tmp_path / "empty"
    empty.write_text("", encoding="utf-8")
    assert deliberate_break._python_shebang_launcher(empty, lambda n: n) is None


def test_a_versioned_python_name_is_recognised(tmp_path):
    """`python3.12.1` and `python` are both legitimate; the pattern must accept the whole family."""
    for name in ("python", "python3", "python3.12", "python3.12.1"):
        assert _launcher(tmp_path, f"#!/usr/bin/{name}") == (f"/usr/bin/{name}",), name


def test_github_output_is_appended_not_overwritten(tmp_path, monkeypatch):
    """Two writers in one job must both survive; opening in write mode would drop the first."""
    out = tmp_path / "github-output"
    out.write_text("existing=1\n", encoding="utf-8")
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    deliberate_break._write_github_output(verdict="PASS", reason="ok")
    assert out.read_text(encoding="utf-8") == "existing=1\nverdict=PASS\nreason=ok\n"


def test_github_output_is_a_no_op_outside_actions(tmp_path, monkeypatch):
    """Running this script locally must not fail for want of a CI-only variable."""
    monkeypatch.delenv("GITHUB_OUTPUT", raising=False)
    deliberate_break._write_github_output(verdict="PASS")  # must not raise


def test_github_output_ignores_an_empty_variable(monkeypatch):
    """An empty GITHUB_OUTPUT is not a path. Treating it as one would write to the repo root."""
    monkeypatch.setenv("GITHUB_OUTPUT", "")
    deliberate_break._write_github_output(verdict="PASS")  # must not raise


# =================================================================================================
# `main` — the exit-code contract, which is what actually gates a PR.
#
# 23 contiguous statements, none of them exercised. The two directions fail differently and both
# fail badly: a SKIP that exits non-zero blocks every PR that carries no marker, and a BROKEN or
# HOLLOW verdict that exits zero lets a defective break through with a green check — a gate whose
# own report is the only thing saying it worked.
# =================================================================================================

MARKER = (
    "<!-- deliberate-break: "
    "test=tests/test_app.py::test_value "
    "test-file=tests/test_app.py "
    "break-file=app.py -->"
)


def _capture_outputs(tmp_path, monkeypatch):
    out = tmp_path / "gh-output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    return out


def _stub_verdict(monkeypatch, verdict: str) -> dict:
    seen: dict = {}

    def fake(spec, **kwargs):
        seen.update(kwargs)
        seen["spec"] = spec
        return {"verdict": verdict, "reason": "stubbed"}

    monkeypatch.setattr(deliberate_break, "verify_spec", fake)
    return seen


def test_no_marker_skips_and_exits_zero(tmp_path, monkeypatch, capsys):
    """Most PRs carry no marker. Exiting non-zero here would block all of them."""
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", "an ordinary pull request body")
    assert deliberate_break.main([]) == 0
    assert "skipped: no deliberate-break marker" in capsys.readouterr().out


def test_no_marker_reports_has_marker_false_not_silence(tmp_path, monkeypatch, capsys):
    """`has_marker` is how the workflow tells "no marker" from "the check did not run".

    Emitting nothing would make a skipped check and a crashed one look identical downstream.
    """
    out = _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", "no marker here")
    deliberate_break.main([])
    capsys.readouterr()
    written = out.read_text(encoding="utf-8")
    assert "has_marker=false" in written
    assert f"verdict={deliberate_break.VERDICT_SKIPPED}" in written


def test_a_passing_verdict_exits_zero(tmp_path, monkeypatch, capsys):
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)
    _stub_verdict(monkeypatch, VERDICT_PASS)
    assert deliberate_break.main([]) == 0
    capsys.readouterr()


@pytest.mark.parametrize("verdict", [VERDICT_BROKEN, VERDICT_HOLLOW, "ERROR"])
def test_any_non_passing_verdict_exits_non_zero(tmp_path, monkeypatch, capsys, verdict):
    """The whole point of the gate. PASS is the ONLY green verdict — including for values this
    module does not enumerate, which is why an unknown string is parametrised here too."""
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)
    _stub_verdict(monkeypatch, verdict)
    assert deliberate_break.main([]) == 1
    capsys.readouterr()


def test_the_verdict_reaches_the_workflow_output(tmp_path, monkeypatch, capsys):
    out = _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)
    _stub_verdict(monkeypatch, VERDICT_HOLLOW)
    deliberate_break.main([])
    capsys.readouterr()
    written = out.read_text(encoding="utf-8")
    assert "has_marker=true" in written
    assert f"verdict={VERDICT_HOLLOW}" in written


def test_the_body_file_wins_over_the_environment(tmp_path, monkeypatch, capsys):
    """A file is passed explicitly; an env var is ambient. Reading the wrong one silently checks
    the wrong PR."""
    _capture_outputs(tmp_path, monkeypatch)
    body_file = tmp_path / "body.md"
    body_file.write_text(MARKER, encoding="utf-8")
    monkeypatch.setenv("PR_BODY", "no marker in the environment")
    seen = _stub_verdict(monkeypatch, VERDICT_PASS)
    assert deliberate_break.main(["--pr-body-file", str(body_file)]) == 0
    capsys.readouterr()
    assert seen["spec"] is not None, "the marker in the FILE must be the one parsed"


def test_a_custom_body_env_name_is_honoured(tmp_path, monkeypatch, capsys):
    out = _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", "no marker here")
    monkeypatch.setenv("OTHER_BODY", MARKER)
    seen = _stub_verdict(monkeypatch, VERDICT_PASS)
    assert deliberate_break.main(["--pr-body-env", "OTHER_BODY"]) == 0
    capsys.readouterr()
    assert seen["spec"] is not None, "the marker in OTHER_BODY must reach verify_spec"
    assert "has_marker=true" in out.read_text(encoding="utf-8")


def test_no_tamper_check_inverts_into_enforce_tamper(tmp_path, monkeypatch, capsys):
    """An inverted flag is easy to get backwards, and getting it backwards disables the tamper
    check on every run while the flag still reads as opt-in."""
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)

    seen = _stub_verdict(monkeypatch, VERDICT_PASS)
    deliberate_break.main([])
    capsys.readouterr()
    assert seen["enforce_tamper"] is True, "tamper checking must be ON by default"

    seen = _stub_verdict(monkeypatch, VERDICT_PASS)
    deliberate_break.main(["--no-tamper-check"])
    capsys.readouterr()
    assert seen["enforce_tamper"] is False


def test_base_and_head_reach_verify_spec(tmp_path, monkeypatch, capsys):
    """Comparing the wrong revisions produces a confident verdict about the wrong diff."""
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)
    seen = _stub_verdict(monkeypatch, VERDICT_PASS)
    deliberate_break.main(["--base", "origin/release", "--head", "abc123"])
    capsys.readouterr()
    assert seen["base"] == "origin/release"
    assert seen["head"] == "abc123"


def test_selected_pr_body_file_reaches_tamper_check(tmp_path, monkeypatch, capsys):
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", "<!-- meta:issue:35 -->")
    body_file = tmp_path / "pr-body.md"
    body_file.write_text("<!-- meta:issue:36 -->\n" + MARKER, encoding="utf-8")
    seen = _stub_verdict(monkeypatch, VERDICT_PASS)

    deliberate_break.main(["--pr-body-file", str(body_file)])
    capsys.readouterr()

    assert seen["pr_body"] == body_file.read_text(encoding="utf-8")


def test_the_result_is_printed_as_parseable_json(tmp_path, monkeypatch, capsys):
    """Downstream steps read stdout. Human-readable-only output would strand them."""
    _capture_outputs(tmp_path, monkeypatch)
    monkeypatch.setenv("PR_BODY", MARKER)
    _stub_verdict(monkeypatch, VERDICT_BROKEN)
    deliberate_break.main([])
    printed = capsys.readouterr().out.strip().splitlines()[-1]
    assert json.loads(printed)["verdict"] == VERDICT_BROKEN


def test_missing_module_is_reported_as_an_environment_defect() -> None:
    """A test that could not be imported never ran, so it cannot have failed a demonstration.

    Reporting both under `head-test-failed` is one sentinel meaning two things: it sent
    Deliverable-Render #20 through five autofix attempts against its own correctly declared
    dependency, because the message pointed at the PR instead of at the gate's environment.
    """
    pytest_output = (
        "ImportError while importing test module 'tests/docx/test_memo.py'.\n"
        "E   ModuleNotFoundError: No module named 'docx'\n"
        "=========================== short test summary ============================\n"
    )

    assert deliberate_break._missing_module_from_pytest_output(pytest_output, None) == "docx"


def test_a_genuine_assertion_failure_is_not_reclassified() -> None:
    """The environment branch must not swallow a real failed demonstration."""
    pytest_output = "E   assert 1 == 2\n1 failed in 0.02s\n"

    assert deliberate_break._missing_module_from_pytest_output(pytest_output, "") is None


def test_missing_module_is_found_on_either_stream() -> None:
    """Collection evidence and the module name may arrive on different streams."""
    assert (
        deliberate_break._missing_module_from_pytest_output(
            "ERROR collecting tests/test_app.py",
            "ModuleNotFoundError: No module named 'lxml'",
        )
        == "lxml"
    )


def _import_error_run(stdout: str) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(args=["pytest"], returncode=1, stdout=stdout, stderr="")


def test_verify_spec_reports_a_collection_import_failure_as_an_environment_defect(
    tmp_path, monkeypatch
) -> None:
    """Drive the real call site, not just the helper.

    Review was right that asserting on `_missing_module_from_pytest_output` alone leaves the
    wiring untested: a regression in the branch or in the stream ordering would keep the unit
    tests green while the gate carried on emitting `head-test-failed`.
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    _write_test(repo, 0)
    base = _commit(repo, "base test")
    monkeypatch.chdir(repo)
    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None
    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_a, **_k: _import_error_run(
            "ImportError while importing test module 'tests/test_app.py'.\n"
            "E   ModuleNotFoundError: No module named 'docx'\n"
        ),
    )

    result = verify_spec(spec, base=base, enforce_tamper=False)

    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "head-test-not-importable"
    assert result["missing_module"] == "docx"
    assert "never ran" in str(result["detail"])


def test_verify_spec_keeps_head_test_failed_for_a_real_failure(tmp_path, monkeypatch) -> None:
    """A test that ran and failed must not be excused as an environment defect."""
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _write_app(repo, 0)
    _write_test(repo, 0)
    base = _commit(repo, "base test")
    monkeypatch.chdir(repo)
    spec = parse_deliberate_break_spec(
        "<!-- deliberate-break: "
        "test=tests/test_app.py::test_value "
        "test-file=tests/test_app.py "
        "break-file=app.py -->"
    )
    assert spec is not None
    monkeypatch.setattr(
        deliberate_break,
        "_run_with_runtime_deps",
        lambda *_a, **_k: _import_error_run("E   assert 1 == 2\n1 failed in 0.01s\n"),
    )

    result = verify_spec(spec, base=base, enforce_tamper=False)

    assert result["reason"] == "head-test-failed"


def test_a_missing_module_raised_inside_a_test_body_is_a_real_failure() -> None:
    """Without collection evidence this is an ordinary failure of a test that DID run.

    Excusing it would hide a genuine acceptance failure behind an environment explanation.
    """
    in_test_body = (
        "tests/test_app.py::test_value FAILED\n"
        "E   ModuleNotFoundError: No module named 'docx'\n"
        "1 failed in 0.10s\n"
    )

    assert deliberate_break._missing_module_from_pytest_output(in_test_body, None) is None


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_base_collection_failure_cannot_prove_a_deliberate_break(tmp_path, prefix):
    """The head can import a new dependency while the archived base cannot collect."""
    executions = tmp_path / "test-executions.txt"
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "conftest.py").write_text(
        "import sys\n"
        "from pathlib import Path\n"
        "def pytest_runtest_call(item):\n"
        f"    with Path({str(executions)!r}).open('a') as output:\n"
        "        output.write('called\\n')\n"
        "def pytest_sessionstart(session):\n"
        "    print('base dependency stdout sentinel', file=sys.stdout)\n"
        "    print('base dependency stderr sentinel', file=sys.stderr)\n",
        encoding="utf-8",
    )
    base = _commit(repo, "base without the candidate dependency")
    (repo / "candidate_dependency.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "test_candidate.py").write_text(
        "from candidate_dependency import VALUE\ndef test_value():\n    assert VALUE == 1\n",
        encoding="utf-8",
    )
    _commit(repo, "candidate test and dependency")
    spec = helper["DeliberateBreakSpec"](
        "test_candidate.py::test_value",
        "test_candidate.py",
        "app.py",
        (sys.executable, "-m", "pytest", "-q", "-o", "addopts=", "test_candidate.py::test_value"),
    )
    result = helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    # This record survives archive cleanup and proves head execution, not just a verdict.
    assert executions.exists(), "the head pytest command never executed the test"
    assert executions.read_text(encoding="utf-8").splitlines() == ["called"]
    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "base-test-not-importable"
    assert result["missing_module"] == "candidate_dependency"
    assert "never ran" in result["detail"]
    assert "ModuleNotFoundError: No module named 'candidate_dependency'" in result["base_stdout"]
    assert "base dependency stdout sentinel" in result["base_stdout"]
    assert "base dependency stderr sentinel" in result["base_stderr"]


@pytest.fixture(params=["", "templates/consumer-repo/"], ids=["root", "consumer"])
def base_proof_helper(request):
    return runpy.run_path(
        str(
            Path(__file__).resolve().parents[2]
            / request.param
            / "scripts/check_deliberate_break.py"
        )
    )


def _base_proof_repo(tmp_path, helper, base_app, head_app, test_source, conftest_source=""):
    """Commit a base tree and a candidate test for a real archive/pytest proof."""
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text(base_app, encoding="utf-8")
    (repo / "conftest.py").write_text(conftest_source, encoding="utf-8")
    base = _commit(repo, "base behavior")
    (repo / "app.py").write_text(head_app, encoding="utf-8")
    (repo / "test_candidate.py").write_text(test_source, encoding="utf-8")
    _commit(repo, "candidate implementation and test")
    spec = helper["DeliberateBreakSpec"](
        "test_candidate.py::test_value",
        "test_candidate.py",
        "app.py",
        # The file contains one test. Selecting the file lets collection failures
        # use exit 2 rather than the node-selector's additional usage error.
        (sys.executable, "-m", "pytest", "-q", "-o", "addopts=", "test_candidate.py"),
    )
    return repo, base, spec


@pytest.mark.parametrize("stream", ["stdout", "stderr"])
def test_base_import_diagnostics_preserve_both_streams(tmp_path, base_proof_helper, stream):
    """Route actual pytest collection diagnostics to either stream, retaining both."""
    repo, base, spec = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        "VALUE = 1\n",
        "VALUE = 1\n",
        "from candidate_dependency import VALUE\ndef test_value():\n    assert VALUE == 1\n",
        "import sys\n"
        "from _pytest._io import TerminalWriter\n"
        "def pytest_sessionstart(session):\n"
        "    reporter = session.config.pluginmanager.getplugin('terminalreporter')\n"
        f"    reporter._tw = TerminalWriter(file=sys.{stream})\n"
        "    print('base stdout sentinel', file=sys.stdout)\n"
        "    print('base stderr sentinel', file=sys.stderr)\n",
    )
    (repo / "candidate_dependency.py").write_text("VALUE = 1\n", encoding="utf-8")
    _commit(repo, "dependency available only on head")
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "base-test-not-importable"
    assert result["missing_module"] == "candidate_dependency"
    assert "ERROR collecting" in result[f"base_{stream}"]
    assert "ModuleNotFoundError: No module named 'candidate_dependency'" in result[f"base_{stream}"]
    assert "base stdout sentinel" in result["base_stdout"]
    assert "base stderr sentinel" in result["base_stderr"]
    assert result["command"] == list(spec.command)


@pytest.mark.parametrize(
    "exit_code,stream",
    [(1, "stdout"), (1, "stderr"), (2, "stdout"), (3, "stdout"), (4, "stdout"), (5, "stdout")],
)
def test_base_pytest_must_execute_a_test_before_counting_as_red(
    tmp_path, base_proof_helper, exit_code, stream
):
    """Interrupted collection, internal/usage errors and no tests are not a failed assertion."""
    executions = tmp_path / "test-executions.txt"
    repo, base, spec = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        f"MODE = {exit_code}\n",
        "MODE = 0\n",
        "import app\n"
        "if app.MODE in (1, 2):\n"
        "    raise RuntimeError('base collection diagnostic')\n"
        "def test_value():\n"
        "    assert app.MODE == 0\n",
        "import app, pytest, sys\n"
        "from pathlib import Path\n"
        "from _pytest._io import TerminalWriter\n"
        "def pytest_runtest_call(item):\n"
        f"    with Path({str(executions)!r}).open('a') as output:\n"
        "        output.write(f'{app.MODE}\\n')\n"
        "def pytest_sessionstart(session):\n"
        "    reporter = session.config.pluginmanager.getplugin('terminalreporter')\n"
        f"    reporter._tw = TerminalWriter(file=sys.{stream})\n"
        "    if app.MODE:\n"
        "        print('base stdout sentinel', file=sys.stdout)\n"
        "        print('base stderr sentinel', file=sys.stderr)\n"
        "def pytest_collection_modifyitems(items):\n"
        "    if app.MODE == 3:\n"
        "        raise RuntimeError('base internal diagnostic')\n"
        "    if app.MODE == 4:\n"
        "        raise pytest.UsageError('base usage diagnostic')\n"
        "    if app.MODE == 5:\n"
        "        items.clear()\n",
    )
    if exit_code == 1:
        # Pytest can report a collection error as exit 1 without running a test.
        spec = base_proof_helper["DeliberateBreakSpec"](
            spec.test_id,
            spec.test_file,
            spec.break_file,
            (*spec.command, "--continue-on-collection-errors"),
        )
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    # The external record survives archive cleanup: head ran, base never did.
    assert executions.read_text(encoding="utf-8").splitlines() == ["0"]
    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "base-test-did-not-run"
    assert result["returncode"] == exit_code
    assert "base stdout sentinel" in result["base_stdout"]
    assert "base stderr sentinel" in result["base_stderr"]
    diagnostic = {
        1: "base collection diagnostic",
        2: "base collection diagnostic",
        3: "INTERNALERROR",
        4: "base usage diagnostic",
        5: "no tests ran",
    }[exit_code]
    assert diagnostic in result["base_stdout"] + result["base_stderr"]
    if exit_code == 1:
        assert "ERROR collecting" in result[f"base_{stream}"]


@pytest.mark.parametrize("stream", ["stdout", "stderr"])
@pytest.mark.parametrize("collection_text", [False, True])
def test_base_missing_import_inside_a_test_still_proves_red(
    tmp_path, base_proof_helper, stream, collection_text
):
    """A ModuleNotFoundError raised by the selected test is an actual behavioral failure."""
    executions = tmp_path / "test-executions.txt"
    repo, base, spec = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        (
            "def value():\n"
            + (
                f"    import sys\n    print('ERROR collecting unrelated.py', file=sys.{stream})\n"
                if collection_text
                else ""
            )
            + "    import candidate_dependency\n    return candidate_dependency.VALUE\n"
        ),
        "def value():\n    return 1\n",
        "import app\n"
        "from pathlib import Path\n"
        "def test_value():\n"
        f"    with Path({str(executions)!r}).open('a') as output:\n"
        "        output.write('called\\n')\n"
        "    assert app.value() == 1\n",
        "import sys\n"
        "from _pytest._io import TerminalWriter\n"
        "def pytest_sessionstart(session):\n"
        "    reporter = session.config.pluginmanager.getplugin('terminalreporter')\n"
        f"    reporter._tw = TerminalWriter(file=sys.{stream})\n",
    )
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    assert executions.read_text(encoding="utf-8").splitlines() == ["called", "called"]
    assert result["verdict"] == VERDICT_PASS
    assert result["reason"] == "head-passed-base-failed"
    assert "1 failed" in result[f"base_{stream}"]
    assert "ModuleNotFoundError: No module named 'candidate_dependency'" in result[f"base_{stream}"]
    assert ("ERROR collecting" in result["base_stdout"] + result["base_stderr"]) == collection_text


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_base_parametrized_execution_proves_red_despite_collection_text(tmp_path, prefix):
    """A base-function marker covers its executed parametrized pytest node.

    The collection-looking text models a second diagnostic emitted in the same pytest
    run.  It must not erase proof that the selected case actually ran and failed.
    """
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text("VALUE = 0\n", encoding="utf-8")
    base = _commit(repo, "base behavior")
    (repo / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "test_candidate.py").write_text(
        "import pytest\nimport app\n\n"
        "@pytest.mark.parametrize('expected', [1])\n"
        "def test_value(expected):\n"
        "    print('ERROR collecting unrelated.py')\n"
        "    assert app.VALUE == expected\n",
        encoding="utf-8",
    )
    _commit(repo, "candidate implementation and parametrized test")
    spec = helper["DeliberateBreakSpec"](
        "test_candidate.py::test_value",
        "test_candidate.py",
        "app.py",
        (sys.executable, "-m", "pytest", "-q", "-o", "addopts=", "test_candidate.py::test_value"),
    )

    result = helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)

    assert result["verdict"] == VERDICT_PASS
    assert result["reason"] == "head-passed-base-failed"
    assert "FAILED test_candidate.py::test_value[1]" in result["base_stdout"]


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_pytest_node_identity_requires_the_selected_parameter(prefix):
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    matches = helper["_pytest_node_id_matches_selected"]

    assert matches("tests/test_x.py::test_case", "tests/test_x.py::test_case[param]")
    assert matches("tests/test_x.py::test_case[param]", "tests/test_x.py::test_case[param]")
    assert not matches("tests/test_x.py::test_case[param]", "tests/test_x.py::test_case[other]")
    assert not matches(
        "tests/test_x.py::test_case[param]", "tests/test_x.py::test_case_extra[param]"
    )
    assert not matches("tests/test_x.py::test_case[param]", "tests/test_y.py::test_case[param]")


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_pytest_result_parser_retains_supported_spaced_and_punctuated_node_ids(prefix):
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    node = 'tests/тест file.py::test_Δ[has - space, "quote"(brace){%}\\path]'

    assert helper["_pytest_results_from_output"](
        f"{node} FAILED [100%]\nFAILED {node} - assert left - right\nPASSED {node}"
    ) == [("FAILED", node), ("FAILED", node), ("PASSED", node)]
    for percent in (0, 9, 50, 100):
        assert helper["_pytest_results_from_output"](f"{node} FAILED [ {percent}%]") == [
            ("FAILED", node)
        ]
    assert helper["_pytest_results_from_output"]("FAILED unrelated diagnostic") == []
    opaque = "tests/test_x.py::test_case[unbalanced]tail["
    assert helper["_pytest_results_from_output"](f"FAILED {opaque}") == [("FAILED", opaque)]
    ambiguous = "tests/test_x.py::test_case[has] - other]"
    assert helper["_pytest_results_from_output"](f"FAILED {ambiguous}") == []
    assert helper["_pytest_results_from_output"](
        f"FAILED {ambiguous} - assert left - right\n{ambiguous} FAILED"
    ) == [("FAILED", ambiguous)]


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
@pytest.mark.parametrize("selected_passes_base", [True, False])
def test_real_collection_error_requires_selected_failed_node(
    tmp_path, prefix, selected_passes_base
):
    """Only a selected FAILED node can prove RED alongside real collection failure."""
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text("VALUE = 0\n", encoding="utf-8")
    (repo / "test_unrelated.py").write_text("import missing_only_on_base\n", encoding="utf-8")
    base = _commit(repo, "base behavior with unrelated collection error")
    (repo / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "test_unrelated.py").unlink()
    expected = 0 if selected_passes_base else 1
    assertion = "app.VALUE in (0, 1)" if selected_passes_base else "app.VALUE == expected"
    (repo / "test_candidate.py").write_text(
        "import pytest\nimport app\n\n"
        f"@pytest.mark.parametrize('expected', [{expected}])\n"
        "def test_value(expected):\n"
        f"    assert {assertion}\n",
        encoding="utf-8",
    )
    _commit(repo, "candidate implementation and parametrized test")
    spec = helper["DeliberateBreakSpec"](
        "test_candidate.py::test_value",
        "test_candidate.py",
        "app.py",
        (
            sys.executable,
            "-m",
            "pytest",
            "-v",
            "-o",
            "addopts=",
            "--continue-on-collection-errors",
            ".",
        ),
    )

    result = helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)

    assert "ERROR collecting" in result["base_stdout"] + result["base_stderr"]
    if selected_passes_base:
        assert result["verdict"] == VERDICT_BROKEN
        assert result["reason"] == "base-test-did-not-run"
        assert "test_candidate.py::test_value[0] PASSED" in result["base_stdout"]
    else:
        assert result["verdict"] == VERDICT_PASS
        assert result["reason"] == "head-passed-base-failed"
        assert "test_candidate.py::test_value[1] FAILED" in result["base_stdout"]


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_collection_error_accepts_explicit_parametrized_node_with_space_and_punctuation(
    tmp_path, prefix
):
    """A selected parametrized ID remains exact when pytest prints its supported spacing."""
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text("VALUE = 0\n", encoding="utf-8")
    (repo / "test_unrelated.py").write_text("import missing_only_on_base\n", encoding="utf-8")
    base = _commit(repo, "base behavior with unrelated collection error")
    (repo / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    (repo / "test_unrelated.py").unlink()
    (repo / "test_candidate.py").write_text(
        "import pytest\nimport app\n\n"
        "@pytest.mark.parametrize('expected', [1], ids=['has space,case-1'])\n"
        "def test_value(expected):\n"
        "    assert app.VALUE == expected\n",
        encoding="utf-8",
    )
    _commit(repo, "candidate implementation and spaced parametrized test")
    selected = "test_candidate.py::test_value[has space,case-1]"
    spec = helper["DeliberateBreakSpec"](
        selected,
        "test_candidate.py",
        "app.py",
        (
            sys.executable,
            "-m",
            "pytest",
            "-v",
            "-o",
            "addopts=",
            "--continue-on-collection-errors",
            ".",
        ),
    )

    result = helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)

    assert result["verdict"] == VERDICT_PASS
    assert result["reason"] == "head-passed-base-failed"
    assert f"{selected} FAILED" in result["base_stdout"]


@pytest.mark.parametrize("prefix", ["", "templates/consumer-repo/"])
def test_collection_error_accepts_padded_verbose_progress_without_summary(tmp_path, prefix):
    """A selected failure before the final item has pytest's padded progress token."""
    helper = runpy.run_path(
        str(Path(__file__).resolve().parents[2] / prefix / "scripts/check_deliberate_break.py")
    )
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    (repo / "app.py").write_text("VALUE = 0\n", encoding="utf-8")
    (repo / "conftest.py").write_text(
        "def pytest_report_header(config):\n" "    return 'ERROR collecting simulated.py'\n",
        encoding="utf-8",
    )
    (repo / "test_candidate.py").write_text(
        "import pytest\nimport app\n\n"
        "@pytest.mark.parametrize('expected', [1], ids=['chosen'])\n"
        "def test_value(expected):\n    assert app.VALUE == expected\n\n"
        "def test_after():\n    assert True\n",
        encoding="utf-8",
    )
    base = _commit(repo, "base behavior with padded-progress test")
    (repo / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    _commit(repo, "candidate implementation and padded-progress test")
    selected = "test_candidate.py::test_value[chosen]"
    spec = helper["DeliberateBreakSpec"](
        selected,
        "test_candidate.py",
        "app.py",
        (
            sys.executable,
            "-m",
            "pytest",
            "-v",
            "--no-summary",
            "-o",
            "addopts=",
            "--continue-on-collection-errors",
            ".",
        ),
    )

    result = helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)

    assert result["verdict"] == VERDICT_PASS
    assert result["reason"] == "head-passed-base-failed"
    assert f"{selected} FAILED" in result["base_stdout"]
    assert "[ 50%]" in result["base_stdout"]
    assert "ERROR collecting simulated.py" in result["base_stdout"]
    assert "short test summary" not in result["base_stdout"].lower()


@pytest.mark.parametrize(
    "command",
    [
        ("pytest", "-q"),
        ("/other/venv/bin/python3", "-m", "pytest", "-q"),
        ("uv", "run", "pytest", "-q"),
        ("uv", "run", "--project", "project", "--", "pytest", "-q"),
        ("uv", "run", "--module", "pytest", "-q"),
        ("uv", "run", "python", "-I", "-m", "pytest", "-q"),
    ],
)
@pytest.mark.parametrize("exit_code", [2, 5])
def test_wrapped_pytest_nonexecution_never_proves_red(
    tmp_path, base_proof_helper, monkeypatch, command, exit_code
):
    repo, base, spec = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        "VALUE = 0\n",
        "VALUE = 1\n",
        "def test_value():\n    assert True\n",
    )
    spec = base_proof_helper["DeliberateBreakSpec"](
        spec.test_id, spec.test_file, spec.break_file, (*command, spec.test_id)
    )
    calls = []

    def execute(actual_command, cwd):
        calls.append(actual_command)
        code = 0 if len(calls) == 1 else exit_code
        return subprocess.CompletedProcess(actual_command, code, "no tests ran", "")

    monkeypatch.setitem(
        base_proof_helper["verify_spec"].__globals__, "_run_with_runtime_deps", execute
    )
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    assert calls == [spec.command, spec.command]
    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "base-test-did-not-run"
    assert result["returncode"] == exit_code


@pytest.mark.parametrize("stream", ["stdout", "stderr"])
def test_executed_head_import_failure_with_collection_text_is_behavioral(
    tmp_path, base_proof_helper, stream
):
    repo, base, spec = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        "VALUE = 0\n",
        "VALUE = 1\n",
        "import sys\n"
        "def test_value():\n"
        f"    print('ERROR collecting unrelated.py', file=sys.{stream})\n"
        "    raise ModuleNotFoundError(\"No module named 'candidate_dependency'\")\n",
    )
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    assert result["verdict"] == VERDICT_BROKEN
    assert result["reason"] == "head-test-failed"


@pytest.mark.parametrize("command", [("custom", "-m", "pytest"), ("uv", "run", "custom", "pytest")])
def test_custom_commands_keep_nonzero_contract(base_proof_helper, command):
    assert not base_proof_helper["_is_pytest_command"](command)


@pytest.mark.parametrize("stream", ["stdout", "stderr"])
@pytest.mark.parametrize("exit_code", [1, 5])
def test_real_custom_command_collection_text_preserves_nonzero_contract(
    tmp_path, base_proof_helper, stream, exit_code
):
    executions = tmp_path / "custom-executions.txt"
    repo, base, _ = _base_proof_repo(
        tmp_path,
        base_proof_helper,
        "VALUE = 0\n",
        "VALUE = 1\n",
        "import app, sys\nfrom pathlib import Path\n"
        f'with Path({str(executions)!r}).open("a") as output:\n'
        '    output.write(str(app.VALUE) + "\\n")\n'
        "if app.VALUE != 1:\n"
        f'    print("ERROR collecting custom output", file=sys.{stream})\n'
        f"    print(\"ModuleNotFoundError: No module named 'diagnostic_only'\", file=sys.{stream})\n"
        f"    sys.exit({exit_code})\n",
    )
    spec = base_proof_helper["DeliberateBreakSpec"](
        "test_candidate.py::test_value",
        "test_candidate.py",
        "app.py",
        (sys.executable, "test_candidate.py"),
    )
    result = base_proof_helper["verify_spec"](spec, base=base, cwd=repo, enforce_tamper=False)
    assert executions.read_text().splitlines() == ["1", "0"]
    assert result["verdict"] == VERDICT_PASS
    assert result["reason"] == "head-passed-base-failed"
