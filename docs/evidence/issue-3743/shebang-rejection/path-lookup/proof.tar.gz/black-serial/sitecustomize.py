"""Run Black's normal per-file formatter serially inside this sandbox."""
import black
import black.concurrency


def reformat_many(sources, fast, write_back, mode, report, **kwargs):
    for source in sorted(sources):
        black.reformat_one(
            source, fast=fast, write_back=write_back, mode=mode, report=report
        )


black.concurrency.reformat_many = reformat_many
