"""Bind the fresh PATH lookup validation without replacing historical evidence."""
import hashlib
import io
import json
import runpy
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path.cwd()
OUT = Path('/tmp/shebang-path-validation')
EVIDENCE = Path('docs/evidence/issue-3743/shebang-rejection')
DEST = ROOT / EVIDENCE / 'path-lookup'
parse_junit = runpy.run_path(str(ROOT / EVIDENCE / 'replay.py'))['parse_junit']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def outcomes(path):
    result = {}
    for case in parse_junit(path).iter('testcase'):
        key = (case.get('classname'), case.get('name'))
        assert key not in result
        assert not list(case), (key, [child.tag for child in case])
        result[key] = 'PASS'
    return result


baseline = outcomes(OUT / 'baseline.xml')
candidate = outcomes(OUT / 'candidate.xml')
assert len(baseline) == 340 and len(candidate) == 348
assert baseline.keys() <= candidate.keys()
assert all(candidate[node] == value for node, value in baseline.items())
added = sorted(candidate.keys() - baseline.keys())
expected = sorted((
    'tests.scripts.test_check_deliberate_break_shebang_rejection',
    f'{name}[{prefix}]',
) for prefix in ['root', 'template'] for name in runpy.run_path(str(ROOT / EVIDENCE / 'replay.py'))['MUTATIONS'])
assert added == expected
assert len(outcomes(OUT / 'focused.xml')) == 8
assert len(outcomes(OUT / 'replay-parser.xml')) == 7

base_cov = json.loads((OUT / 'baseline.json').read_text())
cand_cov = json.loads((OUT / 'candidate.json').read_text())
assert base_cov['files'].keys() == cand_cov['files'].keys()
deltas = {}
for name, original in base_cov['files'].items():
    current = cand_cov['files'][name]
    assert set(original['executed_lines']) <= set(current['executed_lines'])
    old_branches = set(map(tuple, original['executed_branches']))
    new_branches = set(map(tuple, current['executed_branches']))
    assert old_branches <= new_branches
    assert (set(original['executed_lines']) | set(original['missing_lines'])) == (
        set(current['executed_lines']) | set(current['missing_lines']))
    assert (old_branches | set(map(tuple, original['missing_branches']))) == (
        new_branches | set(map(tuple, current['missing_branches'])))
    assert original['excluded_lines'] == current['excluded_lines'] == []
    for field in ['num_statements', 'num_branches', 'excluded_lines']:
        assert original['summary'][field] == current['summary'][field]
    deltas[name] = {
        'added_lines': sorted(set(current['executed_lines']) - set(original['executed_lines'])),
        'added_branches': sorted(new_branches - old_branches),
        'removed_lines': [], 'removed_branches': [],
    }
assert base_cov['totals']['num_statements'] == cand_cov['totals']['num_statements'] == 1244
assert base_cov['totals']['num_branches'] == cand_cov['totals']['num_branches'] == 556
comparison = {
    'baseline_pass': len(baseline), 'candidate_pass': len(candidate),
    'added_nodes': added, 'removed_nodes': [], 'changed_old_outcomes': [],
    'deltas': deltas, 'baseline_totals': base_cov['totals'],
    'candidate_totals': cand_cov['totals'],
}
write_json(OUT / 'comparison.json', comparison)

proof = Path('/tmp/fresh-shebang-rejection-proof')
mutation = json.loads((proof / 'summary.json').read_text())
assert mutation['pair_count'] == 8
assert sorted(tuple(pair['node'].split('::')) for pair in mutation['pairs']) == sorted(
    ('tests/scripts/test_check_deliberate_break_shebang_rejection.py', name) for _, name in expected)
for pair in mutation['pairs']:
    prefix = 'root' if pair['source'] == 'scripts/check_deliberate_break.py' else 'template'
    name = pair['node'].split('::')[1].split('[')[0]
    directory = proof / f'{prefix}-{name}'
    original = (directory / 'original.py').read_bytes()
    restored = (directory / 'restored.py').read_bytes()
    mutant = (directory / 'mutant.py').read_bytes()
    assert original == restored == (ROOT / pair['source']).read_bytes()
    assert mutant != original
    assert digest(original) == pair['original_sha256'] == pair['restored_sha256']
    assert digest(mutant) == pair['mutant_sha256']
    for phase, exit_code in [('red', 1), ('green', 0)]:
        assert pair[phase]['exit'] == exit_code
        cases = list(parse_junit(directory / f'{phase}.xml').iter('testcase'))
        assert len(cases) == 1
        assert cases[0].get('name') == pair['node'].split('::')[1]
        assert cases[0].get('classname') == pair['node'].split('::')[0][:-3].replace('/', '.')
        assert not cases[0].findall('error') and not cases[0].findall('skipped')
        failures = cases[0].findall('failure')
        assert len(failures) == (1 if phase == 'red' else 0)
        if failures:
            assert 'AssertionError' in ''.join(failures[0].itertext())
reuse = json.loads((OUT / 'reuse-audit.json').read_text())
assert reuse['exit'] != 0 and reuse['file_count'] == 93 and reuse['all_bytes_unchanged']
for name, sha in reuse['hashes'].items():
    assert digest((proof / name).read_bytes()) == sha

original_summary = json.loads((ROOT / EVIDENCE / 'summary.json').read_text())
with tarfile.open(ROOT / EVIDENCE / 'proof.tar.gz') as archive:
    historical = json.load(archive.extractfile('manifest.json'))
    assert len(historical) == 122
    for name, binding in historical.items():
        data = archive.extractfile(name).read()
        assert digest(data) == binding['sha256'] and len(data) == binding['bytes']
assert digest((ROOT / EVIDENCE / 'proof.tar.gz').read_bytes()) == original_summary['archive']['sha256']
for name in ['scripts/check_deliberate_break.py', 'templates/consumer-repo/scripts/check_deliberate_break.py']:
    data = (ROOT / name).read_bytes()
    assert data == subprocess.check_output(['git', 'show', f"{original_summary['base_head']}:{name}"])
    assert digest(data) == original_summary['input_sha256'][name]

members = {}
for file in OUT.rglob('*'):
    if file.is_file() and not file.name.endswith('.pyc') and 'diagnostic' not in file.name:
        members[str(file.relative_to(OUT))] = file.read_bytes()
for file in proof.rglob('*'):
    if file.is_file():
        members['mutation-proof/' + str(file.relative_to(proof))] = file.read_bytes()
paths = list(original_summary['input_sha256']) + json.loads((OUT / 'modules.json').read_text())
paths.append('tests/scripts/test_shebang_rejection_replay.py')
for name in paths:
    members['current-inputs/' + name] = (ROOT / name).read_bytes()
for name in ['scripts/check_deliberate_break.py', 'templates/consumer-repo/scripts/check_deliberate_break.py', 'tests/scripts/test_check_deliberate_break_shebang_rejection.py']:
    assert members['mutation-proof/inputs/' + name] == (ROOT / name).read_bytes()
assert members['mutation-proof/inputs/replay.py'] == (ROOT / EVIDENCE / 'replay.py').read_bytes()
manifest = {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(members.items())}
members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
DEST.mkdir(exist_ok=True)
archive_path = DEST / 'proof.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    assert set(archive.getnames()) == set(members)
    for name, binding in manifest.items():
        data = archive.extractfile(name).read()
        assert digest(data) == binding['sha256'] and len(data) == binding['bytes']
summary = {
    'base_head': original_summary['base_head'],
    'validated_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'python': sys.executable, 'historical_interpreter_available': False,
    'production_changed': False, 'production_helpers_equal': True,
    'historical_proof_sha256': original_summary['archive']['sha256'],
    'proof_pairs': 8, 'proof_reuse_files_unchanged': 93, 'parser_tests_pass': 7,
    'comparison': comparison,
    'input_sha256': {name: digest((ROOT / name).read_bytes()) for name in paths},
    'archive': {'path': 'proof.tar.gz', 'sha256': digest(archive_path.read_bytes()),
                'bytes': archive_path.stat().st_size, 'verified_manifest_members': len(manifest),
                'manifest_sha256': digest(members['manifest.json'])},
    'validation': {name: json.loads((OUT / f'{name}-command.json').read_text()) for name in ['black', 'ruff', 'template', 'diffcheck']},
}
assert all(record['exit'] == 0 for record in summary['validation'].values())
write_json(DEST / 'summary.json', summary)
print(json.dumps({'archive_members': len(manifest), 'baseline': len(baseline), 'candidate': len(candidate), 'deltas': deltas}, indent=2))
