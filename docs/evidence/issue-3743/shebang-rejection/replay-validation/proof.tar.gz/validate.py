"""Collect exact receipts for the focused replay regression chunk."""

import hashlib
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path.cwd()
OUT = Path('/tmp/shebang-replay-validation')
EVIDENCE = Path('docs/evidence/issue-3743/shebang-rejection')


def record(name, argv, extra_env=None, expected=0):
    env = os.environ.copy()
    env.update(extra_env or {})
    completed = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=900)
    (OUT / (name + '.stdout')).write_bytes(completed.stdout)
    (OUT / (name + '.stderr')).write_bytes(completed.stderr)
    receipt = {'argv': argv, 'cwd': str(ROOT), 'exit': completed.returncode,
               'env_overrides': extra_env or {}}
    (OUT / (name + '-command.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, completed.returncode, flush=True)
    if completed.returncode != expected:
        print(completed.stdout.decode(), completed.stderr.decode(), flush=True)
        raise RuntimeError(name)
    return receipt


mode = sys.argv[1]
if mode == 'tests':
    record('focused', [sys.executable, '-m', 'pytest',
           'tests/scripts/test_check_deliberate_break_shebang_rejection.py', '-q', '-o',
           'addopts=', '-m', 'not slow', '--junitxml=' + str(OUT / 'focused.xml')])
    record('replay-tests', [sys.executable, '-m', 'pytest',
           'tests/scripts/test_shebang_rejection_replay.py', '-q', '-o', 'addopts=',
           '-m', 'not slow', '--basetemp=' + str(OUT / 'pytest-tmp'),
           '--junitxml=' + str(OUT / 'replay-tests.xml')])
elif mode in ('coverage', 'baseline', 'candidate'):
    with tarfile.open(ROOT / EVIDENCE / 'path-lookup/proof.tar.gz') as archive:
        modules = json.load(archive.extractfile('modules.json'))
    (OUT / 'modules.json').write_text(json.dumps(modules, indent=2) + '\n')
    for phase in (('baseline', 'candidate') if mode == 'coverage' else (mode,)):
        selected = modules + (['tests/scripts/test_check_deliberate_break_shebang_rejection.py']
                              if phase == 'candidate' else [])
        common = ['--rcfile=' + str(EVIDENCE / 'coverage.ini'),
                  '--data-file=' + str(OUT / (phase + '.coverage'))]
        record(phase, [sys.executable, '-m', 'coverage', 'run', *common, '-m', 'pytest',
               *selected, '-q', '-o', 'addopts=', '-m', 'not slow',
               '--junitxml=' + str(OUT / (phase + '.xml'))])
        record(phase + '-json', [sys.executable, '-m', 'coverage', 'json', *common,
               '-o', str(OUT / (phase + '.json'))])
        record(phase + '-report', [sys.executable, '-m', 'coverage', 'report', *common,
               '--show-missing'])
elif mode == 'checks':
    record('black', ['black', '--check', '--line-length', '100', '--exclude',
           r'(\.workflows-lib|node_modules)', '.'],
           {'PYTHONPATH': str(OUT / 'black-serial')})
    record('ruff', ['ruff', 'check', 'tests/scripts/test_check_deliberate_break_shebang_rejection.py',
           'tests/scripts/test_shebang_rejection_replay.py', str(EVIDENCE / 'replay.py')])
    record('template', [sys.executable, 'scripts/validate_template_completeness.py', '--strict'],
           {'GITHUB_STEP_SUMMARY': str(OUT / 'template-summary.md')})
    record('diffcheck', ['git', 'diff', '--check'])
elif mode == 'replay':
    proof = OUT / 'mutation-proof'
    argv = [sys.executable, str(EVIDENCE / 'replay.py'), '--output', str(proof)]
    record('replay', argv)
    before = {str(p.relative_to(proof)): p.read_bytes() for p in proof.rglob('*') if p.is_file()}
    record('reuse', argv, expected=1)
    after = {str(p.relative_to(proof)): p.read_bytes() for p in proof.rglob('*') if p.is_file()}
    assert before == after and len(before) == 93
    audit = {'exit': 1, 'file_count': len(before), 'all_bytes_unchanged': True,
             'hashes': {p: hashlib.sha256(data).hexdigest() for p, data in before.items()}}
    (OUT / 'reuse-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
else:
    raise ValueError(mode)
