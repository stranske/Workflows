Related #3743. This is one bounded test-only increment; the broader coverage issue stays open.

## Summary

Malformed pytest launchers must not authorize a Python import probe or dependency repair. Add eight root/template cases using real executable files and PATH lookup for empty launchers, missing shebangs, unclosed quotes and unresolved env Python interpreters. Production helpers and all historical proof remain unchanged.

## Tasks and acceptance

- [x] Each malformed launcher returns no probe, is not a managed pytest runtime and cannot report probe success.
- [x] Eight exact module/test/parameter mutation controls fail with one assertion and no errors/skips, then pass after byte-identical restoration.
- [x] Replay reuse fails before mutation, preserving all 93 existing proof files.
- [x] Matched coverage: 340 baseline PASS / 348 candidate PASS, exactly eight additions, zero removed/changed old outcomes or covered-line/branch regressions.
- [x] Same 1244 statements / 556 branches / zero exclusions. Gains eight template lines and five branches (one root, four template).
- [x] Historical proof verifies 122 member bindings and PATH proof verifies 151; fresh replay-validation proof binds the current source/test/replay inputs.
- [x] Full-repository Black (754 files), focused Ruff, strict template completeness and git diff --check pass.

## Validation

This round adds 14 replay regression cases (21 companion tests total): wrong test/module/parameter, incorrect exits, errors/skips/non-assertion or duplicate results, restoration after failed RED validation, and all eight real mutation pairs followed by reuse rejection before copying or checkout. The eight launcher cases also pass. Fresh receipts and current input bindings are in `docs/evidence/issue-3743/shebang-rejection/replay-validation/`. Full Black checks all 754 files using the previously archived serial adapter; Ruff, strict template completeness and diff checks pass. Production helpers and earlier archives remain unchanged.


Reconciled against commits `3babd920` and `fccc1cc9`: all three implementation tasks are verified. The current tests pass 8 launcher cases and 7 parser cases. Both archives verify (122 historical / 151 PATH-proof member bindings); the PATH archive binds current source/test/replay bytes and confirms 340 baseline / 348 candidate PASS with no coverage regressions. The historical interpreter `/opt/anaconda3/bin/python3` is absent on this runner; fresh checks use `/opt/hostedtoolcache/Python/3.14.8/x64/bin/python`. The literal interpreter-specific acceptance items remain unchecked.


`/opt/anaconda3/bin/python3 -m pytest tests/scripts/test_check_deliberate_break_shebang_rejection.py -q -o addopts=`: 8 PASS.

`/opt/anaconda3/bin/python3 docs/evidence/issue-3743/shebang-rejection/replay.py --output /tmp/fresh-shebang-rejection-proof`: eight assertion RED1 / restored GREEN0 controls. Reuse was rejected with all existing bytes unchanged.

See `docs/evidence/issue-3743/shebang-rejection/README.md`, `summary.json` and `proof.tar.gz` for exact matched commands, raw JUnit/coverage/console receipts and source bytes. Archive SHA256: `83bf8bec764c0630a08c661876eaf7a24b5a7b27e1ee2875f6f96565ff281fae`.

Selection uses the last-400 scripts-touching repair-subject/churn proxy: this helper ranked first (74 repair-subject matches / 83 touches). That proxy is not a verified escaped-defect count.

## Handoff

Ready for review. Matching keepalive owns hosted CI and review after opening. Closer must check unchanged head, complete current topology, full active threads and seven-minute floor before guarded delivery and actual verify:compare. This is helper-scope evidence, not repository-wide 90%, provider PASS, deployment or source closeout. No production/source-engineering prerequisite or campaign allowance was used.

<!-- pr-preamble:start -->
<!-- meta:issue:3743 -->
> **Source:** Issue #3743

Closes #3743

<!-- pr-preamble:end -->

<!-- auto-status-summary:start -->
## Automated Status Summary
#### Scope
Continue the broader coverage initiative with one test-only malformed-launcher rejection chunk. Fresh last-400 scripts-touching history ranks check_deliberate_break.py first (74 repair-subject proxy matches / 83 touches, not verified escaped defects). Matched current-main helper coverage leaves malformed and unresolved shebang rejection unexecuted in the template copy. Such launchers must never authorize an import probe or dependency repair.

<!-- Updated WORKFLOW_OUTPUTS.md context:start -->
## Context for Agent

### Related Issues/PRs
- [stranske/Workflows#3865](https://github.com/stranske/Workflows/issues/3865)
- [stranske/Workflows#3832](https://github.com/stranske/Workflows/issues/3832)
- [#3743](https://github.com/stranske/Workflows/issues/3743)
- [#3856](https://github.com/stranske/Workflows/issues/3856)
- [#3865](https://github.com/stranske/Workflows/issues/3865)
- [#3832](https://github.com/stranske/Workflows/issues/3832)
- [#948](https://github.com/stranske/Workflows/issues/948)
- [#389](https://github.com/stranske/Workflows/issues/389)
- [#3820](https://github.com/stranske/Workflows/issues/3820)
- [#3814](https://github.com/stranske/Workflows/issues/3814)
- [#3808](https://github.com/stranske/Workflows/issues/3808)
<!-- Updated WORKFLOW_OUTPUTS.md context:end -->

#### Tasks
- [x] Add real executable-file/PATH cases for empty pytest files, missing shebangs, unclosed shebang quotes and unresolved env Python interpreters; assert absent probe, unmanaged runtime and unsuccessful probe for root/template.
- [x] Add a replay producing eight exact named assertion RED/restored GREEN pairs on private production copies; validate test module/name, exits, absence of errors/skips and byte-identical restoration; reject output reuse before mutation.
- [x] Archive matched baseline/candidate JUnit and coverage JSON, exact commands/cwd/exits, source/test/replay bytes and hashes, and a lossless member manifest.

#### Acceptance criteria
- [ ] `/opt/anaconda3/bin/python3 -m pytest tests/scripts/test_check_deliberate_break_shebang_rejection.py -q -o addopts=` exits 0 with 8 PASS, no errors/skips. Raw JUnit is retained in docs/evidence/issue-3743/shebang-rejection/proof.tar.gz.
- [ ] `/opt/anaconda3/bin/python3 docs/evidence/issue-3743/shebang-rejection/replay.py --output /tmp/fresh-shebang-rejection-proof` exits 0 after eight exact named assertion RED exit1/restored GREEN exit0 pairs, matching original/restored bytes. Reusing the output exits nonzero before mutation and preserves every proof file. Raw receipts/JUnit/source bytes are archived.
- [x] Identical baseline helper modules versus those modules plus only the new module have exactly eight added passing nodes, zero removed/changed old outcomes and zero covered-line/branch regressions, with identical statement/branch universes and zero exclusions. Exact counts/commands and coverage delta are retained in summary.json and the archive.
- [x] Full-repository Black, focused Ruff, strict template completeness and git diff --check exit 0. Production root/template helpers remain equal and unchanged from base; historical evidence remains unchanged. Archive member hashes/lengths and current source/test/replay input bindings verify.

<!-- auto-status-summary:end -->
