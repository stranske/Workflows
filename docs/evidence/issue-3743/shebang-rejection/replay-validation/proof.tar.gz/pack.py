"""Verify and archive replay regression receipts without rewriting earlier proof."""

import hashlib
import io
import json
import runpy
import subprocess
import tarfile
from pathlib import Path

ROOT = Path.cwd()
OUT = Path('/tmp/shebang-replay-validation')
EVIDENCE = Path('docs/evidence/issue-3743/shebang-rejection')
DEST = ROOT / EVIDENCE / 'replay-validation'
module = runpy.run_path(str(ROOT / EVIDENCE / 'replay.py'))
parse_junit = module['parse_junit']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(name):
    return json.loads((OUT / name).read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def outcomes(name):
    cases = list(parse_junit(OUT / name).iter('testcase'))
    assert all(not list(case) for case in cases)
    result = {(case.get('classname'), case.get('name')): 'PASS' for case in cases}
    assert len(result) == len(cases)
    return result


assert len(outcomes('focused.xml')) == 8
assert len(outcomes('replay-tests.xml')) == 21
baseline = outcomes('baseline.xml')
candidate = outcomes('candidate.xml')
assert len(baseline) == 340 and len(candidate) == 348
assert baseline.items() <= candidate.items()
expected = {
    ('tests.scripts.test_check_deliberate_break_shebang_rejection', f'{name}[{case}]')
    for name in module['MUTATIONS'] for case in ('root', 'template')
}
assert candidate.keys() - baseline.keys() == expected
old_cov = read_json('baseline.json')
new_cov = read_json('candidate.json')
assert old_cov['files'].keys() == new_cov['files'].keys()
deltas = {}
for name, old in old_cov['files'].items():
    new = new_cov['files'][name]
    delta = {}
    for kind in ('lines', 'branches'):
        def values(record, status):
            data = record[status + '_' + kind]
            return set(map(tuple, data)) if kind == 'branches' else set(data)
        old_executed = values(old, 'executed')
        new_executed = values(new, 'executed')
        assert old_executed <= new_executed
        assert old_executed | values(old, 'missing') == new_executed | values(new, 'missing')
        delta['added_' + kind] = sorted(new_executed - old_executed)
        delta['removed_' + kind] = []
    assert old['excluded_lines'] == new['excluded_lines'] == []
    for field in ('num_statements', 'num_branches', 'excluded_lines'):
        assert old['summary'][field] == new['summary'][field]
    deltas[name] = delta
assert old_cov['totals']['num_statements'] == new_cov['totals']['num_statements'] == 1244
assert old_cov['totals']['num_branches'] == new_cov['totals']['num_branches'] == 556
comparison = {
    'baseline_pass': len(baseline), 'candidate_pass': len(candidate),
    'added_nodes': sorted(expected), 'removed_nodes': [], 'changed_old_outcomes': [],
    'deltas': deltas, 'baseline_totals': old_cov['totals'], 'candidate_totals': new_cov['totals'],
}
write_json(OUT / 'comparison.json', comparison)

proof = OUT / 'mutation-proof'
pairs = read_json('mutation-proof/summary.json')
assert pairs['pair_count'] == len(pairs['pairs']) == 8
assert {pair['node'] for pair in pairs['pairs']} == {
    module['TEST'] + '::' + name for _, name in expected
}
for pair in pairs['pairs']:
    case = 'root' if pair['source'] == module['HELPER'] else 'template'
    name = pair['node'].split('::')[1].split('[')[0]
    directory = proof / f'{case}-{name}'
    original = (directory / 'original.py').read_bytes()
    assert original == (directory / 'restored.py').read_bytes() == (ROOT / pair['source']).read_bytes()
    assert digest(original) == pair['original_sha256'] == pair['restored_sha256']
    mutant = (directory / 'mutant.py').read_bytes()
    assert mutant != original and digest(mutant) == pair['mutant_sha256']
    for phase, exit_code in (('red', 1), ('green', 0)):
        assert pair[phase]['exit'] == exit_code
        cases = list(parse_junit(directory / (phase + '.xml')).iter('testcase'))
        assert len(cases) == 1
        case_result = cases[0]
        assert case_result.get('name') == pair['node'].split('::')[1]
        assert case_result.get('classname') == module['TEST'][:-3].replace('/', '.')
        assert not case_result.findall('error') and not case_result.findall('skipped')
        failures = case_result.findall('failure')
        assert len(failures) == (phase == 'red')
        if failures:
            assert 'AssertionError' in ''.join(failures[0].itertext())
reuse = read_json('reuse-audit.json')
assert reuse['exit'] == 1 and reuse['file_count'] == 93 and reuse['all_bytes_unchanged']
for name, sha in reuse['hashes'].items():
    assert digest((proof / name).read_bytes()) == sha

historical = {}
for relative, count in (('proof.tar.gz', 122), ('path-lookup/proof.tar.gz', 151)):
    path = ROOT / EVIDENCE / relative
    assert path.read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:' + str(EVIDENCE / relative)])
    with tarfile.open(path) as archive:
        manifest = json.load(archive.extractfile('manifest.json'))
        assert len(manifest) == count
        assert set(archive.getnames()) == set(manifest) | {'manifest.json'}
        for name, binding in manifest.items():
            data = archive.extractfile(name).read()
            assert len(data) == binding['bytes'] and digest(data) == binding['sha256']
    historical[relative] = {'sha256': digest(path.read_bytes()), 'verified_members': count}
base_head = json.loads((ROOT / EVIDENCE / 'summary.json').read_text())['base_head']
source_paths = [module['HELPER'], 'templates/consumer-repo/' + module['HELPER']]
for name in source_paths:
    assert (ROOT / name).read_bytes() == subprocess.check_output(['git', 'show', base_head + ':' + name])
assert (ROOT / source_paths[0]).read_bytes() == (ROOT / source_paths[1]).read_bytes()

validation = {name: read_json(name + '-command.json') for name in ('black', 'ruff', 'template', 'diffcheck')}
assert all(receipt['exit'] == 0 for receipt in validation.values())
inputs = source_paths + [module['TEST'], str(EVIDENCE / 'replay.py'), str(EVIDENCE / 'coverage.ini'),
                        'tests/scripts/test_shebang_rejection_replay.py'] + read_json('modules.json')
for name in inputs:
    destination = OUT / 'current-inputs' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((ROOT / name).read_bytes())
for name in source_paths + [module['TEST']]:
    assert (proof / 'inputs' / name).read_bytes() == (ROOT / name).read_bytes()
assert (proof / 'inputs/replay.py').read_bytes() == (ROOT / EVIDENCE / 'replay.py').read_bytes()

members = {
    str(path.relative_to(OUT)): path.read_bytes()
    for path in OUT.rglob('*')
    if path.is_file() and not path.is_symlink() and path.suffix != '.pyc'
}
manifest = {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(members.items())}
members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
DEST.mkdir(exist_ok=True)
archive_path = DEST / 'proof.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    assert set(archive.getnames()) == set(members)
    for name, binding in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == binding['bytes'] and digest(data) == binding['sha256']
summary = {
    'validated_parent_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'base_head': base_head, 'python': read_json('focused-command.json')['argv'][0],
    'historical_interpreter_available': Path('/opt/anaconda3/bin/python3').exists(),
    'focused_pass': 8, 'replay_tests_pass': 21, 'new_replay_regression_cases': 14,
    'proof_pairs': 8, 'proof_reuse_files_unchanged': 93,
    'production_changed': False, 'production_helpers_equal': True,
    'comparison': comparison, 'historical_archives': historical,
    'input_sha256': {name: digest((ROOT / name).read_bytes()) for name in inputs},
    'archive': {'path': 'proof.tar.gz', 'sha256': digest(archive_path.read_bytes()),
                'bytes': archive_path.stat().st_size, 'verified_manifest_members': len(manifest),
                'manifest_sha256': digest(members['manifest.json'])},
    'validation': validation,
    'runner_adaptations': [
        'The historical /opt/anaconda3/bin/python3 interpreter is unavailable.',
        'The archived Black serial adapter uses normal per-file formatting checks; parallel worker completion hangs.',
        'GITHUB_STEP_SUMMARY points into /tmp because the inherited runner path is read-only.',
    ],
    'archive_selection': 'All regular validation files except derived .pyc caches; symlinks are omitted.',
}
write_json(DEST / 'summary.json', summary)
print(json.dumps({'archive_members': len(manifest), 'comparison': comparison, 'archive': summary['archive']}, indent=2))
