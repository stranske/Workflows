"""Exercise the matched comparator against retained reports and corrupt private copies."""

import json
import runpy
import shutil
import sys
import tarfile
import tempfile
from pathlib import Path

root = Path('/home/runner/work/Workflows/Workflows')
driver = runpy.run_path(str(root / 'docs/evidence/issue-3743/runtime-health/measure.py'))
rows = []
with tempfile.TemporaryDirectory(prefix='collector-controls-') as temporary:
    original = Path(temporary) / 'original'
    original.mkdir()
    with tarfile.open(root / 'docs/evidence/issue-3743/runtime-health/proof.tar.gz') as archive:
        for phase in ('baseline', 'candidate'):
            for kind in ('coverage.json', 'junit.xml'):
                name = f'{phase}-{kind}'
                (original / name).write_bytes(archive.extractfile('matched/' + name).read())
        for phase in ('runtime-health', 'current-repair'):
            name = f'{phase}-junit.xml'
            (original / name).write_bytes(archive.extractfile(name).read())
    driver['compare'](original)
    rows.append({'control': 'retained-valid-matched-packet', 'accepted': True})
    for name in ('line-regression', 'branch-regression', 'universe-drift', 'old-skip',
                 'wrong-new-node', 'duplicate-node', 'short-suite', 'suite-error', 'xml-entity'):
        private = Path(temporary) / name
        shutil.copytree(original, private)
        candidate = private / 'candidate-coverage.json'
        data = json.loads(candidate.read_text())
        file = data['files'][driver['SOURCE']]
        baseline = json.loads((private / 'baseline-coverage.json').read_text())['files'][driver['SOURCE']]
        if name == 'line-regression':
            file['executed_lines'].remove(baseline['executed_lines'][0])
        elif name == 'branch-regression':
            file['executed_branches'].remove(baseline['executed_branches'][0])
        elif name == 'universe-drift':
            file['summary']['num_statements'] += 1
        candidate.write_text(json.dumps(data))
        report = private / 'candidate-junit.xml'
        text = report.read_text()
        if name == 'old-skip':
            start = text.index('<testcase ')
            end = text.index('/>', start)
            text = text[:end] + '><skipped/></testcase>' + text[end+2:]
        elif name == 'wrong-new-node':
            text = text.replace('[root-healthy]', '[root-unexpected]')
        elif name in ('duplicate-node', 'short-suite'):
            start = text.index('<testcase ')
            end = text.index('/>', start) + 2
            text = text[:end] + text[start:end] + text[end:] if name == 'duplicate-node' else text[:start] + text[end:]
        elif name == 'suite-error':
            text = text.replace('errors="0"', 'errors="1"', 1)
        elif name == 'xml-entity':
            text = '<!DOCTYPE testsuites [<!ENTITY injected "bad">]><testsuites>&injected;</testsuites>'
        report.write_text(text)
        try:
            driver['compare'](private)
        except Exception as error:
            rows.append({'control': name, 'rejected': True, 'error': type(error).__name__, 'reason': str(error)})
        else:
            raise RuntimeError(f'Corrupt proof accepted: {name}')
Path(sys.argv[1]).write_text(json.dumps(rows, indent=2) + '\n')
print(f'Valid packet accepted; {len(rows)-1} corrupt private packets rejected')
