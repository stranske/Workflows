"""Append current receipts without rewriting any historical decoded member."""

import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path('/home/runner/work/Workflows/Workflows')
base = root / 'docs/evidence/issue-3743/runtime-health'
out = Path('/tmp/runtime-health-validation-3838')
measurement = Path('/tmp/runtime-health-measure-3838')
replay = Path('/tmp/runtime-health-replay-3838')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

old_manifest = json.loads((out/'previous-manifest.json').read_text())
comparison = json.loads((measurement/'comparison.json').read_text())
assert comparison['baseline_tests']==304 and comparison['candidate_tests']==312
members = {}
with tarfile.open(out/'previous-proof.tar.gz') as archive:
    for member in archive.getmembers():
        assert member.isfile()
        data=archive.extractfile(member).read()
        assert digest(data)==old_manifest['decoded_members'][member.name]['sha256']
        members[member.name]=data
for directory,prefix in ((measurement,'collector-measurement'),(replay,'collector-replay'),
                         (out,'collector-validation'),(Path('/tmp/runtime-health-measure-deps'),'collector-dependencies')):
    for path in directory.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            members[prefix+'/'+str(path.relative_to(directory))]=path.read_bytes()
members['collector-validation/measure.py']=(base/'measure.py').read_bytes()
summary=json.loads((out/'previous-summary.json').read_text())
for key in ('baseline','candidate','baseline_tests','candidate_tests','new_nodes','removed_nodes',
            'changed_old_outcomes','covered_line_regressions','covered_branch_regressions',
            'newly_covered_lines','newly_covered_branches','historical_reconciliation'):
    summary[key]=comparison[key]
summary['file_sha256']['docs/evidence/issue-3743/runtime-health/measure.py']=digest((base/'measure.py').read_bytes())
summary['collector']={
    'comparison_member':'collector-measurement/comparison.json',
    'baseline_modules':8, 'candidate_additions':['tests/scripts/test_check_deliberate_break_runtime_health.py'],
    'controls': {'valid_packet_accepted':True,'corrupt_packets_rejected':9},
    'prior_archive_sha256':digest((out/'previous-proof.tar.gz').read_bytes()),
    'preserved_decoded_members':len(old_manifest['decoded_members']),
    'fresh_replay_mutations':8, 'replay_output_reuse_files_unchanged':49,
    'requested_interpreter_available':False,
}
summary['task_reconciliation']={
    'matched_measurement_verified':True,
    'replay_and_reuse_verified':True,
    'production_validation_and_bindings_verified':True,
    'literal_anaconda_runtime_health_verified':False,
    'literal_anaconda_repair_verified':False,
    'remote_publication_blocked':'GitHub write requires approval; approval policy is never',
    'local_reconciliation_member':'collector-validation/task-reconciliation.md',
}
summary['validation']={name:json.loads((out/f'{name}.command.json').read_text())
                       for name in ('black-serial','full-black','focused-ruff','templates','diff-check','collector-controls')}
assert all(row['exit']==0 for row in summary['validation'].values())
write(base/'summary.json',summary)
with tarfile.open(base/'proof.tar.gz','w:gz') as archive:
    for name,data in sorted(members.items()):
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
        archive.addfile(entry,io.BytesIO(data))
files=old_manifest['files'].copy()
files['docs/evidence/issue-3743/runtime-health/measure.py']=digest((base/'measure.py').read_bytes())
files={name:digest((root/name).read_bytes()) for name in files}
manifest={'archive':'proof.tar.gz','stored_sha256':digest((base/'proof.tar.gz').read_bytes()),
          'decoded_members':{name:{'sha256':digest(data),'bytes':len(data)} for name,data in sorted(members.items())},
          'files':files,'preserved_decoded_members':len(old_manifest['decoded_members'])}
write(base/'manifest.json',manifest)
assert digest((base/'proof.tar.gz').read_bytes())==manifest['stored_sha256']
with tarfile.open(base/'proof.tar.gz') as archive:
    assert set(archive.getnames())==set(manifest['decoded_members'])
    for name,binding in manifest['decoded_members'].items():
        data=archive.extractfile(name).read()
        assert digest(data)==binding['sha256'] and len(data)==binding['bytes'],name
for name,value in manifest['files'].items():
    assert digest((root/name).read_bytes())==value,name
historical={name:value for name,value in comparison['file_sha256'].items()
            if name.startswith('docs/evidence/issue-3743/') and not name.startswith('docs/evidence/issue-3743/runtime-health/')}
assert all(digest((root/name).read_bytes())==value for name,value in historical.items())
print(json.dumps({'verified_members':len(members),'preserved_members':len(old_manifest['decoded_members']),
                  'unchanged_historical_files':len(historical)}))
