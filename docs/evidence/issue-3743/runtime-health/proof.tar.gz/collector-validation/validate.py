"""Retain command receipts for validation and replay-output refusal."""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path('/home/runner/work/Workflows/Workflows')
out = Path('/tmp/runtime-health-validation-3838')

def run(name, argv, overrides=None, expected=0):
    env = os.environ.copy()
    env.update(overrides or {})
    result = subprocess.run(argv, cwd=root, env=env, capture_output=True, check=False, timeout=300)
    (out / f'{name}.stdout').write_bytes(result.stdout)
    (out / f'{name}.stderr').write_bytes(result.stderr)
    receipt = {'argv': argv, 'cwd': str(root), 'env': overrides or {}, 'exit': result.returncode}
    (out / f'{name}.command.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if result.returncode != expected:
        raise RuntimeError(f'{name} exited {result.returncode}')
    print(name, result.returncode, flush=True)

def inventory(path):
    return {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*') if p.is_file()}

replay = Path('/tmp/runtime-health-replay-3838')
before = inventory(replay)
source_before = {path: hashlib.sha256((root/path).read_bytes()).hexdigest()
                 for path in ('scripts/check_deliberate_break.py',
                              'templates/consumer-repo/scripts/check_deliberate_break.py')}
run('replay-reuse', [sys.executable, 'docs/evidence/issue-3743/runtime-health/replay.py', '--output', str(replay)], expected=1)
after = inventory(replay)
assert before == after and len(before) == 49
assert all(hashlib.sha256((root/path).read_bytes()).hexdigest() == value for path, value in source_before.items())
(out/'replay-reuse-inventory.json').write_text(json.dumps({'before': before, 'after': after, 'caller': source_before}, indent=2)+'\n')
rows=json.loads((replay/'results.json').read_text())
assert len(rows)==8 and len({r['name'] for r in rows})==8
for row in rows:
    assert row['red']['exit']==1 and row['green']['exit']==0
    assert row['original_sha256']==row['restored_sha256']==source_before[row['source']]
    assert row['mutation_sha256']!=row['original_sha256']
    assert row['test_sha256']==hashlib.sha256((root/'tests/scripts/test_check_deliberate_break_runtime_health.py').read_bytes()).hexdigest()

run('black-serial', [sys.executable, 'docs/evidence/issue-3743/runtime-probes/revalidation/black_serial.py'], {'BLACK_CACHE_DIR': '/tmp/runtime-health-measure-black-cache'})
run('full-black', ['black','--check','--line-length','100','--exclude',r'(\.workflows-lib|node_modules)','.'], {'BLACK_CACHE_DIR': '/tmp/runtime-health-measure-black-cache', 'BLACK_NUM_WORKERS': '1'})
run('focused-ruff', ['ruff','check','tests/scripts/test_check_deliberate_break_runtime_health.py','docs/evidence/issue-3743/runtime-health/replay.py','docs/evidence/issue-3743/runtime-health/measure.py'])
run('templates', [sys.executable,'scripts/validate_template_completeness.py','--strict'], {'GITHUB_STEP_SUMMARY': str(out/'template-summary.md')})
run('diff-check', ['git','diff','--check'])
run('collector-controls', [sys.executable,str(out/'check_collector.py'),str(out/'collector-controls.json')], {'PYTHONPATH': '/tmp/runtime-health-measure-deps'})
