import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path.cwd()
OUT=Path('/tmp/runtime-health-current-receipts')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def nodes(name):
    rows={}
    for case in ET.parse((OUT/'matched' if name in ('baseline','candidate') else OUT)/f'{name}-junit.xml').getroot().iter('testcase'):
        key=f"{case.attrib['classname']}::{case.attrib['name']}"
        assert key not in rows,key
        rows[key]='failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
    return rows

baseline=nodes('baseline'); candidate=nodes('candidate')
old=json.loads((OUT/'previous-runtime-health/summary.json').read_text())
coverage={name:json.loads((OUT/'matched'/f'{name}-coverage.json').read_text())['files']['scripts/check_deliberate_break.py'] for name in ('baseline','candidate')}
b,c=coverage['baseline'],coverage['candidate']
summary={
    'base':old['base'],
    'environment':json.loads((OUT/'environment.json').read_text()),
    'interpreter':json.loads((OUT/'environment.json').read_text())['interpreter'],
    'python':json.loads((OUT/'environment.json').read_text())['python'],
    'baseline':b['summary'],'candidate':c['summary'],
    'baseline_tests':len(baseline),'candidate_tests':len(candidate),
    'new_nodes':sorted(candidate.keys()-baseline.keys()),
    'removed_nodes':sorted(baseline.keys()-candidate.keys()),
    'changed_old_outcomes':{key:[value,candidate.get(key)] for key,value in baseline.items() if value!=candidate.get(key)},
    'covered_line_regressions':sorted(set(b['executed_lines'])-set(c['executed_lines'])),
    'covered_branch_regressions':sorted(set(map(tuple,b['executed_branches']))-set(map(tuple,c['executed_branches']))),
    'newly_covered_lines':sorted(set(c['executed_lines'])-set(b['executed_lines'])),
    'newly_covered_branches':sorted(set(map(tuple,c['executed_branches']))-set(map(tuple,b['executed_branches']))),
    'historical_reconciliation':old['historical_reconciliation'],
    'file_sha256':{name:digest((ROOT/name).read_bytes()) for name in old['file_sha256']},
    'limits':old['limits']+['Requested /opt/anaconda3/bin/python3 is absent; fresh receipts use available Linux Python, with historical macOS packet preserved byte for byte.'],
}
assert len(baseline)==304 and len(candidate)==312
assert all(value=='passed' for value in candidate.values())
assert len(summary['new_nodes'])==8
for name in ['removed_nodes','changed_old_outcomes','covered_line_regressions','covered_branch_regressions']:
    assert not summary[name],(name,summary[name])
assert len(nodes('runtime-health'))==8 and len(nodes('current-repair'))==8
for run in ('runtime-health','current-repair'):
    assert set(nodes(run).values())=={'passed'}
for row in coverage.values():
    assert row['summary']['num_statements']==591,row['summary']
    assert row['summary']['num_branches']==262,row['summary']
    assert row['summary']['excluded_lines']==0,row['summary']
source=(ROOT/'scripts/check_deliberate_break.py').read_bytes()
template=(ROOT/'templates/consumer-repo/scripts/check_deliberate_break.py').read_bytes()
assert source==template
for name in ('scripts/check_deliberate_break.py','templates/consumer-repo/scripts/check_deliberate_break.py'):
    assert (ROOT/name).read_bytes()==subprocess.run(['git','show',f"{summary['base']}:{name}"],capture_output=True,check=True).stdout
summary['production_unchanged']=True; summary['root_template_identical']=True
results=json.loads((OUT/'mutations/results.json').read_text())
assert len(results)==8 and len({row['name'] for row in results})==8
for row in results:
    assert row['red']['exit']==1 and row['green']['exit']==0
    assert row['original_sha256']==row['restored_sha256']==digest(source)
    assert row['mutation_sha256']!=row['original_sha256']
    assert row['test_sha256']==summary['file_sha256']['tests/scripts/test_check_deliberate_break_runtime_health.py']
summary['mutations']=8
historical=json.loads((OUT/'historical-before.json').read_text())
assert all(digest((ROOT/path).read_bytes())==value for path,value in historical.items())
summary['historical_files_unchanged']=len(historical)
(OUT/'historical-after.json').write_text(json.dumps(historical,indent=2)+'\n')
(OUT/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
