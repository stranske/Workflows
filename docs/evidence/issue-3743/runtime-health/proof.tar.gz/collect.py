import hashlib
import json
import os
import platform
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path.cwd()
OUT = Path('/tmp/runtime-health-current-receipts')
ENV = os.environ.copy()
ENV.pop('PYTEST_ADDOPTS', None)

def run(name, argv, expected=0):
    result = subprocess.run(argv, cwd=ROOT, env=ENV, capture_output=True, timeout=300)
    (OUT / f'{name}-console.log').write_bytes(result.stdout + result.stderr)
    (OUT / f'{name}-command.json').write_text(json.dumps({'argv': argv, 'cwd': str(ROOT), 'exit': result.returncode, 'env': {'PYTEST_ADDOPTS': None}}, indent=2) + '\n')
    print(name, 'exit', result.returncode, flush=True)
    if result.returncode != expected:
        print((result.stdout + result.stderr).decode(), flush=True)
        raise SystemExit(1)

(OUT/'environment.json').write_text(json.dumps({'python':sys.version,'interpreter':sys.executable,'platform':platform.platform(),'requested_interpreter_available':Path('/opt/anaconda3/bin/python3').exists()},indent=2)+'\n')
run('runtime-health', [sys.executable,'-m','pytest','tests/scripts/test_check_deliberate_break_runtime_health.py','-q','-o','addopts=','-m','not slow',f'--junitxml={OUT}/runtime-health-junit.xml'])
run('current-repair', [sys.executable,'-m','pytest','tests/scripts/test_check_deliberate_break_repair_failures.py','-q','-o','addopts=','-m','not slow',f'--junitxml={OUT}/current-repair-junit.xml'])
with tarfile.open(OUT/'previous-runtime-health/proof.tar.gz') as archive:
    previous=json.loads(archive.extractfile('baseline-command.json').read())
modules=[arg for arg in previous['argv'] if arg.startswith('tests/')]
for name in ('baseline','candidate'):
    tests=modules+(['tests/scripts/test_check_deliberate_break_runtime_health.py'] if name=='candidate' else [])
    run(name,[sys.executable,'-m','pytest',*tests,'-q','-o','addopts=','-m','not slow','--cov=scripts.check_deliberate_break','--cov-branch','--cov-report=term-missing',f'--cov-report=json:{OUT}/{name}-coverage.json',f'--junitxml={OUT}/{name}-junit.xml'])
run('replay',[sys.executable,'docs/evidence/issue-3743/runtime-health/replay.py','--output',str(OUT/'mutations')])
def hashes():
    return {str(p.relative_to(OUT/'mutations')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'mutations').rglob('*') if p.is_file()}
before=hashes()
run('reuse',[sys.executable,'docs/evidence/issue-3743/runtime-health/replay.py','--output',str(OUT/'mutations')],1)
after=hashes()
assert before==after
(OUT/'reuse-receipt.json').write_text(json.dumps({'before':before,'after':after,'unchanged':True,'files':len(before)},indent=2)+'\n')
