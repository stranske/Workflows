import hashlib
import json
import tarfile
from pathlib import Path

ROOT=Path.cwd(); OUT=Path('/tmp/runtime-health-current-receipts'); DEST=ROOT/'docs/evidence/issue-3743/runtime-health'

def digest(data):
    return hashlib.sha256(data).hexdigest()

summary=json.loads((OUT/'comparison.json').read_text())
validation=json.loads((OUT/'validation-commands.json').read_text())
for name in ('full-black','focused-ruff','templates','diff-check'):
    assert validation[name]['exit']==0,(name,validation[name])
summary['validation']=validation
summary['previous_runtime_health_archive_sha256']=digest((OUT/'previous-runtime-health/proof.tar.gz').read_bytes())
previous=OUT/'previous-runtime-health'
manifest=json.loads((previous/'manifest.json').read_text())
assert digest((previous/'proof.tar.gz').read_bytes())==manifest['stored_sha256']
with tarfile.open(previous/'proof.tar.gz') as archive:
    assert set(archive.getnames())==set(manifest['decoded_members'])
    for name,binding in manifest['decoded_members'].items():
        data=archive.extractfile(name).read()
        assert digest(data)==binding['sha256'] and len(data)==binding['bytes'],name
for name,binding in manifest['files'].items():
    assert digest((previous/Path(name).name).read_bytes())==binding,name
snapshot=OUT/'source-snapshots'; snapshot.mkdir(exist_ok=True)
for name in summary['file_sha256']:
    path=snapshot/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes((ROOT/name).read_bytes())
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'summary.json').write_bytes((DEST/'summary.json').read_bytes())
# Retain all original runtime-health packet bytes inside the replacement archive.
with tarfile.open(DEST/'proof.tar.gz','w:gz') as archive:
    for path in sorted(OUT.rglob('*')):
        if path.is_file(): archive.add(path,arcname=str(path.relative_to(OUT)))
manifest={'archive':'proof.tar.gz','stored_sha256':digest((DEST/'proof.tar.gz').read_bytes()),'decoded_members':{},'files':{}}
with tarfile.open(DEST/'proof.tar.gz') as archive:
    for member in archive.getmembers():
        data=archive.extractfile(member).read()
        manifest['decoded_members'][member.name]={'sha256':digest(data),'bytes':len(data)}
for path in [DEST/'README.md',DEST/'summary.json',DEST/'replay.py',ROOT/'tests/scripts/test_check_deliberate_break_runtime_health.py',ROOT/'scripts/check_deliberate_break.py',ROOT/'templates/consumer-repo/scripts/check_deliberate_break.py']:
    manifest['files'][str(path.relative_to(ROOT))]=digest(path.read_bytes())
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('packaged',len(manifest['decoded_members']),'members; all archived and current file bindings verified')
