import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

root=Path.cwd(); output=Path('/tmp/runtime-health-current-receipts/matched'); output.mkdir(exist_ok=False)
env=os.environ.copy(); env.pop('PYTEST_ADDOPTS',None)
with tarfile.open(output.parent/'previous-runtime-health/proof.tar.gz') as archive:
    receipt=json.loads(archive.extractfile('baseline-command.json').read())
modules=[arg for arg in receipt['argv'] if arg.startswith('tests/')]
for name in ('baseline','candidate'):
    selected=modules+(['tests/scripts/test_check_deliberate_break_runtime_health.py'] if name=='candidate' else [])
    argv=[sys.executable,'-m','pytest',*selected,'-q','-o','addopts=','-m','not slow','--cov=scripts.check_deliberate_break','--cov-branch','--cov-report=term-missing',f'--cov-report=json:{output}/{name}-coverage.json',f'--junitxml={output}/{name}-junit.xml']
    with (output/f'{name}-console.log').open('wb') as console:
        run=subprocess.run(argv,cwd=root,env=env,stdout=console,stderr=subprocess.STDOUT,timeout=300)
    (output/f'{name}-command.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'exit':run.returncode,'env':{'PYTEST_ADDOPTS':None}},indent=2)+'\n')
    print(name,run.returncode,flush=True)
    assert run.returncode==0
