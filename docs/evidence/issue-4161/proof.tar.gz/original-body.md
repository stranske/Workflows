Supersedes #4162. The original terminal writer’s unchanged payload is rehomed to the registry branch for keepalive routing.

## Summary

Adds discriminating tests for the four ranked coverage targets (six commits). No production defect was exposed, so this is test-only.

Baseline note: CI ranked these targets at **212** uncovered statements+branches (whole-suite Gate figure). Local focused suites already cover more than CI attributes for a module in isolation; this PR judges progress against the CI ranking of 212.

## Coverage (focused target suite, branch coverage)

After the latest keepalive deepen commit, focused Miss+BrPart is **3** (about **209** fewer than CI’s 212 ranking; meets the ~180-unit goal). Combined Cover **99.91%**.

| Target | CI uncovered | Cover after | Remaining Miss+BrPart |
| --- | ---: | ---: | ---: |
| `scripts/check_consumer_sync_drift.py` | 69 | 100.00% | 0 |
| `scripts/validate_run_contract.py` | 26 | 100.00% | 0 |
| `scripts/langchain/issue_formatter.py` | 29 | 100.00% | 0 |
| `tools/post_ci_summary.py` | 88 | 99.71% | 3 |
| Combined | 212 | 99.91% | 3 |

### Remaining gaps

- `tools/post_ci_summary.py` line **751** and for-loop exit **748→755** remain dead with the current control flow: the canonical-name loop `break`s on the first unique casefold, so the duplicate `continue` and natural for-exit never run. Covering them would require a production restructure, not more tests.
- Line **732** (jobs Sequence re-check after `job_sources` filtering) is now covered via a mutating `FlipJobs` mapping.

### Tasks
Complete these in order. Mark checkbox done ONLY after implementation is verified:

- [x] "Uncovered units" baseline is CI’s whole-suite ranking (**212**); local focused Miss+BrPart after this pass is **3** (~**209** covered vs CI). Baseline difference documented here.
- [x] Before push: `black --line-length 100` + `ruff check` on every changed test file; whole-tree `black --check --line-length 100 --exclude '(\.workflows-lib|node_modules)' .` passed.
- [x] Verified work committed and pushed on this open PR (partial-or-complete delivery invariant).
- [x] `black --check --line-length 100` / `ruff check` contract re-verified on this push (lane PRs #3962/#3965 failed lint-format on new tests; do not rely on autofix).
- [x] `tools/post_ci_summary.py` import-fallback (lines 22–30): covered via in-process reload with an incomplete `tools` stub.
- [x] `validate_run_contract._safe_evidence_path` escape check (377–378): covered by forcing `Path.is_relative_to` false after resolve succeeds.
- [x] Reachable leftover Miss/BrPart closed (directory rglob non-file skip, absent removals, non-object summary JSON, empty junit body, triage without playbook, non-sequence jobs, non-object tracked vars, non-string evidence_id, partial self-smoke fixtures, empty feedback prompt, non-checkbox placeholders, unresolved bold/colon labels, non-pytest verify hint, nested details depth, mutating jobs Sequence re-check). Remaining 3 are dead arcs in `post_ci_summary` noted above.
- [x] `python3 -m pytest --cov=scripts.check_consumer_sync_drift --cov=scripts.validate_run_contract --cov=scripts.langchain.issue_formatter --cov=tools.post_ci_summary --cov-report=term-missing --cov-branch -m "not slow" tests/scripts/test_check_consumer_sync_drift.py tests/scripts/test_validate_run_contract.py tests/contracts/test_validate_run_contract.py tests/scripts/test_issue_formatter.py tests/test_post_ci_summary.py` — **384 passed**

### Acceptance Criteria

- [ ] New discriminating tests fail when deliberately broken and pass when reverted (break-and-revert recorded below). CI pytest pending on this push.
- [x] Targets’ uncovered statements+branches down by about **209** vs CI’s 212 ranking (goal ~180). Remaining 3 explained above (dead code only).
- [x] Production code unchanged (test-only; no real bug found).
- [x] Ranked targets only; low blast radius; one PR for this chunk.
- [x] Same round contract: ranked by Gate gap order; break-and-revert run for real; no negative-cache workaround; test-only; one logical chunk.

## Validation

- `black --line-length 100` on the four changed test files; `black --check --line-length 100 --exclude '(\.workflows-lib|node_modules)' .` passed
- `ruff check` on the four changed test files passed
- Focused target suite above — 384 passed; combined Cover **99.91%**, Miss+BrPart **3**
- Re-verified this push: `black --line-length 100` + `ruff check` on `tests/test_post_ci_summary.py`; whole-tree `black --check --line-length 100 --exclude '(\.workflows-lib|node_modules)' .` passed

## Break-and-revert proof

Each newly added discriminating test failed when its asserted production behavior was deliberately broken, then passed after reverting:

**First commit**
- drift remote-blob decoding: failed after replacing decoded text with a fixed string
- sync-PR filtering: failed after replacing the `sync/workflows-` prefix check
- issue checklist normalization: failed after discarding checked-item text
- document identity validation: failed after suppressing self-supersession validation
- post-CI required-segment: failed after replacing the queued-state badge

**Keepalive deepen commit**
- `test_default_required_groups_used_when_derivation_is_empty`: failed after making `_load_required_groups` return `[]` instead of `DEFAULT_REQUIRED_JOB_GROUPS`
- `test_main_marks_missing_remote_file_and_header_insensitive_match`: failed after removing the `missing.add(...)` path when a remote blob is absent
- `test_identity_ref_without_colon_fails`: failed after dropping the `":" not in ref` check
- `test_validate_and_refine_tasks_returns_when_tasks_header_missing`: failed after replacing the `StopIteration` early-return with `header_idx = 0`
- `test_collect_triage_returns_empty_when_no_failure_lines`: failed after returning a non-empty sentinel when triage lines are empty

**Import-fallback / escape deepen commit**
- `test_import_fallback_recovers_when_tools_package_is_incomplete`: failed after removing the `sys.path.insert` / re-import recovery block
- `test_import_fallback_reraises_unrelated_module_not_found`: failed after dropping the unrelated-name `raise`
- `test_safe_evidence_path_escape_check_after_resolve`: failed after suppressing the post-resolve escape `report.fail`

**Reachable-gap deepen commit**
- `test_fetch_remote_tree_reports_tree_http_failure`: failed after rewriting the tree-fetch failure message
- `test_response_message_ignores_non_string_message_field`: failed after returning non-string `message` values
- `test_probe_targets_skips_empty_managed_directories`: failed after forcing a section target for empty directories
- `test_document_page_rejects_compact_iso_date_that_normalizes`: failed after disabling the non-canonical `isoformat()` check
- `test_main_self_smoke_returns_via_cli`: failed after making `--self-smoke` return `7`
- `test_parse_sections_keeps_multiline_details_in_preamble`: failed after dropping preamble append inside details blocks
- `test_format_issue_body_falls_back_when_prompt_import_fails`: failed after re-raising `ImportError` instead of falling through
- `test_dedupe_runs_keeps_present_over_absent_and_equal_priority`: failed after always replacing on equal-present ties
- `test_category_states_keep_worse_state_when_later_job_is_weaker`: failed after always overwriting category state

**Reachable Miss/BrPart close commit**
- `test_main_directory_compare_skips_subdir_entries_and_absent_removals`: failed after marking removals obsolete even when absent remotely
- `test_load_prompt_ignores_whitespace_only_feedback`: failed after appending whitespace-only feedback
- `test_load_gate_summary_skips_non_object_json`: failed after appending non-dict JSON payloads
- `test_strip_original_issue_handles_nested_details_outside_fences`: failed after breaking on the first structural details tag (depth>0 path)
- `test_self_smoke_partial_fixtures_skip_missing_files`: failed after enqueueing `valid_run.json` when the file is missing

**Jobs Sequence re-check deepen commit**
- `test_required_segments_skips_jobs_that_stop_being_sequences`: failed with `TypeError: 'int' object is not iterable` after replacing the defensive `continue` with `pass`

Closes #4161

<!-- pr-preamble:start -->
<!-- meta:issue:4161 -->
> **Source:** Issue #4161

Closes #4161

<!-- pr-preamble:end -->

<!-- auto-status-summary:start -->
## Automated Status Summary
#### Scope
Workflows reads 87.40% blended line+branch in CI; reaching 90% needs about 1659 more covered statements+branches. Prioritize fleet's largest gap by far.

The target order below is the Orchestrator's own ranking (escaped defects, then churn, then uncovered mass -- unchanged). Only the bundling is new: earlier rounds spent a whole PR on files with a handful of uncovered statements, so one PR now covers the next ranked targets until it has covered about 180 units.

<!-- Updated WORKFLOW_OUTPUTS.md context:start -->
## Context for Agent

### Related Issues/PRs
- [#3962](https://github.com/stranske/Workflows/issues/3962)
- [#3965](https://github.com/stranske/Workflows/issues/3965)
<!-- Updated WORKFLOW_OUTPUTS.md context:end -->

#### Tasks
- [x] "Uncovered units" here come from the repository's whole CI run (every test file together). One test module's own suite can already cover more than CI's count shows for that module, and CI's figure is the one this PR is judged on: if your baseline differs, say so in the PR body and use CI's number.
- [x] Before you push, run the repository's own formatter and linter on every file you add or change, with the flags its CI `lint-format` and `lint-ruff` jobs use: one unformatted file fails a required check, and waiting for the autofix bot to repair it afterwards has not worked on lane PRs.
- [x] Deliver what you verified. If you cannot reach the goal for ANY reason (a broken local environment, a target you could not finish, the time you had), still open the pull request with the verified work you have, say in its body how far short it is and why, and never leave verified commits or edits unpushed or uncommitted: a partial pull request that merges is worth more than a complete one that never opens, and a worktree left holding work blocks this issue's next dispatch.
- [x] This repository's CI runs `black --check --line-length 100` and `ruff check` over the whole tree (the required `lint-format` job): run `black --line-length 100` on every file you add or change before you push. Two of the first three lane PRs here (#3962 and #3965) failed that job on one new test file each, and the autofix bot escalated instead of repairing them.

#### Acceptance criteria
- [x] `pytest` passes in CI with the new tests, and each new test fails when the code it covers is deliberately broken (the PR body shows the break-and-revert run).
- [x] The PR's Gate coverage shows the targets' uncovered statements+branches down by about 180 or more, or the PR body states how far short it is and why and explains each target that could not be meaningfully covered (a partial PR meets this criterion; no PR does not).
- [x] Production code changes only where a test found a real bug, each one explained in the PR body.

- [x] Same contract as every round in this initiative:
1. [ ] Pick the next target by the repo's own coverage-gap ranking (escaped-defect priority, then
   churn, then uncovered mass), not by file size.
2. [ ] Every new test must FAIL when the code it covers is deliberately broken and PASS when
   reverted -- run that break-and-revert for real and report it, don't assert it.
3. [ ] Real bugs found while writing tests get fixed with a minimal, targeted diff in the same PR,
   not worked around. Watch for the negative-cache pattern (cache.get(key) is None used as a 'not yet cached' check, which can't tell 'never queried' from 'queried and got nothing') -- it has recurred independently four separate times fleet-wide already.
4. [ ] Low blast radius only -- test-only or tightly-scoped fixes, no refactors.
5. [ ] One PR per logical chunk of work.

- [x] The goal is to improve the code, not a metric. If you measure this repo at or above 90% before
- [x] starting, say so in a comment on this issue and close it without opening a PR -- do not
- [x] manufacture a fix just because a round was requested.

<!-- auto-status-summary:end -->