"""Targeted counterexamples for cache identity, cache misses, and time boundary."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path('/tmp/wf4161-recovery')
ROOT = BASE / 'semantic'
OUT = BASE / 'semantic-proof'
OUT.mkdir(exist_ok=True)
ROOT.mkdir(exist_ok=True)
archive = subprocess.Popen(['git', 'archive', 'd2def1901357855222046823b609a8f87b95ccfb'], stdout=subprocess.PIPE)
subprocess.run(['tar', '-x', '-C', str(ROOT)], stdin=archive.stdout, check=True)
archive.stdout.close()
assert archive.wait() == 0
TEST = 'tests/scripts/test_check_consumer_sync_drift.py::'
PROD = 'scripts/check_consumer_sync_drift.py'
CASES = [
    ('cache-repo-identity', PROD, 'key = (repo, sha)', 'key = ("", sha)',
     TEST + 'test_main_keeps_unreadable_blob_cache_scoped_to_each_repo'),
    ('cache-negative-result', PROD, 'if key not in blob_text_cache:', 'if blob_text_cache.get(key) is None:',
     TEST + 'test_main_reports_create_only_gate_fyi_without_authorizing_sync'),
    ('boundary-equality', PROD, 'current_time - updated <= SYNC_COVERAGE_MAX_AGE', 'current_time - updated < SYNC_COVERAGE_MAX_AGE',
     TEST + 'test_build_report_sync_pr_coverage_lease_boundary'),
    ('boundary-direction', PROD, 'current_time - updated <= SYNC_COVERAGE_MAX_AGE', 'current_time - updated >= SYNC_COVERAGE_MAX_AGE',
     TEST + 'test_build_report_sync_pr_coverage_lease_boundary'),
    ('missing-remote-file', PROD, 'missing.add(f"{repo}: {remote_target}")', 'pass',
     TEST + 'test_main_marks_missing_remote_file_and_header_insensitive_match'),
    ('unknown-repo-filter', PROD, 'if repo in prs_by_repo:', 'if True:',
     TEST + 'test_build_remediation_states_ignores_prs_for_unknown_repos'),
]
CASES.append(('cache-empty-result', PROD, 'if key not in blob_text_cache:', 'if not blob_text_cache.get(key):', TEST + 'test_main_reports_create_only_gate_fyi_without_authorizing_sync'))
rows = json.loads((OUT / 'proof.json').read_text()) if (OUT / 'proof.json').exists() else []
completed = {r['id'] for r in rows}
for ident, production, old, new, node in CASES:
    if ident in completed:
        continue
    path = ROOT / production
    original = path.read_bytes()
    assert original.decode().count(old) == 1
    mutant = original.decode().replace(old, new)
    row = {'id': ident, 'test': node, 'production_file': production, 'original': old, 'replacement': new}
    def run(color):
        cmd = [sys.executable, '-m', 'pytest', '--no-cov', '-m', 'not quarantine and not slow', '-q', '--tb=short',
               '--junitxml=' + str(OUT / (ident + '-' + color + '.xml')), node]
        with (OUT / (ident + '-' + color + '.log')).open('w') as log:
            result = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=110)
        return {'command': cmd, 'exit': result.returncode}
    path.write_text(mutant)
    shutil.rmtree(path.parent / '__pycache__', ignore_errors=True)
    try:
        row['red'] = run('red')
    finally:
        path.write_bytes(original)
        shutil.rmtree(path.parent / '__pycache__', ignore_errors=True)
    assert row['red']['exit'] == 1
    row['failed_cases'] = [c.get('name') for c in ET.parse(OUT / (ident + '-red.xml')).findall('.//testcase') if c.find('failure') is not None]
    assert row['failed_cases']
    row['green'] = run('green')
    assert row['green']['exit'] == 0
    assert path.read_bytes() == original
    row['restored_sha256'] = hashlib.sha256(original).hexdigest()
    rows.append(row)
    (OUT / 'proof.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(ident, row['failed_cases'], flush=True)
