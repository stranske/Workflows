"""Replay per-case semantic mutations in an isolated merged-revision archive."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

import coverage

BASE = Path('/tmp/wf4161-recovery')
ROOT = BASE / 'merged'
OUT = BASE / 'mutations'
OUT.mkdir(exist_ok=True)
TARGETS = {
    'tests/scripts/test_check_consumer_sync_drift.py': 'scripts/check_consumer_sync_drift.py',
    'tests/scripts/test_issue_formatter.py': 'scripts/langchain/issue_formatter.py',
    'tests/scripts/test_validate_run_contract.py': 'scripts/validate_run_contract.py',
    'tests/test_post_ci_summary.py': 'tools/post_ci_summary.py',
}
data = coverage.CoverageData(basename=str(ROOT / '.coverage'))
data.read()
before = json.loads((BASE / 'parent-coverage.json').read_text())['files']
added = json.loads((BASE / 'new-tests.json').read_text())
originals = {p: (ROOT / p).read_bytes() for p in TARGETS.values()}
rows = json.loads((OUT / 'proof.json').read_text()) if (OUT / 'proof.json').exists() else []
completed = {r['test'] for r in rows}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')


def run(node, log, xml):
    cmd = [sys.executable, '-m', 'pytest', '-m', 'not quarantine and not slow',
           '--no-cov', '-q', '--tb=short', '--junitxml=' + str(xml), node]
    started = time.monotonic()
    with log.open('w') as output:
        result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=110)
    return {'command': cmd, 'exit': result.returncode,
            'seconds': round(time.monotonic() - started, 3)}


try:
    for testfile, names in added.items():
        sourcefile = TARGETS[testfile]
        path = ROOT / sourcefile
        source = originals[sourcefile].decode()
        lines = source.splitlines(keepends=True)
        offsets = [0]
        for line in lines:
            offsets.append(offsets[-1] + len(line.encode()))
        contexts = data.contexts_by_lineno(str(path.resolve()))
        tree = ast.parse(source)
        candidates = []
        for func in [tree, *ast.walk(tree)]:
            if not isinstance(func, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for n in ast.walk(func):
                if isinstance(n, ast.If):
                    expr = n.test
                    replacement = 'not (' + ast.get_source_segment(source, expr) + ')'
                    kind = 'invert condition'
                elif isinstance(n, ast.Return) and n.value is not None:
                    expr = n.value
                    replacement = "'MUTATION_SENTINEL'" if isinstance(expr, ast.Constant) and expr.value is None else 'None'
                    kind = 'replace return value'
                elif isinstance(n, ast.Continue):
                    expr = n
                    replacement = 'break'
                    kind = 'stop loop instead of skipping item'
                else:
                    continue
                start = offsets[expr.lineno - 1] + expr.col_offset
                end = offsets[expr.end_lineno - 1] + expr.end_col_offset
                candidates.append((expr.lineno, start, end, replacement, kind, getattr(func, 'name', '<module>')))
        for name in names:
            node = testfile + '::' + name
            if node in completed:
                continue
            test_ast = ast.parse((ROOT / testfile).read_text())
            test_func = next(n for n in ast.walk(test_ast) if isinstance(n, ast.FunctionDef) and n.name == name)
            direct_calls = {n.func.attr for n in ast.walk(test_func) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
            hit = {line for line, ctx in contexts.items() if any(name in c and testfile in c for c in ctx)}
            selected = [c for c in candidates if c[0] in hit]
            selected.sort(key=lambda c: (c[5] not in direct_calls, c[0] not in before[sourcefile]['missing_lines'], c[4] != 'invert condition', c[0]))
            found = None
            for attempt, (lineno, start, end, replacement, kind, function) in enumerate(selected[:12], 1):
                ident = f'{len(rows)+1:03d}-{attempt:02d}'
                mutated = originals[sourcefile][:start] + replacement.encode() + originals[sourcefile][end:]
                compile(mutated, sourcefile, 'exec')
                path.write_bytes(mutated)
                shutil.rmtree(path.parent / '__pycache__', ignore_errors=True)
                try:
                    red = run(node, OUT / (ident + '-red.log'), OUT / (ident + '-red.xml'))
                finally:
                    path.write_bytes(originals[sourcefile])
                    shutil.rmtree(path.parent / '__pycache__', ignore_errors=True)
                if red['exit'] != 1:
                    continue
                cases = ET.parse(OUT / (ident + '-red.xml')).findall('.//testcase')
                failures = [c.attrib['name'] for c in cases if c.find('failure') is not None]
                if not failures:
                    continue
                green = run(node, OUT / (ident + '-green.log'), OUT / (ident + '-green.xml'))
                assert green['exit'] == 0, (node, green)
                assert path.read_bytes() == originals[sourcefile]
                found = {'test': node, 'production_file': sourcefile, 'line': lineno,
                         'function': function, 'mutation': kind,
                         'original': originals[sourcefile][start:end].decode(),
                         'replacement': replacement, 'red': red, 'green': green,
                         'failed_cases': failures, 'log_prefix': ident,
                         'restored_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                break
            if found is None:
                raise RuntimeError(f'No detected relevant mutation for {node}; attempts={min(12, len(selected))}')
            rows.append(found)
            (OUT / 'proof.json').write_text(json.dumps(rows, indent=2) + '\n')
            print(len(rows), node, found['mutation'], found['line'], flush=True)
finally:
    for sourcefile, original in originals.items():
        (ROOT / sourcefile).write_bytes(original)
    (OUT / 'restoration.json').write_text(json.dumps({p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in originals}, indent=2) + '\n')
