import os
from pathlib import Path
import re
import tomllib

os.environ["BLACK_CACHE_DIR"] = "/tmp/issue3835-black-cache"
import black

root = Path.cwd()
config = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["black"]
paths = black.get_sources(
    root=root,
    src=(".",),
    quiet=True,
    verbose=False,
    include=re.compile(config["include"]),
    exclude=re.compile(r"(\.workflows-lib|node_modules)"),
    extend_exclude=black.re_compile_maybe_verbose(config["extend-exclude"]),
    force_exclude=None,
    report=black.Report(),
    stdin_filename=None,
)
for path in sorted(paths):
    result = black.main(
        ["--check", "--line-length", "100", "--config", str(root / "pyproject.toml"), str(path)],
        standalone_mode=False,
    )
    if result:
        raise SystemExit(result)
print(f"Serial Black checks passed for {len(paths)} files.")
