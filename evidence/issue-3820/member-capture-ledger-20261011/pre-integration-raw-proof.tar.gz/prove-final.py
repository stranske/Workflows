from pathlib import Path
import hashlib,json,subprocess
out=Path('/Users/teacher/.codex/automations/imi-merge-verify-closer/work/20261011T1618Z')
paths=['scripts/langchain/pr_verifier.py','templates/consumer-repo/scripts/langchain/pr_verifier.py','.github/scripts/agents_verifier_context.js','templates/consumer-repo/.github/scripts/agents_verifier_context.js']
saved={p:Path(p).read_bytes() for p in paths}
tests=['tests/scripts/test_pr_verifier_partition_recovery.py','.github/scripts/__tests__/agents-verifier-context.test.js']
receipt={'candidate_sha256':{p:hashlib.sha256(b).hexdigest() for p,b in saved.items()},'test_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in tests},'runs':[]}
cmds=[['python3','-m','pytest','tests/scripts/test_pr_verifier_partition_recovery.py::test_byte_rejection_retains_original_capture_gaps','--no-cov','-q'],['node','--test','--test-name-pattern=archive inventory retains|duplicate ZIP names|artifact capture ledger|archive member metadata ceiling|real archive keeps duplicate','.github/scripts/__tests__/agents-verifier-context.test.js']]
try:
 for p in paths:Path(p).write_bytes(subprocess.check_output(['git','show','HEAD:'+p]))
 receipt['mutant_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
 for i,cmd in enumerate(cmds):
  run=subprocess.run(cmd,capture_output=True,text=True);(out/f'final-production-red-{i}.log').write_text(run.stdout+run.stderr);receipt['runs'].append({'phase':'RED','argv':cmd,'cwd':str(Path.cwd()),'exit':run.returncode});assert run.returncode==1
finally:
 for p,b in saved.items():Path(p).write_bytes(b)
 receipt['restored_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
 assert receipt['restored_sha256']==receipt['candidate_sha256']
 (out/'final-mutation-proof.json').write_text(json.dumps(receipt,indent=2))
for i,cmd in enumerate(cmds):
 run=subprocess.run(cmd,capture_output=True,text=True);(out/f'final-restored-green-{i}.log').write_text(run.stdout+run.stderr);receipt['runs'].append({'phase':'GREEN','argv':cmd,'cwd':str(Path.cwd()),'exit':run.returncode});assert run.returncode==0
(out/'final-mutation-proof.json').write_text(json.dumps(receipt,indent=2))
print(receipt['runs'])
