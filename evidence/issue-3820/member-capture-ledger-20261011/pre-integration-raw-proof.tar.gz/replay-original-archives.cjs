const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const repo = process.argv[2], input = process.argv[3], output = process.argv[4];
const helper = require(path.join(repo, '.github/scripts/agents_verifier_context.js'));
const receiptBytes = fs.readFileSync(path.join(input, 'recovery.json'));
const receipt = JSON.parse(receiptBytes), digest = b => crypto.createHash('sha256').update(b).digest('hex');
const rows = receipt.rows.filter(r => r.status === 'raw-archive-recovered');
const runs = new Map();
for (const row of rows) {
 const metaBytes = fs.readFileSync(path.join(input, `${row.artifact_id}-metadata.json`));
 const zip = fs.readFileSync(path.join(input, `${row.artifact_id}.zip`));
 if (digest(metaBytes) !== row.metadata_sha256 || digest(zip) !== row.archive_sha256) throw Error('original binding mismatch');
 const meta = JSON.parse(metaBytes);
 if (meta.id !== row.artifact_id || meta.workflow_run.head_sha !== row.workflow_run.head_sha) throw Error('original provenance mismatch');
 if (!runs.has(row.workflow_run.id)) runs.set(row.workflow_run.id, []);
 runs.get(row.workflow_run.id).push(meta);
}
const github = {rest: {issues: {listComments: async () => ({data:[]})}, pulls: {
 listReviewComments: async () => ({data:[]}), listReviews: async () => ({data:[]})}, actions: {
 getWorkflowRun: async ({run_id}) => ({data: runs.get(run_id)[0].workflow_run}),
 listWorkflowRunArtifacts: async ({run_id}) => ({data: {total_count:runs.get(run_id).length, artifacts:runs.get(run_id)}}),
 downloadArtifact: async ({artifact_id}) => ({data:fs.readFileSync(path.join(input, `${artifact_id}.zip`))}),
}}};
(async () => {
 const result = await helper.fetchVerifierEvidence({github, owner:'stranske', repo:'Workflows', pullNumber:3802,
  pullRequestBody:'Evidence: '+[...runs.keys()].map(n=>`/actions/runs/${n}`).join(' '),
  associatedCommitShas:[...new Set(rows.map(r=>r.workflow_run.head_sha))]});
 const capture = result.diagnostics.archive_inventory;
 const selectedArtifactCount = result.diagnostics.references.selected_run_ids.reduce((n,id)=>n+runs.get(id).length,0);
 if (capture.length !== selectedArtifactCount || result.artifacts.complete) throw Error('lost selected artifact or false completeness');
 const payload = {mode:'offline-original-archive-replay-current-default-bounds-no-provider', original_receipt_sha256:digest(receiptBytes),
  original_context_sha256:receipt.original_context_sha256, source_sha256:digest(fs.readFileSync(path.join(repo,'.github/scripts/agents_verifier_context.js'))),
  original_archives_verified:rows.length, selected_artifacts_recorded:capture.length, status:result.status, artifacts_complete:result.artifacts.complete,
  rendered_records:result.artifacts.records.length, member_occurrences_recorded:capture.reduce((n,r)=>n+(r.members?.length||0),0),
  diagnostics:result.diagnostics};
 fs.writeFileSync(output,JSON.stringify(payload,null,2)+'\n');
 process.stdout.write(JSON.stringify({archives:rows.length, recorded_members:payload.member_occurrences_recorded,status:result.status,rendered_records:payload.rendered_records,counters:result.diagnostics.counters}));
})().catch(error=>{process.stderr.write(String(error));process.exitCode=1;});
